<template>
  <div>
    <!-- 头部 -->
    <mxg-header></mxg-header>

    <!-- 中间主体区域 -->
    <!-- pages文件夹下的渲染路由组件 -->
    <Nuxt class="main"/>

    <!-- 底部 -->
    <mxg-footer></mxg-footer>

    <!-- 回到顶部，bottom 下拉距离顶部多高时，
    显示回到顶部图标。注意不要加 :target-->
    <el-backtop :bottom="80"></el-backtop>
  </div>
</template>

<script>
import MxgHeader from "@/components/layout/Header";
import MxgFooter from "@/components/layout/Footer";

export default {
  components: {
    MxgHeader,
    MxgFooter
  }
};
</script>

<style scoped>
.main{
  padding-top: 80px;
}
</style>
