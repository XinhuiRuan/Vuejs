
export default {
  /*
  ** Nuxt rendering mode
  ** See https://nuxtjs.org/api/configuration-mode
  */
  mode: 'universal',

  env:{
    //认证客户端，取值 process.env.authURL
    authURL: process.env.NODE_ENV === 'dev' ? '//localhost:7000': '//login.mengxuegu.com',
  },

  /*
  ** Nuxt target
  ** See https://nuxtjs.org/api/configuration-target
  */
  target: 'server',
  /*
  ** Headers of the page
  ** See https://nuxtjs.org/api/configuration-head
  */
  head: {
    // title: process.env.npm_package_name || '',
    title: '梦学谷博客社区门户网',
    meta: [
      { charset: 'utf-8' },
      { name: 'viewport', content: 'width=device-width, initial-scale=1' },
      { hid: 'description', name: 'description', content: 'IT技术交流，JAVA开发问答_前端问答' }
    ],
    link: [
      { rel: 'icon', type: 'image/x-icon', href: '/favicon.ico' } // href可以修改网站的logo
    ]
  },
  /*
  ** Global CSS
  */
  css: [
    // 全局引入样式
    'element-ui/lib/theme-chalk/index.css',
    '~/assets/theme/index.css', // 自定义主题样式
    'element-ui/lib/theme-chalk/display.css', // element-ui的布局样式
    '~/assets/css/global.css', // 自定义全局样式
  ],
  /*
  ** Plugins to load before mounting the App
  ** https://nuxtjs.org/guide/plugins
  */
  plugins: [
    '~/plugins/element-ui.js',
    '@/plugins/interceptor.js',
  ],
  /*
  ** Auto import components
  ** See https://nuxtjs.org/api/configuration-components
  */
  components: true,
  /*
  ** Nuxt.js dev-modules
  */
  buildModules: [
  ],
  /*
  ** Nuxt.js modules
  */
  modules: [
    '@nuxtjs/axios', // 引入
    'cookie-universal-nuxt', // 针对服务端操作cookie
    
  ],
  // 设置代理需要先下载@nuxtjs/axios模块
  axios:{
    proxy: true, // 开启代理转发
    prefix: '/api' // 请求接口添加前缀 /api，/test => /api/test
  },

  proxy: {
    // 将/api开头的请求都进行代理转发，// 比如：/api/test => http://mengxuegu.com:7300/mock/5f2e5c6cfd0fa244c4c55f73/nuxt-blog/test
   '/api': { 
     target: "http://mengxuegu.com:7300/mock/5f2e5c6cfd0fa244c4c55f73/nuxt-blog",
     pathRewrite: {'^/api': ''} // 将/api替换为空，/api/test => /test
   }
 },

  /*
  ** Build configuration
  ** See https://nuxtjs.org/api/configuration-build/
  */
  build: {
    // 将位于 node_modules 目录下的 element-ui 导出
    transpile: [/^element-ui/],

    // webpack自定义配置
    extend(config, ctx){

    }
  }
}
