<template>
  <div class="main">
    <el-row type="flex" justify="space-between">
      <!-- 左侧 -->
      <el-col class="hidden-sm-and-down" :md="3">
        <!-- 技术频道:实际上就是类别 -->
        <el-divider content-position="left">技术频道</el-divider>
        <!-- 类目 -->
        <el-menu active-text-color="#ffffff" router :default-active="$route.path">
          <el-menu-item index="/">推荐</el-menu-item>
          <el-menu-item index="/1">Java</el-menu-item>
          <el-menu-item index="/2">前端</el-menu-item>
          <el-menu-item index="/3">Python</el-menu-item>
          <el-menu-item index="/4">小程序</el-menu-item>
        </el-menu>
      </el-col>

      <!-- 中间 -->
      <el-col :xs="24" :sm="24" :md="16">
        <div class="blog-center">
          <!-- 走马灯 -->
          <div class="banner">
            <el-carousel height="230px">
              <el-carousel-item v-for="item in 1" :key="item">
                <!-- 这里跳转不使用nuxt-link的原因： 它会作为子路由跳转，而要广告要跳转到外链就需要a标签href才行 -->
                <a href="http://www.mengxuegu.com" target="_blank">
                  <img
                    src='https://fuss10.elemecdn.com/9/bb/e27858e973f5d7d3904835f46abbdjpeg.jpeg'
                  />
                </a>
              </el-carousel-item>
            </el-carousel>
          </div>
        </div>
      </el-col>

      <!-- 右侧 -->
      <el-col :md="5">
        <el-card class="right-card" shadow="hover" :body-style="{padding: '10px'}">
          <p>课程推荐</p>
          <el-carousel height="210px">
            <el-carousel-item v-for="item in 1" :key="item">
              <!-- nuxt-link 会作为子路由跳转，而要广告要跳转到外链就需要a标签href才行 -->
              <a target="_blank" href="http://www.mengxuegu.com/">
                <img
                  src="https://fuss10.elemecdn.com/e/5d/4a731a90594a4af544c0c25941171jpeg.jpeg"
                />
                <span>canvas 必备的动画效果大全果大全</span>
              </a>
            </el-carousel-item>
          </el-carousel>
        </el-card>
      </el-col>
    </el-row>
  </div>
</template>

<script>
export default {
  data() {
    return {};
  }
};
</script>

<style scoped>
/* scoped 局部引入 */
@import "@/assets/css/blog/index.css"; /*这个分号一定要写，不然报错*/
</style>
