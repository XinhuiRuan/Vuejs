export default ({ store, route, redirect, $axios }) => {
    $axios.onRequest(config => {
        //console.log("请求拦截器")
        // 请求头添加token
        const accessToken = store.state.accessToken
        if (accessToken) {
            // 针对每个请求，请求头上带上令牌 Authorization: Bearer token
            config.headers.Authorization = 'Bearer ' + accessToken
        }

        return config
    })

    $axios.onResponse(response => {
        // console.log("响应拦截器：", response)
        // 测试：令牌不存在，发送刷新令牌请求
        // if (!store.state.accessToken) {
        //     sendRefreshRequest(store, route, redirect)
        // }
        return response
    })

    $axios.onError(error => {
        //console.log("响应异常：", error)
        if (error.response.status != 401) {
            // 非401认证，直接放行
            return Promise.reject(error)
        } else {
            // 401 发送刷新令牌请求
            sendRefreshRequest(store, route, redirect)
            return Promise.reject('令牌过期，重新登录')
        }

    })
}

// 锁， 防止并发重复请求, true还未请求，false正在请求刷新
let isLock = true

const sendRefreshRequest = (store, route, redirect) => {
    if (isLock && store.state.refreshToken) {
        // 有刷新令牌，防止并发重复请求刷新
        isLock = false
        // 通过刷新令牌获取新令牌，由于发送请求可能在客户端或服务端，因此不能用客户端的window.location.href进行页面跳转
        redirect(`${process.env.authURL}/refresh?redirectURL=${redirectURL(route)}`)
    } else {
        isLock = true
        // 没有刷新令牌，跳转到登录页
        // 注意不要使用 store.dispatch('LoginPage') ，因为 LoginPage 里面使用了window对象，nuxt服务端是没有此对象的
        store.commit('RESET_USER_STATE')
        // 跳转到登录页
        redirect(`${process.env.authURL}?redirectURL=${redirectURL(route)}`)
    }
}

// 获取重定向地址
const redirectURL = (route) => {
    // 客户端
    if (process.client) {
        return window.location.href
    }
    // 服务端获取当前请求的路由地址，通过路由对象获取
    // process.env._AXIOS_BASE_URL_获取发送axios的基础url，开发：http://localhost:3000/api；发布：http://blog.mengxuegu.com/api
    return process.env._AXIOS_BASE_URL_.replace('api', '') + route.path.slice(1)
}