import Vue from 'vue';
import ElementUI from 'element-ui';

Vue.use(ElementUI);

/*
    使用element-ui的步骤
    1. 创建 plugins/element-ui.js 文件
    2. 在 nuxt.config.js 中引入该插件文件
    3. 引入element-ui的样式（组件和布局样式）
*/ 