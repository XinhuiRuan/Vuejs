module.exports = {
    devServer: {
        port: 8888, // 端口号，如果端口号被占用，会自动提升1
        host: "localhost", //主机名， 127.0.0.1， 真机 0.0.0.0
        https: false, //协议
        open: true, //启动服务时自动打开浏览器访问

        // 通过代理 proxy 解决 axios 跨域问题（注意：这是开发环境的代理配置，生产环境的代理配置是另外配的）
        // proxy: {
        //     // 匹配 /dev-api 开头的请求，
        //     '/dev-api': {
        //         // 目标服务器, 代理访问到 https://localhost:8001
        //         target: 'http://localhost:8001',
        //         // 开启代理：在本地会创建一个虚拟服务端，然后发送请求的数据，
        //         // 并同时接收请求的数据，这样服务端和服务端进行数据的交互就不会有跨域问题
        //         changOrigin: true,
        //         pathRewrite: {
        //             // 会将 /dev-api 替换为 '',也就是 /dev-api 会移除，
        //             // 如 /dev-api/db.json 被替换代理到 https://localhost:8001/db.json
        //             '^/dev-api': '',
        //         }
        //     }
        // }

        // 重构代理配置，使用不同环境的常量值
        proxy: {
            [process.env.VUE_APP_BASE_API]: {
                target: process.env.VUE_APP_SERVICE_URL, // 在 .env.development 中配置的
                changOrigin: true,
                pathRewrite: {
                    ['^' + process.env.VUE_APP_BASE_API]: ''
                }
            }
        }
    },

    publicPath:"./",  // 可以设置成相对路径，这样所有的资源都会被链接为相对路径，打出来的包可以被部署在任意路径
    // outputDir:"dist",  //打包时生成的生产环境构建文件的目录
    //assetsDir: "public",  // 放置生成的静态资源 (js、css、img、fonts) 的 (相对于 outputDir 的) 目录

    lintOnSave: false, // 关闭格式检查
    productionSourceMap: false, // 打包时不会生成 .map 文件，加快打包速度
}
