import { initRegisteredInfo } from '@/api/login'
import joinApi from "@/api/join"

const hunter = {
    state: {
        registeredId: process.env.VUE_APP_REGISTERED_ID, // 得到赏金猎人注册的ID  
        weixinId: process.env.VUE_APP_WEIXIN_ID, // 用户微信ID 
        
        weixinSelfie: '', // 用户微信头像地址  
        weixinName: '', // 用户微信名称    
        swipeImgs: [],
        adsImgs: []
    },

    mutations: {
        SET_REGISTEREDID(state, registeredId) {
            state.registeredId = registeredId;
        },

        SET_WEIXINID(state, weixinId) {
            state.weixinId = weixinId;
        },

        SET_WEIXINSELFIE(state, weixinSelfie) {
            state.weixinSelfie = weixinSelfie;
        },

        SET_WEIXINNAME(state, weixinName) {
            state.weixinName = weixinName;
        },

        SET_SWIPEIMGS(state, newSwipeImgs) {
            state.swipeImgs = newSwipeImgs;
        },

        SET_ADSIMGS(state, newAdsImgs) {
            state.adsImgs = newAdsImgs;
        },
    },

    actions: {
        // 第一次从首页进入，根据微信的code从后台得到猎人加盟id、微信id、微信名和微信头像图片链接
        InitRegisteredInfo({ commit, state }, code) {
            return new Promise((resolve, reject) => {
                initRegisteredInfo(code).then(response => {
                    const resp = response.data
                    const flag = resp.flag
                    if (flag) {
                        const infos = resp.data
                        if (infos.hunter_id) {
                            // 是已加盟的猎人
                            commit("SET_REGISTEREDID", infos.hunter_id)
                        }
                        commit("SET_WEIXINID", infos.openid)
                        commit("SET_WEIXINSELFIE", infos.headimgurl)
                        commit("SET_WEIXINNAME", infos.nickname)
                    }
                    resolve(flag)
                })
            })
        },

        Join({ commit }, form) {
            // 提交表单给后台进行验证是否正确
            // resolve 触发成功处理，reject 触发异常处理
            return new Promise((resolve, reject) => {
                joinApi.addHunter(form).then(response => {
                    const resp = response.data
                    commit("SET_REGISTEREDID", resp.data.id) // 获取新的猎人注册id
                    resolve(resp)
                });
            })
        },

        // 保存首页的跑马灯图片
        AddSwipeImgs({ commit }, newSwipeImgs) {
            commit("SET_SWIPEIMGS", newSwipeImgs) 
        },
        AddAdsImgs({ commit }, newAdsImgs) {
            commit("SET_ADSIMGS", newAdsImgs) 
        },
    }
}

export default hunter