import request from "@/utils/request"

export default{
    // 得到问题回答
    getAnswers(curLen,eachLen){
        return request({
            url: `/answers?curLen=${curLen}&eachLen=${eachLen}`,
            method: "get",           
        })
    },
}