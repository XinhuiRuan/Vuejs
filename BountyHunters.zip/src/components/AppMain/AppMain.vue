<template>
  <div class="main">
    <!-- 使用 v-show 判断路由为 /home 时不显示横向指示导航 -->
    <!-- <app-link v-show="$route.path !== '/home'"></app-link> -->
    <!-- 当扫二维码进入存在id值时不显示导航栏 -->
    <app-link v-if="$route.query.id ? false : true"></app-link>

    <!-- 子路由渲染出口 -->
    <!-- <router-view>
    </router-view> -->

    <keep-alive>
    <router-view v-if="$route.meta.keepAlive">
        <!-- 这里是会被缓存的视图组件 -->
    </router-view>
    </keep-alive>

    <router-view v-if="!$route.meta.keepAlive">
        <!-- 这里是不被缓存的视图组件 -->
    </router-view>
  </div>
</template>

<script>
import AppLink from './AppLink.vue'

export default {
  data() {
    return {};
  },

  components: {AppLink},

  methods: {}
};
</script>

<style scoped>

</style>