<template>
  <div class="navbar">
    <!-- 路由模式下会匹配页面路径和标签的to属性，并自动选中对应的标签 -->
    <van-tabbar v-model="active" class="active_tab">
      <van-tabbar-item v-for="(item,index) in tabbars" :key="index" :to="item.name">
        <span>{{item.title}}</span>
        <img slot="icon" :src="$route.path.indexOf(item.name) != -1 ? item.active : item.normal" />
      </van-tabbar-item>
    </van-tabbar>
  </div>
</template>

<script>
export default {
  data() {
    return {
      currIndex: 0,
      active: 0,
      tabbars: [
        {
          name: "/home",
          title: "首页",
          normal: require("@/assets/NavbarIcons/home.png"),
          active: require("@/assets/NavbarIcons/home_ac.png")
        },
        {
          name: "/answer",
          title: "答疑解惑",
          normal: require("@/assets/NavbarIcons/answer.png"),
          active: require("@/assets/NavbarIcons/answer_ac.png")
        },
        {
          name: "/member",
          title: "会员",
          normal: require("@/assets/NavbarIcons/member.png"),
          active: require("@/assets/NavbarIcons/member_ac.png")
        }
      ]
    };
  },

  components: {},

  created() {
    this.SetActiveIdx();
  },

  methods: {
    // 通过页面当前路由判断active哪个导航标签
    SetActiveIdx() {
      const curPath = this.$route.path;
      for (let item in this.tabbars) {
        let idx = item - 0;
        if (curPath.indexOf(this.tabbars[idx].name) != -1) {
          this.active = idx;
        }
      }
    }
  }
};
</script>

<style scoped>
.el-menu {
  border-right: none;
}

.active_tab img {
  /* width: 26px; */
  height: 26px;
}

.van-tabbar-item--active {
  color: #1e90ff;
}
</style>