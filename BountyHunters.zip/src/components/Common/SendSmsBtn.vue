<template>
  <div class>
    <van-button slot="button" :disabled=" telephone.length == 11 ? hasSend : true" 
    size="small" type="primary" @click="SendSms" :text="smsBtnMsg"/>
  </div>
</template>

<script>
import joinApi from "@/api/join";
export default {
  components: {},
  props: ["telephone"],

  data() {
    return {
      smsBtnMsg: "发送验证码", // 发送验证码按钮显示的信息
      hasSend: false, // 是否在发送验证码状态
      countTime: 60
    };
  },

  methods: {
    // 发送验证码
    SendSms() {
      this.hasSend = true
      let that = this
      // 倒计时方法
      function countdownFunc() {
        that.countTime -= 1
        that.smsBtnMsg = that.countTime + "秒后重新获取"
      }
      countdownFunc()
      var timing = setInterval(countdownFunc, 1000)

      setTimeout(() => {
        // 充重置数据
        this.hasSend = false
        this.countTime = 60
        this.smsBtnMsg = "发送验证码"
        clearInterval(timing); // 清除定时器
      }, 60 * 1000)
      // 发送电话号码到后台
      joinApi.sendSms(this.telephone).then(response => {
        const resp = response.data
        if (!resp.flag) {
          this.$toast(resp.message)
          return
        }
      })
    }
  }
}
</script>

<style scoped>
</style>