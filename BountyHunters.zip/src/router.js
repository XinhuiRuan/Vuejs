import Vue from "vue";
import Router from "vue-router";
// 默认导入目录下的 index.vue 文件，等价于 ./views/login/index.vue，只适用于取名字为 index.vue
import Layout from "./components/Layout.vue"
import Main from "./components/AppMain/AppMain.vue"
import Home from "./views/home/home.vue"
import Join from "./views/home/join.vue"
import Recommend from "./views/home/recommend.vue"
import Recruit from "./views/home/recruit.vue"
import RecruitAd from "./views/home/recruitAd.vue"
import Apply from "./views/home/apply.vue"
import Resumes from "./views/home/resumes.vue"
import Answer from "./views/answer/answer.vue"
import Member from "./views/member/member.vue"
import PersonalInfo from "./views/member/personalInfo.vue"
import BankAccount from "./views/member/bankAccount.vue"
import JoinLetter from "./views/member/joinLetter.vue"
import MyQrCode from "./views/member/myQrCode.vue"

Vue.use(Router);

export default new Router({
  //mode:"history",//去除哈希值的#号s
  routes: [
    // {
    //   // 登录页
    //   path: "/login",
    //   name: 'login', //路由名称
    //   component: Login
    // },
    {
      // 基础布局
      path: "/",
      name: 'layout', //路由名称
      component: Layout,
      redirect: '/home', // 重定向到子路由
      children: [
        {
          path: '/home',
          component: Home,
          meta: {
            title: '赏金猎人',
            keepAlive: true // 需要被缓存
          }
        },
        // 第一种：写之后几个组件路由的方法，但会显得冗余，推荐第二种
        // {
        //   path: '/member/',
        //   component: Member,
        //   meta: {title: '会员管理'}
        // }
      ]
    },
    {
      // 我要加入
      path: '/home/join',
      component: Main,
      children: [
        {
          path: '/',
          component: Join,
          name: 'join',
          meta: {title: '资料填写'}
        }
      ]
    },
    {
      // 我要推荐
      path: '/home/recommend',
      component: Main,
      children: [
        {
          path: '/',
          component: Recommend,
          meta: {title: '推荐资料填写'}
        }
      ]
    },
    {
      // 招募推广
      path: '/home/recruit',
      component: Main,
      children: [
        {
          path: '/',
          component: Recruit,
          meta: {
            title: '招募推广',
            keepAlive: true // 需要被缓存
          }
        }
      ]
    },
    {
      // 专属广告
      path: '/home/recruit/recruitAd',
      component: Main,
      children: [
        {
          path: '/',
          component: RecruitAd,
          meta: {
            title: '专属广告',
            keepAlive: true // 需要被缓存
          }
        }
      ]
    },
    {
      // 面试申请
      path: '/home/apply',
      component: Apply,
      meta: {title: '面试申请'}
    },

    {
      // 简历查询
      path: '/home/resumes',
      component: Main,
      children: [
        {
          path: '/',
          component: Resumes,
          meta: {title: '简历查询'}
        }
      ]
    },

    // 第二种：写之后几个组件的路由的方法
    {
      path: '/member',
      component: Layout,
      children: [
        {
          path: '/',
          component: Member,
          meta: {
            title: '会员中心',
            keepAlive: true // 需要被缓存
          }
        }
      ]
    },
    {
      // 我的资料
      path: '/member/personalInfo',
      component: Main,
      children: [
        {
          path: '/',
          component: PersonalInfo,
          meta: {title: '我的资料'}
        }
      ]
    },
    {
      // 绑定银行卡号
      path: '/member/bankAccount',
      component: Main,
      children: [
        {
          path: '/',
          component: BankAccount,
          meta: {title: '绑定银行卡号'}
        }
      ]
    },
    {
      // 我的二维码
      path: '/member/myQrCode',
      component: Main,
      children: [
        {
          path: '/',
          component: MyQrCode,
          meta: {title: '我的二维码'}
        }
      ]
    },
    {
      // 加盟函
      path: '/member/personalInfo/joinLetter',
      component: Main,
      children: [
        {
          path: '/',
          component: JoinLetter,
          meta: {title: '加盟函'}
        }
      ]
    },
    {
      // 加盟函
      path: '/home/joinLetter',
      component: Main,
      children: [
        {
          path: '/',
          component: JoinLetter,
          meta: {title: '加盟函'}
        }
      ]
    },


    {
      path: '/answer',
      component: Layout,
      children: [
        {
          path: '/',
          component: Answer,
          meta: {
            title: '答疑解惑',
            keepAlive: true // 需要被缓存
          }
        }
      ]
    },
   
  ]
});
