<template>
  <div class v-show="show">
    <div class="imgDiv" align="center">
      <van-image fit="fill" :src="answerImg" />
    </div>

    <div class="commonFont" align="center">
      <span>
        咨询电话：
        <span v-text="hotline"></span>
      </span>
      <a :href="'tel://'+hotline" class="el-icon-phone" style="margin-left: 1%;">
        <!-- <van-icon name="phone" color="blue" size="1rem"/> -->
      </a>
    </div>

    <van-list
      class="answerList"
      v-model="loading"
      :finished="finished"
      finished-text="没有更多了"
      @load="onLoad"
    >
      <div class="loadingArea">
        <!-- 循环遍历问题回答 -->
        <van-panel v-for="(item,index) in answers" :key="index" :title="item.question">
          <span>{{item.answer}}</span>
        </van-panel>
      </div>
    </van-list>
  </div>
</template>

<script>
import answersApi from "@/api/answers";
import funHelper from "lodash/function";

export default {
  components: {},

  data() {
    return {
      answerImg: require("@/assets/Images/answerImg.jpg"), // 答疑解惑图片的地址
      answers: [],
      hotline: "137-8007-7009",
      show: true,
      loading: false,
      finished: false,
      eachLen: 3, // 每次从后台获取数据的长度
    };
  },

  // 钩子函数获取职业信息
  // created() {
  //   //this.fetchAnswerData()
  //   this.onLoad()
  // },

  // mounted() {
  //   let img = document.getElementsByClassName("van-image")[0].childNodes[0]; //图片
  //   img.onload = () => {
  //     this.show = true;
  //   };
  // },

  methods: {
    onLoad: funHelper.throttle(
      function() {
        // 如果使用()=> 箭头函数 this指向根实例，使用普通函数function()不改变this指向本组件
        console.log("1000ms内只能调用一次!");
        this.fetchAnswerData();
      },
      1000,
      { trailing: false }
    ),

    // onLoad(){
    //   console.log("我被调用了!");
    //   this.fetchAnswerData();
    // },

    // 获取后台维护的答疑解惑
    fetchAnswerData() {
      // 获取后台维护的问题回答
      answersApi.getAnswers(this.answers.length, this.eachLen).then(response => {
        const resp = response.data
        if (resp.flag) {
          // 查询成功
          for (const item of resp.data.rows) {
            this.answers.push({
              question: "Q"+ item.sort + "：" + item.question,
              answer: item.answer
            });
          }

          // 加载状态结束
          this.loading = false

          let loadingTimer = setInterval(()=>{
            // 解决用户下滑太快，定时器每隔1秒如果处于加载状态但是还未加载完，重新触发onload事件
            if(!this.finished && this.loading)  {
              this.loading = false
            }
          },1000)

          // 数据全部加载完成
          if (this.answers.length >= resp.data.total) {
            this.finished = true;
            clearTimeout(loadingTimer) // 清除定时器
          }
          console.log(this.answers.length)
        }
      })
      
    }
  }
};
</script>

<style scoped>
.commonFont {
  margin-top: 1.5vh;
}

.van-panel {
  margin: 1.5vh 1vw;
  background: #f5f5f5;
  /* box-shadow: 0 0.5vh 0.5vh 0 #a9a9a9; */
}
.van-cell {
  background: #f5f5f5;
  font-size: 0.8rem;
  font-weight: bold;
  padding: 1vh 0;
  width: 94vw;
  margin: 0 auto;
  border-bottom: 0.2vh solid #a9a9a9;
}
.van-panel__content {
  padding: 1vh 3vw;
  font-size: 0.65rem;
  line-height: 5vh;
  text-align: justify;
}

.commonFont {
  font-size: 0.8rem;
}

.answerList:after {
  content: "";
  height: 50px;
  display: block;
}
</style>