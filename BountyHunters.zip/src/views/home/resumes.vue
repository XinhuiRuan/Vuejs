<template>
  <div>
    <van-search v-model.trim="search" show-action placeholder="请输入姓名或手机号" @search="fetchResumes">
      <template #action>
        <van-button type="info" size="small" @click="fetchResumes">查询</van-button>
      </template>
    </van-search>

    <!-- 简历信息卡片部分 -->
    <!-- <van-list
      class="cardBody"
      v-model="loading"
      :finished="finished"
      finished-text="没有更多了"
      @load="onLoad"
    > -->
    <div class="cardBody">
      <div
        class="card"
        v-for="resume in resumesList"
        :key="resume.sort"
        @click="showDialog(resume.id)"
      >
        <div class="part1">
          <span v-text="resume.name"></span>
        </div>
        <div class="part2">
          <div>
            <i class="el-icon-phone"></i>
            <span v-text="resume.telephone"></span>
          </div>
          <div>
            <i class="el-icon-date"></i>
            <span v-text="resume.interviewDate"></span>
          </div>
        </div>
      </div>
    </div>
    <!-- </van-list> -->

    <!-- 固定底部显示文字 -->
    <van-tabbar>
      <div>
        <span>共{{total}}份简历信息</span>
      </div>
    </van-tabbar>

    <van-dialog v-model="dialogShow" title=" " confirm-button-text="取消">
      <recommend
        :isSubComponent="true"
        :isResumes="true"
        :propEmpId="empId"
        @close_dialog="closeDialog"
      ></recommend>
    </van-dialog>
  </div>
</template>

<script>
//import _ from 'lodash';
import funHelper from 'lodash/function'
import resumesApi from "@/api/resumes";
import Recommend from "@/views/home/recommend.vue";

export default {
  data() {
    return {
      search: "",
      resumesList: [],
      total: 0,
      dialogShow: false, // 是否显示被推荐人信息对话框
      empId: "",
      loading: false,
      finished: false,
      timer: null
    };
  },

  components: {
    Recommend
  },

  created() {
    this.fetchResumes();
  },

  methods: {
    // onLoad: funHelper.throttle(function(){
    //   // 如果使用()=> 箭头函数 this指向根实例，使用普通函数function()不改变this指向本组件
    //   console.log(this); 
    //   console.log('2秒内只能调用一次!');
    //   this.fetchResumes(); 
    //  }, 1000, { 'trailing': false }),

    //onLoad() {
      //  setTimeout(() => {
      // for (let i = 0; i < 20; i++) {
      //   this.list.push(this.list.length + 1);
      // }

      // // 加载状态结束
      // this.loading = false;

      // // 数据全部加载完成
      // if (this.list.length >= 100) {
      //   this.finished = true;
      // }
      //  }, 1000);

    //   if (!this.timer) {
    //     this.timer = setTimeout(() => {
    //       this.fetchResumes(); 
    //       this.timer = null;
    //     }, 100);
    //   }
    // },

    // 查询该赏金猎人的收集简历列表
    fetchResumes() {
      const registeredId = this.$store.state.hunter.registeredId; // 得到赏金猎人的id
      resumesApi.getResumes(registeredId, this.search).then(response => {
        const resp = response.data;
        if (resp.flag) {
          const data = resp.data
          this.total = data.total
          this.resumesList = data.rows
          // data.rows.forEach(row => {
          //   row.sort = this.resumesList + 1
          //   this.resumesList.push(row)
          // });
        }

        // 查询需要有查询结果提示
        if (this.search) {
          if (resp.flag) {
            this.$toast.success(resp.message);
          } else {
            this.$toast.fail(resp.message);
          }
        }

        //console.log(this.resumesList.length)
      });

      // 加载状态结束
     // this.loading = false;
      
    },

    showDialog(value) {
      this.empId = value;
      this.dialogShow = true;
    },

    // beforeClose(action, done) {
    //   /* 先在<van-dialog>加上属性:beforeClose="beforeClose"
    //    beforeClose：相当于一个钩子函数，会在关闭之前执行一些操作，会有两个参数，action, done。
    //     action是点击的目标的名称，如果点击了"确认"按钮，则action为confirm；如果点击了"取消"按钮，则action为cancel。
    //     done是执行关闭的操作。 */
    //   // console.log(action);
    //   done();
    // },

    // 子组件我要推荐调用的方法
    closeDialog(flag) {
      // 1. 关闭弹出框
      this.dialogShow = flag;
      // 2. 重新查询列表（简单版），也可以实现前台更新该条信息，不用全部刷新（跟user确认）
      this.fetchResumes();
    }
  }
};
</script>

<style scoped>
.card {
  display: table;
  height: 15vh;
  width: 90vw;
  margin: 3vh auto;
  box-shadow: 0.5rem 0.5rem 0.8rem #888888;
}

.part1,
.part2 {
  display: table-cell;
}
.part1 {
  width: 40%;
  font-weight: bold;
  vertical-align: middle;
  text-align: center;
  color: rgba(19, 61, 197, 0.459);
}
.part2 {
  width: 60%;
  background: rgba(19, 61, 197, 0.459);
  color: white;
  padding-left: 8vw;
}
.part2 div {
  margin-top: 2.5vh;
}
.part2 i {
  font-size: 1rem;
}
.part2 span {
  font-size: 0.8rem;
  margin-left: 5vw;
}

.van-tabbar {
  color: #1989fa;
  background: #ecf9ff;
  font-size: 0.8rem;
  line-height: 5vh;
  height: 5vh;
}

.van-tabbar div {
  margin: 0 auto;
}

.cardBody:after {
  content: "";
  height: 35px;
  display: block;
}

.van-dialog {
  width: 90%;
}
</style>