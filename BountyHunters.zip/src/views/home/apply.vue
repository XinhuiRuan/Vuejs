<template>
  <div>
    <div class="notice">
      <div>1.请填写个人相关信息并选择预计面试日期进行面试申请。</div>
      <div>2.面试申请提交成功后，您的推荐人会与您取得联系并进行电话面试，如您有问题也可与推荐人进行联系，联系方式见下方（推荐人信息）。</div>
    </div>
    <recommend :isSubComponent="true" :isRecruitment="true" :propBhMobile="bhMobile"></recommend>   
  </div>
</template>

<script>
import Recommend from "@/views/home/recommend.vue";
import memberApi from "@/api/member";

export default {
  data() {
    return {
      bhMobile: ''
    };
  },

  components: {
    Recommend
  },

  created(){
    const bhId = this.$route.query.id
    if(bhId){
      this.getHunterPhone(bhId)
    }
  },

  methods: {
    // 根据二维码上的赏金猎人id得到手机号码
    getHunterPhone(bhId){
      memberApi.getMemberPersonalInfo(bhId).then(response => {
        const resp = response.data;
        if (resp.flag) {
          this.bhMobile = resp.data.telephone;
        } else {
          this.$toast.fail(resp.message);
        }
      });
    }
  }
};
</script>

<style scoped>
.notice {
  font-size: 0.8rem;
  text-align: justify;
  color: #606266;
  line-height: 1.5rem;
  padding: 2vh 8vw;
}
</style>