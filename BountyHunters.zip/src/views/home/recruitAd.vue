<template>
  <div class="content">
    <van-loading size="24px" color="#1989fa" vertical v-show="loadingShow">
      <span style="color: #1989fa;" v-text='msg'></span>
    </van-loading>
    <!-- img2Loaded:{{img2Loaded}}
    <br />
    img1Loaded:{{img1Loaded}}
    <br />
    err: {{err}}
    <br />
    img3Loaded:{{img3Loaded}}
    <br />
    img4Loaded:{{img4Loaded}} -->
    <div id="code" v-show="false">
      <canvas id="canvas" v-show="false"></canvas>
    </div>

    <!-- 最后图片生成部分 -->
    <div id="result"></div>
  </div>
</template>

<script>
import QRCode from "qrcode";

export default {
  components: {
    QRcode: QRCode //注册生成二维码组件
  },

  data() {
    return {
      imgNum1: 2,
      imgNum2: 2,
      qrcodeBgImg: require("../../assets/Images/qrcodeBg.png"), // 二维码的背景图
      adImg: require("../../assets/Images/ads.jpg"), // 广告的图片
      loadingShow: true,
      msg: '正在加载中...'
      // img2Loaded: false,
      // img1Loaded: false,
      // err: "",
      // img3Loaded: false,
      // img4Loaded: false
    };
  },

  mounted() {
    this.createQRCode();
  },

  methods: {
    createQRCode() {
      var that = this
      var img2 = new Image()
      img2.setAttribute("crossOrigin",'Anonymous')
      img2.src = this.qrcodeBgImg
      // 加载二维码背景图img2
      img2.onload = () => {
        //that.img2Loaded = true;

        // 第一步：img2加载完成，生成二维码img1
        const registeredId = this.$store.state.hunter.registeredId; // 得到赏金猎人的id
        let url = `http://ngbapp.innolux.com/InnoluxBountyHunters/index.html#/home/apply?id=${registeredId}`;

        var canvas = document.getElementById("canvas"); //获取到canvas
        QRCode.toCanvas(canvas, url, error => {
          if (error) console.error(error);
          //console.log("success!");
        });

        var img1 = new Image()
        img1.setAttribute("crossOrigin",'Anonymous')
        img1.src = canvas.toDataURL("image/png")

        img1.onload = () => {
          //that.img1Loaded = true;

          // 第二步：二维码img1加载完成，与img2合成生成个人专属二维码img3
          var canvas = document.createElement("canvas"),
            context = canvas.getContext("2d");
          canvas.width = img2.width;
          canvas.height = img2.height;
          // 将 img2（背景图） 加入画布
          context.drawImage(img2, 0, 0, img2.width, img2.height);
          // 将 img1 加入画布(img1,离left的距离，离top的距离)
          let left = img2.width * 0.6;
          let top = img2.height * 0.25;
          let width = img2.width * 0.3;
          let height = width;
          context.drawImage(img1, left, top, width, height);

          // 设置字体
          // context.font = "3rem bold 黑体";
          // // 设置颜色
          // context.fillStyle = "#ff0";
          // // 设置水平对齐方式
          // context.textAlign = "center";
          // // 设置垂直对齐方式
          // context.textBaseline = "middle";
          // context.fillText("要写的文字", 200, 200);

          context.stroke();

          // 将画布内容导出
          var img3 = new Image(); //实例一个img
          
          try {
            img3.setAttribute("crossOrigin",'Anonymous')
            img3.style.width = "100%";
            img3.src = canvas.toDataURL("image/png", 0.7); //转换成base64格式路径的png图片

            var img4 = new Image();
            img4.setAttribute("crossOrigin",'Anonymous')
            img4.src = this.adImg;
            // 第三步：设置定时器50ms执行1次，当img3和广告图img4都加载完成后，进行合成
            var timer = setInterval(function() {
            //  that.img3Loaded = img3.complete;
            //  that.img4Loaded = img4.complete;

              if (img3.complete && img4.complete) {
                var canvas = document.createElement("canvas"),
                  context = canvas.getContext("2d");

                // 当img4和img3的宽度超过最大值时，需要将图片等比例缩小
                // 等比例缩放图片的方法
                function scaleImgs(image, maxWidth) {
                  if (image.width > maxWidth) {
                    let ratio =
                      Math.round((maxWidth / image.width) * 10000, 2) / 10000;
                    image.width = maxWidth;
                    image.height = image.height * ratio;
                  }
                }
                // 最后合成的图片要等于img4广告图片最后的宽度
                scaleImgs(img4, document.body.clientWidth);
                scaleImgs(img3, img4.width);
                
                canvas.width = img4.width;
                canvas.height = img4.height + img3.height;
                // 将 img4（背景图） 加入画布
                context.drawImage(img4, 0, 0, img4.width, img4.height);
                // 将 img3 加入画布
                context.drawImage(img3, 0, img4.height, img3.width, img3.height);

                context.stroke();
                var img5 = new Image(); //实例一个img
                img5.setAttribute("crossOrigin",'Anonymous')
                img5.src = canvas.toDataURL("image/png"); //转换成base64格式路径的png图片
                document.getElementById("result").appendChild(img5);

                // 清除定时器
                clearInterval(timer);
                // 隐藏加载框
                that.loadingShow = false
              }
            }, 50)

          } catch (err) {
            that.msg = '加载失败，请重新进入...'
            //that.err = err
          }
        };
      };
    }
  }
};
</script>

<style scoped>
.van-loading {
  margin-top: 20vh;
}

#result{
  display: flex; 
	justify-content: center; 
}
</style>