<template>
  <div v-show="show">
    <div class="imgDiv" align="center">
      <van-image fit="fill" :src="joinImg" />
    </div>

    <div class="submitForm">
      <ValidationObserver ref="form">
        <!-- 输入我的猎头的号码 -->
        <ValidationProvider rules="mobile" name="telephone" v-slot="{ errors }">
          <van-field
            v-if="$route.query.id"
            v-model.trim="joinForm.bhMobile"
            readonly
            type="tel"
            maxlength="11"
            label="我的猎头"
            placeholder="请输入手机号"
            :error-message="errors[0]"
          />
        </ValidationProvider>

        <!-- 输入手机号码，调起手机号键盘 -->
        <ValidationProvider rules="required|mobile" name="telephone" v-slot="{ errors }">
          <van-field
            autofocus
            v-model.trim="joinForm.telephone"
            required
            clearable
            type="tel"
            maxlength="11"
            label="手机号码："
            placeholder="请输入手机号码"
            :error-message="errors[0]"
          >
            <template #button>
              <sendSmsBtn :telephone="joinForm.telephone"></sendSmsBtn>
            </template>
          </van-field>
        </ValidationProvider>

        <!-- 输入短信验证码 -->
        <ValidationProvider rules="required" name="code">
          <van-field
            v-model.trim="joinForm.code"
            required
            center
            clearable
            type="tel"
            label="短信验证码："
            placeholder="请输入短信验证码"
          ></van-field>
        </ValidationProvider>

        <!-- 输入人员姓名 -->
        <ValidationProvider rules="required" name="name">
          <van-field
            v-model.trim="joinForm.name"
            required
            clearable
            label="人员姓名："
            placeholder="请输入姓名"
          />
        </ValidationProvider>

        <!-- 输入身份证号 -->
        <ValidationProvider rules="required|idCard" name="empid" v-slot="{ errors }">
          <van-field
            v-model.trim="joinForm.empid"
            required
            clearable
            maxlength="18"
            label="身份证号："
            placeholder="请输入身份证号（X需要大写）"
            :error-message="errors[0]"
          />
        </ValidationProvider>

        <!-- 所在地区 -->
        <ValidationProvider rules="required" name="area">
          <van-field
            readonly
            clickable
            required
            label="所在地区："
            :value="joinForm.area"
            placeholder="-请选择-"
            @click="showPicker1 = true"
          />
        </ValidationProvider>
        <van-popup v-model="showPicker1" position="bottom">
          <van-picker
            show-toolbar
            :columns="citys"
            @cancel="showPicker1 = false"
            @confirm="onConfirmCity"
            @change="onChangeCity"
          />
        </van-popup>

        <!-- 职业，加个空的ValidationProvider，因为这个验证器有个Bug，所以统一不显示van-field原来的下划线 -->
        <ValidationProvider>
          <van-field
            readonly
            clickable
            label="职业："
            :value="joinForm.occupation"
            placeholder="-请选择-"
            @click="showPicker2 = true"
          />
        </ValidationProvider>

        <van-popup v-model="showPicker2" position="bottom">
          <van-picker
            show-toolbar
            :columns="jobs"
            @cancel="showPicker2 = false"
            @confirm="onConfirmJob"
          />
        </van-popup>

        <!-- 同意框 -->
        <van-checkbox v-model="checked" shape="square" @click="showJoinDialog">
          <span>我已阅读并知晓加盟须知</span>
        </van-checkbox>

<!-- pid: {{joinForm.pid}} -->

        <div class="btnGroup">
          <van-button type="info" @click="handleJoinForm">提交</van-button>
          <!-- <van-button color="#00CCFF" to="/home">不了，我再逛逛</van-button> -->
        </div>
      </ValidationObserver>
    </div>
  </div>
</template>

<script>
import joinApi from "@/api/join";
import memberApi from "@/api/member";
import Citys from "@/assets/citys";
import { ValidationProvider, ValidationObserver } from "vee-validate";
import SendSmsBtn from "@/components/Common/SendSmsBtn";

export default {
  data() {
    return {
      show: false,
      joinImg: require("@/assets/Images/joinImg.jpg"), // 我要加入图片的地址
      joinForm: {
        // 要传给后台的表单数据
        pid: this.$route.query.id ? this.$route.query.id : '', // 如果根据二维码进入该页面，可以得到猎人ID
        bhMobile: "",
        appid: this.$store.state.hunter.weixinId,
        telephone: "",
        code: "", // 验证码
        name: "",
        empid: "",
        area: "",
        occupation: ""
      },
      showPicker1: false,
      citys: [
        {
          values: Object.keys(Citys),
          className: "cityColumn1"
        },
        {
          values: Citys["北京市"],
          className: "cityColumn2"
          //defaultIndex: 0
        }
      ],
      showPicker2: false,
      jobs: [],
      checked: false,
      empIdDialogShow: false
    };
  },

  components: {
    ValidationProvider,
    ValidationObserver,
    SendSmsBtn
  },

  // 钩子函数获取职业信息
  created() {
    this.initalData();
  },

  mounted() {
    let img = document.getElementsByClassName("van-image")[0].childNodes[0]; //图片
    img.onload = () => {
      this.show = true;
    };
  },

  methods: {
    // 判断用户是否已经注册，无需重复注册；没有注册过，从后台获取职业弹出选择框的数据
    initalData() {
      const registeredId = this.$store.state.hunter.registeredId; // 得到赏金猎人的id
      if (registeredId) {
        // 已注册过，弹出提示框，点击确认回到主页
        this.$dialog
          .alert({
            messageAlign: "center",
            message: `<span style="color:#A9A9A9;font-weight:bold;font-size:0.9rem;">您已加盟，无需再次加盟</span>`,
            showConfirmButton: this.joinForm.pid ? false : true // 二维码进来如果已经注册不需要出现确认按钮
          })
          .then(() => {
            // 点击确认回到首页
            this.$router.push("/home");
          });
      } else {
        // 第一次注册，获取后台维护的职业数据
        joinApi.getJobs().then(response => {
          const resp = response.data;
          if (resp.flag) {
            // 查询成功
            for (const item of resp.data) {
              this.jobs.push(item.code);
            }
          }
        });

        if (this.joinForm.pid) {
          // 通过二维码进来，获取上阶猎人的电话号码
          memberApi.getMemberPersonalInfo(this.joinForm.pid).then(response => {
            const resp = response.data;
            if (resp.flag) {
              this.joinForm.bhMobile = resp.data.telephone;
            } else {
              this.$toast.fail(resp.message);
            }
          });
        }
      }
    },

    onConfirmCity(value) {
      this.joinForm.area = value[0] + " - " + value[1];
      this.showPicker1 = false;
    },
    onChangeCity(picker, values) {
      picker.setColumnValues(1, Citys[values[0]]);
    },

    onConfirmJob(value) {
      this.joinForm.occupation = value;
      this.showPicker2 = false;
    },

    // 加盟须知弹出框
    showJoinDialog() {
      if (!this.checked) {
        this.$dialog.alert({
          title: "加盟须知",
          messageAlign: "left",
          // message: `提交资料成功后你将成为赏金猎人一员，可通过赏金猎人平台为群创光电输送人力，赚取推荐奖金。
          //   推荐人员入职，需对推荐人员进行追踪，人员入职满1个月即可获得推荐奖金。
          //   推荐奖金发放规则：依据招募宣传政策
          //   推荐奖金发放方式：银行卡打款（需进行银行卡绑定）
          //   推荐奖金结算日期：每月1日
          //   推荐奖金发放时间：每月10日
          //   注：被推荐人入职日期在N月1日~31日，入职满一个月后，奖金将于(N+2)月10日进行发放。`.trimMultiSpace()
          message: `如您想加盟成为赏金猎人一员，请您在点击“同意”之前务必审慎阅读、充分理解加盟须知内各项条款内容，确保对其内容及相应的责任已全部知晓并充分理
    一、【加盟注册】
    1.1您进行加盟注册时，应提供有关您本人真实、合法、准确、有效的身份信息及其他相关信息。
1.2为判断或核实您提供的相关实名身份信息是否真实有效，宁波群志光电有限公司（下称“我司”）有权将您提供的实名身份信息提供给公安机关进行整理、保存及比对处理。
1.3加盟注册成功后，您有义务妥善保管其账号及密码，并正确、安全地使用其账号及密码。若您因个人原因导致账号密码遗失、账号被盗等情形而造成相关个人损失，应当由您个人自行承担。
二、【加盟者权利与义务】
2.1加盟注册成功后，您可通过赏金猎人平台向我司推荐人员，您应自行审核被推荐人员之身份证件、学历证件及各种资格、技术技能证件，并保证其真实、合法、有效。遇被推荐人员持有虚假或不实证件或存在其他虚假或不实信息，或存在冒名顶替等情形，不得向我司进行推荐，否则，您应自行承担由此引发的一切责任。
2.2您須向被推荐人员公示我司《员工招聘简章》所规定的录用条件、职位及工作地点等信息，且需做好被推荐人员到我司面试过程中的相关服务工作，确保被推荐人员可顺利至我司面试。
2.3您在推荐人员入职过程中不得有以下行为：
(1)向被推荐人员收取未向其明示的费用或收费超过国家法律、政府机关规定标准；
(2)向被推荐人员收取押金、其它变相押金或其它类似费用；
(3)以我司（含其关联企业）名义向被推荐人员收费；
(4)扣押被推荐人员之身份证件、学历证、资格证、技术技能证及其它证件；
(5)作不利我司（含其关联企业）利益或声誉之宣传；
(6)未据实向被推荐人员传达我司相关讯息，虚假宣传、超越我司的要求内容范围宣传；
(7)对被推荐人员实施欺骗、暴力、胁迫等不当、违法行为；
(8)其它违法、违约行为或明显将增加我司负担的行为。
您若有以上行为，我司有权：
(1)	要求您立即退还多收的各种费用、押金及其它财物予被推荐人；
(2)	取消您赏金猎人资格，且永久禁止其再次加盟注册成为赏金猎人；
(3) 致我司受有财产上或非财产上损害时，我司有权追究您相关责任或要求赔偿我司相关损失。
前述三项，我司可择一主张，亦可同时主张。
三、【推荐奖金发放】
3.1推荐奖金发放条件：若您推荐人员成功入职，当被推荐人在职满1个月后，我司将于次月发放推荐奖金（推荐奖金金额以最新发布政策为准）。
3.2推荐奖金发放方式：以银行卡打款方式进行发放。需您个人进行银行卡信息绑定，为保证推荐奖金可以发放无误，必须保证个人银行卡信息填写正确。
(1)如因您个人填写银行卡信息错误的情况而导致奖金未能正确到账，其相关责任由您自行承担；
(2)如因您个人银行卡更换，银行卡信息未能及时维护而导致奖金未能正确发放，其相关责任由您自行承担；
(3)如因您银行卡等信息填写无误但奖金未能及时到账，可提报个人身份证及银行卡有效信息与我司联系，我司会对该情况进行审核追溯，审核通过后会根据我司相关规定将奖金发放到您账户中。
四、【其他】
我司有权在必要时变更本须知内容，您可在赏金猎人平台相关页面查阅最新版的须知内容。本须知内容变更后，如您继续使用赏金猎人平台，即视为您已接受变更后的须知条款。
本须知最终解释权归宁波群志光电有限公司所有。
`.trimMultiSpace()
        });
      }
    },

    // 验证成功，提交表单
    submitJoinForm() {
      this.$store.dispatch("Join", this.joinForm).then(response => {
        if (response.flag) {
          this.$toast.success(response.message);
          if (this.joinForm.pid) {
            // 通过二维码进来，需要弹出提示框，让人员扫公众号二维码
            this.$dialog.alert({
              messageAlign: "center",
              showConfirmButton: this.joinForm.pid ? false : true, // 二维码进来如果已经注册不需要出现确认按钮
              message: `您已加盟成功
请关注INX赏金猎人公众号
<img src="data:image/jpg;base64,/9j/4AAQSkZJRgABAQEAlgCWAAD/2wBDAAoHBwgHBgoICAgLCgoLDhgQDg0NDh0VFhEYIx8lJCIfIiEmKzcvJik0KSEiMEExNDk7Pj4+JS5ESUM8SDc9Pjv/2wBDAQoLCw4NDhwQEBw7KCIoOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozv/wAARCAB4AHgDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD2aiivIbpNf1/4heJLGHxfeaPZaYqy/KSyKu0Z43DA6mgD16ivG47YzSpFH8aHd3YKqg8knoP9ZWh4XPiDTfiFrPh++8QXmrLbaYZIzISPnOwghcnBGcUAeqUV4Z4Y0n4mavqbW+p6vrmlQLEZBNKGIZgRheo65P5V6h4Z8WDWALTUrT+ydV+Zv7PlkzL5Yxh8YHB/pQB0dFYHjVQ3hyQHxB/YH7xP9O/u89Oo69OteYeMfEuuPpTakdbuvD93bIkUOm+ad18m7/Xg8cHJ7H7vWgD26ivE/C+r6mnj/wAP2a+NJ9bt7yJpLiLzDtjbYx2MMnODW/4o8XeNLm21HS9M8HalAxdo4L+GQ5wG4cAL3A9e9AHptFeJi58R+Ete8Kz6/wCK71rfUf3t3BdMUWDAGVbJOfvY7dK6H4i6rf3uo+FLbQNdmsoNWmdPtFs5wwJTDcEZxk0Ael0V4/eadPp93JaXnxklgniO143JDKfQjzKq6omv6BN4ev7fx7eaxZ6lfpF8pKoy7hnnccjqKAPaqKKKACvJ7GKSfx98Q4YkaSSSw2oijJYmPgAV6xXnGpfD7xP/AMJbqeu6H4li03+0Cu5fJ3HAAGDn6UAeQ6R4P8TRa1YySeH9SVEuI2ZjauAAGGT0r1i3do/jX4kdGKsujggjscR0kfh3x7LdyWcfxHtnuYhmSFYlLoPUjGR1FT+GPB+o2Hi3UrzVvE1pqeo3NgYHjUYkUHbhivpgDt3FAHM+DPi9qy6cNOm0a+16/QtI0scmW2Z9Ap4FWLHxRHqniIePLC1NzeiI2f8AYcL77jaOsuQM7ef7v407UvBeofD7wZDc6Kr3Gum68uW6s4mZ2gbJK7eeOF5xVGzvdH8KaoPGdvph0yMRm0/sR323BJ/5a4b+H8O1AHeeJ/E/h/UdBaCK2tvEkzMpOmW0weQ88nC5Py/Sua/4Sjwv4t0iXULnwnFearZMLWDTDLuuJEGCdoAzgZbt2Nc1rNlcfDjT3+yWcz6tKwni1uBCI4Y3ODEc5GeD/wB9Ck8Ia/oFz8T9Jv7OzTSIEt5FuXmmGJJSjZfJOBnIoA7XQ/Dlpr2j3Vzpfhh/B+rQyBLa6kjJdemWUEDqMr+NXtO8c6nZX0Olav4evoba3Pkz6zcEpC23jzSSuAGIz171ytj4616S61Dw7f30+n3V/cu1hql0FSKCJTkdQNwIUgH/AGhRf+MLnVfFGi+H9Y82DSWVoL6S5wkN/tH+tDYHykgEYPcUAct8VpTcavFcL4og1uCaSV4YoXDC0UkYXIJ9v++a6ib/AI9/hX/vj+cdT23w48LXA1q2h1fR5rjUJP8AiWCOfc1qMnAwG+bjH5Vs698PtQk0Hw4ltrttYTeHomJupEO3Py4YZ6Y296APOPH/AIV8Q3vjvV7m10PUJ4JJ8pJHbOysMDkEDmuh1O0ubDwX8P7W8t5LeePUgHilUqy/vO4Nasdl4rmlWKL4rabJI5CqimMliegA71Fd+FNZvda0+LXviDp109jdxyrbSbVfcCDjHByR/OgD16iiigAryTx/8Vp9I8RxaTpongawul+2NtRhPHgEquc44PtXrdeAeIPC8niL4oeI5y0f2XTClzdIzENJEFUsq4HUgH0oA9A8D2p1bxDqHj9HSGx1e3CRwSf6yPYQpLHpj5CfxFWIdZ8NweOtSvEsTHdizBfVDL+5nUBf3anO3dwOn901UsVGo+AdJXwhcQ6TpcsrrLFqDZZ4SzB1BO7knPesHxR8P7/ULZdE0TW9JtvD8Egmt7aecl0fB3Etgk8s3fvQBra/471LVvh/a694YiuraWW/EJXyllfaN2eMEY4FXta0bwz4i8dDTtW8O3NzdG0D/bi7rFgdF4IGa8w/t7xj8PLkeGdP1K3uIogJv9FhWYfNyeSua6vxJ458VXOmnX/Dt0LTT9ywGwuLdWud/d9uD8vTvQBq6tqFlpfgS6h8aaha+I1F0pWGzlVGCZAUcEHggmuRXRfDPi4DR9B8I3+jX1xzFfXZkMSAfMc8nqAQPqKxtf8ABV/q13DeeGPCWq21lJCpYXC/Mz5JLDJPBGK9Xt9V8VCS01GPSr2LS7OAQ3GmPEn2qeTGN6c42jK9WH3TxQBxHh7wlqnirU1vfGN3E+maI5szHcIYN6AEKVYAcZxyTXTano+h+PdBvraPTm02XRVFpZXl47LEEBwGUg4ZcL1OeorSv/D/AIo8R+CtX0zVb60NxfSK1oGXb5Me5W2vhfvDGO/PesfU9dttT+Euu6TFFKs2hwR2U7OBtd0KqSvPTKnrigDHsvh6ngvQNQ1eW9s7zWFjE2kyW7ksrDOSqnh85HY1W1XWPG+n6VpV54ivZdS0jVELXlnFahXWIY3K52jaSD1yO9dNp3h6TWLXwNrNve2aQaLao1yryfMMqvTHA6d8UvxU8XLpTaTarcLPpd80seowwFWeSL5cgHqpwT3FAHM6Jqvw+Ot6UbbwTqFrLcXUYtbiSVtgfcMMMtg4ODTviD4TudM+Iun+IZLiJ4dS1OFY4lB3Ljb17dqv67Ppl3afD99EikjsYr5WETtuaFN6/fOTjvyTR8SPFFpqvinQ9Igt7gPY6pEzXBUeVJnb91geetAHsNFFFABXmV9axeFvG+rX2tgyWPillsrdbc5cEgKd2cYHPUZr02vLfiJ4w8JSX39n6h9u/tPR5TLbeXH+787aCufUZxQBwfxBuP7J1tPB+xh4f0u4SSJNuZMMoZ/n7/fb/Iro/C/h74YeLb97Ow0/VYnSIyF7iUopAIGAdx55pr6lc/F3Q9L0obDqlncfaL/K+UnlZK/IecnBFdLL4BkiSTRpQo8NachurHbL/pH2gDJ3HHK/M/H0oAzzc+Avhb4qeOGx1Rb3yQhkU+ZGVfBxyw54FXw6yfH5WRgw/snqDmvPm8Q+MPiqraARYnyh9qPyeX93jrz/AHulWvhT9i/tC1GlmQ+IRMRN53+p+yZG/H+3jpQB7Q/iPSba4mtrq5WGSADeXHXgHj1xkUS+JdGjgklW5SURqWIjXJOOw7Z9qwfENnYQapAsej/bJ7jMsru7gLk7e31OR6CsyJ7Ke1nEehusEeDGiXDrnB4fBxg4HJ9MCrfJbTciHPzLm2O2k1rSo2MctwivuCFdpJDHOB068H8q8/8AEt5ok+oa54M0y3uItb1wx75JBiBnCq2c5yOOuB1rbsBHd+Jls/7KeNIyLlpmlk5YDOQeh5J/M1l+LNV0i98ZWtjp/n/8JXp42WPmLi33MoY7j3+Un8ahbFK/U4/SfDWueENYtfDGqTWkmneIpPLuxbsWO1f9ogFfvU7VNF+Hbatc+GtLs9RXWWkNtbySS5hEp4Uk5+7n2rqNJ8EeJl8P+LYtT+x/b9cw8flS/JvyxPbgc1yfw+8Mafper65f+IfN8/wy8cwNu+RlSxPH8X3RQMuaPpkXwrttRi8XMLi31uH7MF0997AAHdnO3HDcV0vhfw5b+ILWxnlIHhm1YT6LC0m2dHDfN5nryD3NcV4p07RfHcuoa54T+0G4tle61L7W2xdm3jYPX5TxVaD/AISL+xPBovvsv9kf2gn2Py/9bnzOd360AfRdFFFABXm3xZRBqHhQ7Fy2rJk468rXpNcLrujX2ga3L4k0uIX6XUgfUEu2DJawqAS8S8HdgH1oAyda8OeE9W8Z6zcRXN+mt6dCt1LEhCwjailf4eR93Iz61F8ONfsPE+s3mrtLKfE01m4mt1UrbBFZQpAPfhc89zUUeh+CfiV4ov77Tde1QXcsavOkI8tQoAX+Jeeg71gfEDQtY8KaPa6Jp9ui6Ot2otr8yAXEsjKxKMVI4yW7dhQB6L4aPjp9QkXxFp2lW9mYGCva/f38YHU8da5X4aeGdP8ADHikWeqPNH4l8mRxCjBofJOMHIHXg963vhxdyaHp58J6tI412BZLl4WJkAjJGDvGR3HGa5Xw54/8M3Wu/wDCWeI757TWBE1t9nt4XaHy+x6E5696APZo3XyxyOByKdvX+8Pzr5+tfiff614lU6vrlzoumeWyn+zlPUZ2nBDHJ711x1rxSLuO3e5ddfkTdp+mBx9nu4P+esjdmwGONw+6OKAPUy64+8PzrgvGnjn/AIQ/xRo0M8cIsLlHe6kMRaVccDbg1iePNevdJ8TaHZajrt9pNjdWRe+Nm2WR+fu8HvgfSuUu/HOr+LEPg3TLCyu4ps21pcSqRM6LyGLMcBiFyeKAOh/sf4e+KY9a8Rx6nrXl27me72ttC7yT8oK9Otc+PEPhDW92l67d3sOl6Z+70uS1jIlmQ/eMpwcn5V7Dqa7zWNP1LSfA+m6XdWNvBpRsFi1y5QjzYAoUZXH3j17GvPPFOg6P4I/4RzxD4fnmv47tmnQXqgqwXaRwADg7uaAN3QvFXw+8F2epzeHrzUJry5tyqJdwlkLgEqDgDjJ5qp8O/Hlq3jW/1DXisc2qCOKFIYiUD5AGBzjtVXTNf1bw7q8XinVdI05NN8RzJubZvEaKfmKKDkHBPWur0K80rTvGt54mu0jTR9faOHSpPKzvcEA/KBlOQeSBQB6xRRRQAV5H4n12x0jxhd6fY6pLe3WtyrY3tpNu2WaOAu6Ptnn3r1yvKtW8TahL441PTtI8DadqtzYOrNcMqiToCGJI6/4UAcXF4Y0PQ/iDqPh+78R3+nQxLGkE8OQ8rsFO07R0+aupn0NvD2rXOm+H7y48T6ysWJrDUXykETAHzVJwNwJUcHPzGrc2q+Mbm6N3P8LrCW4JB81yjPkdDk88YrQ8K+J9R1zxjqGkat4dttI1FbEvJPGQ02CVABb0wQevYUAcZ/wq7xRF4fi1fzL8680/lywfaV4h553bueg4zReaV4d+I3xQFppl15Vh9g3b7WEJ869RggetdFq9lf6Har4f1jW76z0WJxMuvNKTLLIc/uSASccn/vmsTxTp2ja7qn9ofD/Vi2reWqCx09PIygzubPy+ozQBx+t+ErTw5osy6xczWuvCUGCxIDK8BOA5YZGeG4z2q7H8PPiJM0N4lldM4QeVL9sTcqkdAd+QOelev+K9G8PeK/J8NX11FbazLCkquIQ02xcnhiOnB71j6j8TZ7fWrTw/4RsYNdcW+0neUYOmQRyAOi5oAp6fo3hWb4fatHqGvXNykbxpe3c8Zkks5AVyiErnG7jjPWuf1bWdNfxf4VHgZINTubCExBDF5PmuBgFiQuTgE5rpvHWj+G7j7Imsa+fDT3VuJJ7G3j+SViclmCjDEHjJ9Km8J/CLS9J1XTvENlrc90keJogYgFkVl4/Q0Acldap4g0W9v9N8ZWxsLDxNKxklMxlNsgJLeWAT03DjHpWBpvjOLwlqWoWthBBr2nlwlq+oKW2IucFVP3c554HQV6L4h0/R5vD/AI0uE1Y6xdRbiY7hNxsG3H5EJ6enH90VY8PaeqeGvCQtPCWn6jFeQqL66khTdCOPmORz1P5UAcVKPAvieGPUda8U3WnXM3zvYQQsYbZum1BtIA4rckt9N1/T/DWieDrx9WXQ71Z7hmXy2SMvncdwAPOelP0i002y8YePrh9IsriPTofOhglhUou1WOAMcZx2rm9G0rxbrPii28TaRo0unade3ETutlKEi8tWAYYBGRweMetAH0NRRRQAV5PZSyQ+PviHLE7RyJYbldTgqRHwQa9YryG6fX9A+IXiS9h8IXmsWepqsXygqjLtGedpyOooA840fxj4ml1mxjk8QakyPcRqym6cggsOOteuae7x/HTX3jTe66UpVR/EcR8Vhx3JhlSWP4LujowZWA5BHQ/6utfwWuuan8T9S8Qan4fu9JhuLARqJgSNwKDG4gZJwTQBQ+Juo6nrHwut7nVNJfTLttRVTbM24gYbBz71ynh7wla6Oon1rxbN4W1fJH2fZiTyz0OQw4PP5VvfFfS/GOseKWtbC01K50oLE6LEhaIOByR2zya6PTPhQw18at4k1geIMQmPyrq3/LksenP50AVfEek6J4iuY/GFn45bTYbWJbJrm3U8NyfvAg5O7pXM+JdS1fT9BnuLXwOmjMm0LrVuQkmNwG7IAPz9Dz/FU3hzw1r2p+H7nwRe6Jd6XbXN211/aMkRKpjGF28ddvXPerOk6J4wj0e6vtdTUdZt7OfyV0O4Q4u04CuM5wATnofu0AbuteItCtdU8NWPiTSrC6ivNPWSTUL0BjF8uccg5yR6965e80vxSmh6/r6a/qmn2FnJv06CORhFNAzfIUw3C7SMcdMV1Gv+HJdb8feFZbjQmfS0sStzG0e6OE7WIRvocVlW3gjxZ4mk1mwvNcv9J0uK5aG2tZIS0ckOTt2jcPlAAx+FAF65BXwJptuNNSO11ywVtX1gAZhO1T5j/wB8kknk1z2k+E/FsunaodM8R6uLGxiB0owuwS9XnG0bvlHA/Out8Z+C9Zk8DW2n6Xq9wRp1j5ElrDET9uwFAyM8dD69az/D3i/xboXh+x0r/hXupT/ZIVi8zey7sd8bDigDjPCOlazJqPiK+1S/vIbjSoRcX1pIxP20KCTFIc9CBjnPBrW8N+N9c0rW4NRbRJINE1qWO3srcTEQQfMAxjGMdcnoKveG/DHiTxH401bV76G90CzupI5J7SWIst2mfmiJ4yMA9v4q6HUbuS11u10GH4cvdabY3KfZrtf9XFkgl1G3jBJ79qAPRKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooA//Z" />
`            })
          } else {
            // 正常流程走跳转到加盟韩页面
            this.$router.push({
              path: "/home/joinLetter"
              // query: {
              //   back: this.$route.query.toPath // 加盟函点击确认后所需返回的路由地址
              // }
            });
          }
        } else {
          this.$toast.fail(response.message);
        }
      });
    },

    // 处理表单
    handleJoinForm() {
      let that = this;
      this.$refs.form.validate().then(res => {
        if (res) {
          // 验证成功
          if (!that.checked) {
            that.$toast("请阅读加盟须知");
            return;
          }
          if (!that.joinForm.appid) {
            that.$toast("提交失败，没有获取到微信信息");
            return;
          }

          that.submitJoinForm(); // 提交表单
        } else {
          that.$toast("请填写正确信息");
        }
      });
    }
  }
};
</script>

<style scoped>
.van-field {
  border-bottom: 0.2vh solid #ebedf0;
}

.submitForm {
  /* background-color: rgb(255, 255, 255, 0.8); */
  /* height: 50%; */
  padding: 0.5vh 5vw 0 8vw;
  /* border-radius: 20px; */
}
.van-checkbox {
  /* text-decoration: underline; */
  float: right;
  margin: 1.5vh 0 2vh 0;
  font-size: 0.75rem;
}
.btnGroup .van-button {
  display: block;
  width: 65%;
  margin: 1.5vh auto;
}
</style>