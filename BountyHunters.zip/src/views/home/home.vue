<template>
  <div>
     <!-- van-image的fit属性：
        contain	保持宽高缩放图片，使图片的长边能完全显示出来
        cover	保持宽高缩放图片，使图片的短边能完全显示出来，裁剪长边
        fill	拉伸图片，使图片填满元素
        none	保持图片原有尺寸
        scale-down	取none或contain中较小的一个
    -->
    <!-- <h1>欢迎访问赏金猎人</h1> -->
    <!-- 轮播图片 -->
    <div class="imgDiv">
      <van-swipe :autoplay="3000" >
        <van-swipe-item v-for="(image, index) in swipeImgs" :key="index">
          <a :href=image.to>
            <van-image fit="fill" :src=image.url >
              <!-- <template v-slot:loading>
                <van-loading type="spinner" size="20" />
              </template> -->
            </van-image>
          </a>
        </van-swipe-item>
      </van-swipe>
    </div>

    <!-- CODE: {{code}}-->   

    <div class="btnTable">
      <div v-for='img in btnImgs' :key='img.to' @click="$router.push({path: img.to})">
        <van-image fit="scale-down" :src=img.url />
      </div>
      <!-- <div style="display:inline-block;border-radius:51px;width:100px;height:100px;text-align:center;border: 2px solid blue; padding:1.5px;">
        <div style="display:inline-block;background: blue;width:99px;height:99px;border-radius:49px;">金</div>
        </div> -->
    </div>

    <div class="title">
      <van-image fit="scale-down" :src=titleImg.url />
    </div>

    <div class="adsTable">
        <div class="adsRow" v-for='img in adsImgs' :key='img.index'>
          <a :href=img.to>
            <div class='img'>
            <van-image fit="scale-down" :src=img.url />
            </div>
            <div class='content'>
              <h5 v-text="img.content"></h5>
            </div>
          </a>
        </div>
    </div>

  </div>
</template>

<script>
import util from '@/utils/weixin.js'
import homeApi from "@/api/home";

export default {
  data() {
    return {
      //code: '',
      btnImgs: [
        {
          url: require('@/assets/Images/homeIcon1.jpg'),
          to: '/home/join'
        },
        {
          url: require('@/assets/Images/homeIcon2.jpg'),
          to: '/home/recommend'
        },
        {
          url: require('@/assets/Images/homeIcon3.jpg'),
          to: '/home/recruit'
        },
        {
          url: require('@/assets/Images/homeIcon4.jpg'),
          to: '/home/resumes'
        }
      ],
      titleImg: {
        url: require('@/assets/Images/homeTitle.png')
      },
      swipeImgs: [
        {
          index: 0,
          url: '',
          to: ''
        }
      ],
      adsImgs: [],
      loading: false,
      finished: false
    }
  },

  components: {},

  // 钩子函数获取后台图片的base64
  created() {
    //this.code = util.getUrlParam("code")
    this.fetchImgs();
  },
  
  methods: {
    // 获取轮播和广告栏的图片信息
    fetchImgs(){
      const storeSwipeImgs = this.$store.state.hunter.swipeImgs // 得到保存的跑马灯图片
      let swipeLen = storeSwipeImgs.length
      if(swipeLen > 0) this.swipeImgs = storeSwipeImgs

      const storeAdsImgs = this.$store.state.hunter.adsImgs // 得到广告图片
      let adsLen = storeAdsImgs.length
      if(adsLen > 0) this.adsImgs = storeAdsImgs

      if(swipeLen == 0 || adsLen == 0){
        // 如果跑马灯或广告其中有一个为空，去后台查询图片
        homeApi.getHomeImgs("HOME").then(response => {
          const resp = response.data
          if(resp.flag){ // 查询成功
            let tmpSwipeImgs = []
            let tmpAdsImgs = []
            //this.swipeImgs = []
            const imgs = resp.data 

            for(const item of imgs){
              // 遍历图片，修改后台传回的对象属性名
              let imgObj = {
                  index: item.adPosition,
                  url: 'data:image/png;base64,' + item.picCatalog,
                  to: item.jumpWebsite,
                  content: item.adName
              };

              // 优化思路：页面上的图片只后台找一次，找到后保存到vuex，之后直接拿vuex保存的数据
              if(item.adType == "AD"){
                tmpSwipeImgs.push(imgObj)
                //this.swipeImgs.push(imgObj)
              }else if(item.adType == "Information"){
                tmpAdsImgs.push(imgObj) 
                //this.adsImgs.push(imgObj) 
              }
            }

            if(swipeLen == 0){
              // 第一次，vuex需要保存跑马灯图片
              this.swipeImgs = tmpSwipeImgs
              this.$store.dispatch("AddSwipeImgs", tmpSwipeImgs)
            }
            if(adsLen == 0){
              // 第一次，vuex需要保存广告图片
              this.adsImgs = tmpAdsImgs
              this.$store.dispatch("AddAdsImgs", tmpAdsImgs)
            }
          }else{
            // 调用后台失败
            this.$toast.fail(resp.message)
          }
      })
      }

      
    },
  },

}
</script>

<style scoped>
.btnTable{
  display: table;
  width: 95%;
  margin: 1vh auto;
  /* height: 15vh; */
  /* background: green; */
}
.btnTable div{
  display: table-cell;
  vertical-align: middle;
}
.btnTable .van-image{
  display: block;
  margin: 0 auto;
}


.title{
  text-align: center;
}

.adsTable{
  display: table;
  width: 90%;
  margin: 0 auto;
  border-collapse: collapse;
  /* background: yellow; */
}
.adsRow{
  display: table-row;
  /* height: 5vh; */
  border-bottom: 0.2vh solid #ebedf0;
}
.adsRow div{
  display: table-cell;
  padding: 0.5vh 0;
  vertical-align: middle;
}
.adsTable .img{
  /* background: yellow; */
  width:30%;
}
.adsTable .img .van-image{
  max-width: 70%;
  display: block;
  margin: 0 auto;
}
.adsTable .content{
  width:70%;
  text-align: justify;
  /* padding: 0 1vw; */
}

a{
  color: black;
}

.adsTable:after
{
  content : '';
  height : 50px;
  display :block;
}
</style>