<template>
  <div class>
    <div class="submitForm">
      <ValidationObserver ref="form">
        <!-- 持卡人姓名 -->
        <ValidationProvider rules="required">
          <van-field v-model.trim="bankAccountForm.name" readonly maxlength="11" label="持卡人姓名：" />
        </ValidationProvider>

        <!-- 身份证号 -->
        <ValidationProvider rules="required">
          <van-field v-model.trim="bankAccountForm.empid" readonly maxlength="11" label="身份证号：" />
        </ValidationProvider>

        <!-- 银行类别 -->
        <ValidationProvider rules="required">
          <van-field
            readonly
            clickable
            :required="!hasBkAccount"
            label="银行类别："
            :value="bankAccountForm.bktype"
            placeholder="-请选择-"
            @click="showPicker = true"
          />
        </ValidationProvider>
        <van-popup v-model="showPicker" position="bottom">
          <van-picker
            show-toolbar
            :columns="bkoptions"
            @cancel="showPicker = false"
            @confirm="onConfirmBkType"
          />
        </van-popup>

        <!-- 银行卡号 -->
        <ValidationProvider rules="required|bankAccount" name="bkaccount" v-slot="{ errors }" >
          <van-field
            v-model.trim="bankAccountForm.bkaccount"
            clearable
            :required="!hasBkAccount"
            type="tel"
            maxlength="19"
            label="银行卡号："
            placeholder="请绑定持卡人本人的银行卡"
            :error-message="errors[0]"
          />
        </ValidationProvider>

        <!-- 手机号码 -->
        <ValidationProvider rules="required">
          <van-field v-model.trim="bankAccountForm.telephone" readonly maxlength="11" label="手机号码：" >
            <template #button v-if="!hasBkAccount">
              <sendSmsBtn :telephone="bankAccountForm.telephone"></sendSmsBtn>
            </template>
          </van-field>
        </ValidationProvider>

        <!-- 输入短信验证码 -->
        <ValidationProvider rules="required" name="code" v-if="!hasBkAccount">
          <van-field
            v-model.trim="bankAccountForm.code"
            required
            center
            clearable
            type="tel"
            label="短信验证码："
            placeholder="请输入短信验证码"
          ></van-field>
        </ValidationProvider>

        <br />

        <div class="btnGroup">
          <van-button v-if="!hasBkAccount" type="info" @click="submitForm">提交</van-button>
          <van-button v-else type="info" @click="changeBkAccount()">修改银行卡号</van-button>
        </div>
      </ValidationObserver>
    </div>
  </div>
</template>

<script>
import { ValidationProvider, ValidationObserver } from "vee-validate";
import memberApi from "@/api/member";
import SendSmsBtn from "@/components/Common/SendSmsBtn";

export default {
  components: {
    ValidationProvider,
    ValidationObserver,
    SendSmsBtn
  },

  data() {
    return {
      hasBkAccount: true,
      bankAccountForm: {
        id: "",
        name: "",
        empid: "",
        bktype: "",
        bkaccount: "",
        telephone: "",
        code: ""
      },
      showPicker: false,
      bkoptions: [] //银行类别下拉选项
    };
  },

  created() {
    this.fetchBankAccountInfo();
  },

  methods: {
    // 获取绑定银行卡的赏金猎人信息
    fetchBankAccountInfo() {
      const registeredId = this.$store.state.hunter.registeredId; // 得到赏金猎人的id
      if (registeredId) {
        memberApi.getBkAccountInfo(registeredId).then(response => {
          const resp = response.data;
          if (resp.flag) {
            this.bankAccountForm.id = registeredId

            const data = resp.data;
            this.bankAccountForm.name = data.name
            this.bankAccountForm.empid = data.empid
            this.bankAccountForm.bktype = data.bktype
            this.bankAccountForm.bkaccount = data.bkaccount
            this.bankAccountForm.telephone = data.telephone
            this.bkoptions = data.bkoptions

            if(!data.bkaccount) this.hasBkAccount = false
          } else {
            this.$toast.fail(resp.message);
          }
        });
      }
    },

    onConfirmBkType(value) {
      this.bankAccountForm.bktype = value;
      this.showPicker = false;
    },

    // 提交表单
    submitForm() {
      let that = this;
      this.$refs.form.validate().then(res => {
        if (res) {
          // 验证成功
          memberApi.updateBkAccountInfo(that.bankAccountForm).then(response => {
            const resp = response.data;
            if (resp.flag) {
              this.$toast.success(resp.message);
              // 回到会员中心
              this.$router.push({
                path: "/member"
              })
            } else {
              this.$toast.fail(resp.message);
            }
          });
        } else {
          that.$toast("请填写正确信息");
        }
      });
    },

    changeBkAccount(){
      this.hasBkAccount=false
      this.bankAccountForm.bktype = this.bankAccountForm.bkaccount = ""
    }
  }
};
</script>

<style scoped>
/* .van-field:not(.noBorder) {
  border-bottom: 0.5vh solid #f5f5f5;
} */
.van-field {
  border-bottom: 0.2vh solid #f5f5f5;
}


.submitForm {
  margin-top: 5vh;
  padding: 0 8vw;
}

.btnGroup .van-button {
  display: block;
  width: 65%;
  margin: 2vh auto;
}
</style>