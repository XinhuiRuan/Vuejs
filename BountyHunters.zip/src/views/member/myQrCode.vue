<template>
  <div class>
    <div class="commonFont">
      <div class="title">
        <span>想要推荐赏金猎人加盟或寻找可推荐入职人员，可通过分享以下二维码进行操作：</span>
      </div>

      <van-cell
        size="large"
        center
        title="我要推荐赏金猎人"
        label="分享此二维码可推荐人员进行赏金猎人加盟"
        is-link
        arrow-direction="down"
        @click="createQRCode('qrShow1')"
      />

      <van-image :src="qrImg1" v-show='qrShow1'/>

      <van-cell
        size="large"
        center
        title="我要寻找可推荐人员"
        label="分享此二维码可收集有意向求职人员简历"
        is-link
        arrow-direction="down"
        @click="createQRCode('qrShow2')"
      />

      <van-image :src="qrImg2" v-show='qrShow2'/>
    </div>

    <div id="code" v-show="false">
      <canvas id="canvas" v-show="false"></canvas>
    </div> 
  </div>
</template>

<script>
import { ImagePreview } from "vant";
import QRCode from "qrcode"; //引入生成二维码，如果有很多页面使用的话可以在main中引入，挂载在全局；
import vueQr from "vue-qr";

export default {
  components: {
    QRcode: QRCode, //注册生成二维码组件
    vueQr
  },

  data() {
    return {
      logoSrc1: require("@/assets/Images/qrLogo1.jpg"),
      logoSrc2: require("@/assets/Images/qrLogo2.jpg"),
      qrShow1: false,
      qrShow2: false,
      qrImg1: '',
      qrImg2: ''
    };
  },

  methods: {
    // 生成二维码的方法（QRCode版）
    createQRCode(opt) {
      if((opt == 'qrShow1' && this.qrImg1) || (opt == 'qrShow2' && this.qrImg2)){
      // 图片如果已经画过了，则直接显示  
        this[opt] = !this[opt]
        return
      }

      var logoImg = new Image()
      logoImg.setAttribute("crossOrigin", "Anonymous")
      logoImg.src = opt == 'qrShow1' ? this.logoSrc1 : this.logoSrc2
      let page = opt == 'qrShow1' ? 'join' : 'apply'

      // 第一步：加载二维码logo图
      logoImg.onload = () => {
        const registeredId = this.$store.state.hunter.registeredId; // 得到赏金猎人的id
        let url = `http://ngbapp.innolux.com/InnoluxBountyHunters/index.html#/home/${page}?id=${registeredId}`;
        var canvas = document.getElementById("canvas"); //获取到canvas
        QRCode.toCanvas(canvas, url, error => {
          if (error) console.error(error);
        });
        var img1 = new Image();
        img1.setAttribute("crossOrigin", "Anonymous");
        img1.src = canvas.toDataURL("image/png");

        // 第二步：生成二维码
        img1.onload = () => {
          // 第三步：二维码img1加载完成，与logoImg合成生成个人专属二维码qrImg
          var canvas = document.createElement("canvas"),
            context = canvas.getContext("2d");
          canvas.width = img1.width;
          canvas.height = img1.height;
          // 将 img1（二维码） 加入画布
          context.drawImage(img1, 0, 0, img1.width, img1.height);

          // 等比例缩放图片的方法
          function scaleImgs(image, maxWidth) {
            if (image.width > maxWidth) {
              let ratio =
                Math.round((maxWidth / image.width) * 10000, 2) / 10000;
              image.width = maxWidth;
              image.height = image.height * ratio;
            }
          }
          scaleImgs(logoImg, img1.width * 0.4); // 等比例缩小logo
          // 将 logoImg 加入画布(logoImg,离left的距离，离top的距离)
          let left = img1.width * 0.3;
          let top = img1.height * 0.45;
          context.drawImage(logoImg, left, top, logoImg.width, logoImg.height);

          context.stroke();
          var qrImg = new Image(); //实例一个img
          qrImg.setAttribute("crossOrigin", "Anonymous");
          qrImg.src = canvas.toDataURL("image/png"); //转换成base64格式路径的png图片

          if(opt == 'qrShow1'){
            this.qrImg1 = qrImg.src
          }else{
            this.qrImg2 = qrImg.src
          }
          
          qrImg.onload = () => {
            this[opt] = !this[opt]
          }
          
          // 用图片预览方式展示二维码
          // ImagePreview({
          //   images: [qrImg.src],
          //   showIndex: false
          // });
        };
      };
    }

    // showVueQRCode(idx){
    //     var imgs = document.getElementsByTagName("img")
    //     // 用图片预览方式展示二维码
    //     ImagePreview({
    //         images: [imgs[idx].src],
    //         showIndex: false
    //     })
    // }
  }
};
</script>

<style scoped>
.commonFont {
  font-size: 0.8rem;
  text-align: justify;
}

.title {
  width: 82%;
  margin: 4vh auto;
}

.van-cell {
  width: 85%;
  margin: 3vh auto;
  background: rgb(210, 238, 210) !important;
  border-radius: 1em;
}

.van-image{
  max-width: 60%;
  display: block;
  margin: 0 auto;
}
</style>