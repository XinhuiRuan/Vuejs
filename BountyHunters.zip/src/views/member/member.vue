<template>
  <div>
    <div class="selfTable">
      <div class="photoInfo">
        <van-image round width="4rem" height="4rem" :src="selfieUrl" />
      </div>
      <div class="phoneInfo">
        <div class="phoneDiv">
          <div>{{name}}</div>
          <div>{{telephone}}</div>
        </div>
      </div>
    </div>

    <div class="dataTable">
        <div class="dataTd cellBorder">
          <van-icon name="records" size="3rem" />
          <div>
            <span>{{credits}}</span>
          </div>
          <div>
            <span>目前积分</span>
          </div>
          <van-button round type="warning" size="mini">点击签到</van-button>
        </div>
        <div class="dataTd cellBorder">
          <van-icon name="friends-o" size="3rem" />
          <div>
            <span>{{recommend}}/{{entry}}/{{entryOneMonth}}</span>
          </div>
          <div>
            <span>推荐/入职/入职满1月</span>
          </div>
          <van-button round type="warning" size="mini">查看详情</van-button>
        </div>
        <div class="dataTd">
          <van-icon name="balance-o" size="3rem" />
          <div>
            <span>{{bonus}}</span>
          </div>
          <div>
            <span>奖金查看</span>
          </div>
          <van-button round type="warning" size="mini">查看详情</van-button>
        </div>
    </div>

    <!-- 已注册赏金猎人列表 -->
    <div class="listInfo loadingArea" v-if="showCellLink">
      <van-cell icon="user-circle-o" title="我的资料" is-link to="/member/personalInfo">
        <!-- 使用 right-icon 插槽来自定义右侧图标 -->
        <!-- <van-icon
          slot="right-icon"
          name="qr"
          size="20px"
          color="#969799"
          style="line-height: inherit;"
        />
        <van-icon
          size="16px"
          color="#969799"
          slot="right-icon"
          name="arrow"
          style="line-height: inherit;"
        /> -->
      </van-cell>
      <van-cell icon="records" title="推荐记录" />
      <van-cell icon="bar-chart-o" title="猎人排名" />
      <van-cell icon="after-sale" title="提现记录" />
      <van-cell icon="certificate" title="绑定银行卡号" is-link to="/member/bankAccount"/>
      <van-cell icon="edit" title="修改手机号码" />
      <van-cell icon="qr" title="我的二维码" is-link to="/member/myQrCode"/>
    </div>
    <!-- 未注册赏金猎人列表 -->
    <div class="listInfo" v-else>
      <van-cell icon="user-circle-o" title="我的资料" />
      <van-cell icon="records" title="推荐记录" />
      <van-cell icon="bar-chart-o" title="猎人排名" />
      <van-cell icon="after-sale" title="提现记录" />
      <van-cell icon="certificate" title="实名认证" />
      <van-cell icon="edit" title="修改手机号码" />
      <van-cell icon="qr" title="我的二维码" />
    </div>
  </div>
</template>

<script>
import memberApi from "@/api/member";

export default {
  data() {
    return {
      //selfieUrl: "https://img.yzcdn.cn/vant/cat.jpeg",
      selfieUrl: this.$store.state.hunter.weixinSelfie,
      name: this.$store.state.hunter.weixinName,
      telephone: "",
      credits: 0,
      recommend: 0,
      entry: 0,
      entryOneMonth: 0,
      bonus: 0,
      showCellLink: false
    };
  },

  components: {},

  created() {
    this.fetchMemberMainInfo();
  },

  methods: {
    // 后台查询得到在会员中心首页所需要的数据
    fetchMemberMainInfo() {
      const registeredId = this.$store.state.hunter.registeredId; // 得到赏金猎人的id
      if (registeredId) {
        this.showCellLink = true;
        //  只有注册为赏金猎人，才需取后台查询个人信息
        memberApi.getMemberMainInfo(registeredId).then(response => {
          const resp = response.data;
          if (resp.flag) {
            const data = resp.data;
            // this.name = data.name;
            this.telephone = data.telephone;
            this.credits = data.integral;
            this.recommend = data.recommend;
            this.entry = data.entry;
            this.entryOneMonth = data.entryOneMonth;
            this.bonus = data.bonus;

            if(data.isShowBk){
              // 显示提示框：需要绑定银行卡号
              this.$dialog
              .alert({
                messageAlign: "center",
                message: `<span style="color:#A9A9A9;font-weight:bold;font-size:0.9rem;">您已有奖金，请先绑定银行卡号</span>`
              })
            }

          } else {
            this.$toast.fail(resp.message);
          }
        });
      }
    }
  }
};
</script>

<style scoped>
.van-image{
  display: block;
  margin: 0 auto;
}

.selfInfo{
  display: table;
} 
.photoInfo, .phoneInfo {
  height: 17vh;
  display: table-cell;
  vertical-align: middle;
}
.photoInfo {
  width: 30vw;
}
.phoneInfo {
  width: 70vw;
}
.phoneDiv {
  /* width: 50%; */
  /* border-bottom: 0.1vh solid #bbffee; */
  color: #969799;
  font-weight: bold;
  font-size: 0.8rem;
}

.dataTable {
  width: 100%;
  display: table;
  /* border-collapse: collapse; */
  border-collapse: separate;
  border-spacing: 0;
  border-radius: 0.5em;
  background: #3cb371;
}
.dataTd {
  width: 33%;
  display: table-cell;
  /* background: rgba(250, 190, 112, 0.959); */
  /* background:#3CB371; */
  font-family: Arial, Helvetica, sans-serif;
  color: #bbffee;
  font-size: 0.65rem;
  text-align: center;
  vertical-align: middle;
  padding: 2% 0;
}
.dataTd .van-button {
  margin-top: 1%;
}
.cellBorder {
  border-right: 0.1rem solid #faf0e6;
}

.listInfo:after {
  content: "";
  height: 50px;
  display: block;
}
</style>