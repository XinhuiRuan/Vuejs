import request from "@/utils/request"

export default{
    // 校验密码是否正确
    checkPwd(userId, oldPwd){
        return request({
            url: "/user/pwd",
            method: "post",
            data:{
                userId,
                oldPwd
            }
        })
    },

    // 修改密码
    updatePwd(userId, newPwd){
        return request({
            url: "/user/pwd",
            method: "put",
            data:{
                userId,
                newPwd
            }
        })
    }
}