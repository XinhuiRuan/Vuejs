import request from "@/utils/request"

// export default {
//     getList() {
//         const req = request({   
//         // 过程：/db.json -> 通过axios -> /dev-api/db.json -> 通过代理转发(vue.config.js) -> http://localhost:8001/dev-api/db.json
//             url: "/db.json",
//             method: "get"
//         });
//         // console.log(req) // Promise对象，通过它调用then获取响应数据
//         return req;
//     }
// }

// 注意：导出的是普通成员函数
// 登录
export function login(username, password) {
    return request({
        url: "/user/login",
        method: "post",
        data: {
            username,
            password
        }
    })
}

// 获取用户信息
export function getUserInfo(token) {
    return request({
        url: `/user/info/${token}`, // 注意是反单引号 ``
        method: "get"
    })
}

// 退出系统
export function logout(token) {
    return request({
        url: "/user/logout",
        method: 'post',
        data: {
            token
        }
    })
}