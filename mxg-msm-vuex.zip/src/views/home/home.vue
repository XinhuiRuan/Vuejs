<template>
  <div>
    <h1>欢迎访问梦学谷管理系统</h1>
  </div>
</template>

<script>
export default {
  data () {
    return {
    }
  },

  components: {},

  methods: {}
}
</script>

<style scoped>
div{
  text-align: center;
}
</style>