// import * as loginApi from '@/api/login'
// import * as authUtils from '@/utils/auth'
import { login, getUserInfo, logout } from '@/api/login'
import { getToken, setToken, setUser, getUser, removeToken } from '@/utils/auth'

const user = {
    state: {
        token: getToken(), // getToken() 作为token初始值，解决刷新页面之后token为null
        user: getUser() // 是个object
    },

    mutations: {
        SET_TOKEN(state, newToken) {
            state.token = newToken;
            //authUtils.setToken(newToken);
            setToken(newToken);
        },

        SET_USER(state, newUser) {
            state.user = newUser;
            setUser(newUser);
        }
    },

    actions: {
        Login({ commit }, form) {
            // 提交表单给后台进行验证是否正确
            // resolve 触发成功处理，reject 触发异常处理
            return new Promise((resolve, reject) => {
                login(form.username.trim(), form.password).then(response => {
                    const resp = response.data;
                    commit("SET_TOKEN", resp.data.token);
                    resolve(resp);
                }).catch(error => {
                    reject(error);
                })
            })
        },

        // 通过token获取用户信息
        GetUserInfo({ commit, state }) {
            return new Promise((resolve, reject) => {
                // 通过token从后台获得用户信息
                getUserInfo(state.token).then(response => {
                    const resp = response.data;
                    // 第六步：判断是否有得到用户信息
                    if (resp.flag) {
                        // 获取成功，将信息保存到浏览器的 localStorage 中
                        commit("SET_USER", resp.data);
                    }
                    resolve(resp);
                }).catch(error => {
                    reject(error);
                })
            })
        },

        // 退出
        Logout({ commit, state }) {
            return new Promise((resolve, reject) => {
                logout(state.token).then(response => {
                    const resp = response.data;
                    commit('SET_TOKEN', null);
                    commit('SET_USER', null);
                    // 清除本地数据
                    removeToken();
                    resolve(resp);
                }).catch(error => {
                    reject(error);
                })
            })
        }
    }
}

export default user