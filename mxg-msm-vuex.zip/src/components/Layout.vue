<template>
  <div>
    <!-- 头部区域 -->
    <app-header></app-header>
    <!-- 左侧导航区域 -->
    <app-navbar></app-navbar>
    <!-- 右侧主区域 -->
    <app-main>
      
    </app-main>
  </div>
</template>

<script>
import AppHeader from './AppHeader/AppHeader.vue'
import AppNavbar from './AppNavbar/AppNavbar.vue'
import AppMain from './AppMain/AppMain.vue'

export default {
  components: {AppHeader, AppNavbar, AppMain}
}
</script>

<style scoped>
/* 头部区域 */
.header{
  position: absolute;
  line-height: 50px;
  height: 50px;
  top: 0;
  left: 0;
  right: 0;
  padding: 0px;
  background-color: #2d3a4b;
}

/* 左侧导航区域 */
.navbar{
  position: absolute;
  width: 230px;
  top: 50px;
  bottom: 0;
  left: 0;
  overflow-y: auto;
  background-color: #545c64;
}

/* 右侧主区域 */
.main{
  position: absolute;
  left: 230px;
  top: 50px;
  right: 0;
  bottom: 0;
  padding: 10px;
  overflow-y: auto;
  background-color: white;
}
</style>