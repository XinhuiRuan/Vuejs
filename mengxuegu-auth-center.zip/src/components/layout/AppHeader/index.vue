<template>
  <div class="mxg-header">
    <div class="logo">
      <a href="//www.mengxuegu.com" title="梦学谷">
        <img src="@/assets/image/logo.png" alt height="50px" />
      </a>
    </div>
  </div>
</template>

<script>
export default {
  components: {},

  data() {
    return {};
  },

  methods: {}
};
</script>

<style scoped>
.mxg-header {
  width: 100%;
  height: 80px;
  border-top: 3px solid #345dc2;
  z-index: 10;
}

.logo {
  width: 1200px;
  margin: 0 auto; /* 居中 */
  overflow: hidden;
  margin-top: 15px;
}
</style>