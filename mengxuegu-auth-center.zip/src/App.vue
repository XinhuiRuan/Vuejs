<template>
  <div id="app">
    <!-- <img alt="Vue logo" src="./assets/image/logo.png">
    <h1>Hello，梦学谷——陪你学习，伴你梦想</h1>-->
    <router-view></router-view>
  </div>
</template>

<script>
export default {
  name: "App"
};
</script>

<style>
body {
  margin: 0;
  padding: 0px;
  font-family: "微软雅黑";
}
</style>
