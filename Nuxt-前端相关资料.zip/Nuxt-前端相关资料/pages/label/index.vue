<template>
    <div class="label-main">
        <el-row  :gutter="10">
          <el-col v-for="(category, index) in 9" :key="index" :xs="24" :sm="24" :md="6" >
            <el-card shadow="hover">
                <!-- 类别名 -->
                <div slot="header">
                    <span>前端</span>
                </div>
                <!-- 类别下的标签 -->
                <div>
                    <nuxt-link to="/label/html" >
                        <el-tag size="small"> 
                            html
                        </el-tag>
                    </nuxt-link>
                    <nuxt-link to="/label/css" >
                        <el-tag size="small"> 
                            css
                        </el-tag>
                    </nuxt-link>
                    <nuxt-link to="/label/javascript" >
                        <el-tag size="small"> 
                            javascript
                        </el-tag>
                    </nuxt-link>
                    <nuxt-link to="/label/vue.js"  >
                        <el-tag size="small"> 
                            vue.js
                        </el-tag>
                    </nuxt-link>
                    <nuxt-link to="/label/jquery"  >
                        <el-tag size="small"> 
                            jquery
                        </el-tag>
                    </nuxt-link>
                </div>
            </el-card>
          </el-col>
        </el-row>
    </div>
</template>
<script>
export default {
    
    async asyncData() {
        
    },

}
</script>
<style scoped>
.label-main{
    margin: 0 10px;
}
.el-col {
    margin-bottom: 20px;
}
.el-tag {
    margin-right: 5px;
}
.el-tag:hover {
    border-bottom: 1px solid #345DC2;
}
.el-card {
    height: 200px;
}
</style>