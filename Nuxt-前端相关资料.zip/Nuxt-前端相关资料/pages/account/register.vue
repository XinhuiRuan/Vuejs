<template>
    <el-card >
        <el-row type="flex"  justify="center" >
            <h2>注 册</h2>
        </el-row>
        <el-row type="flex"  justify="center">
            <el-form :model="formData" :rules="rules" ref="dataForm" label-width="80px">
                <el-form-item label="你的名字" prop="nickname">
                    <el-input v-model="formData.nickname" placeholder="真实姓名或常用昵称"  style="width:320px" clearable></el-input>
                </el-form-item>
                <el-form-item label="用户名" prop="username">
                    <el-input v-model="formData.username" placeholder="请输入用户名" style="width:320px" clearable>
                    </el-input>
                </el-form-item>
                <el-form-item label="密码" prop="password" >
                    <el-input type="password" placeholder="不少于6位的密码" v-model="formData.password" style="width:320px" clearable></el-input>
                </el-form-item>
                <el-form-item label="确认密码" prop="checkPassword" >
                    <el-input type="password" placeholder="不少于6位的密码" v-model="formData.checkPassword" style="width:320px" clearable></el-input>
                    <el-link type="primary" href="/account/login" >去登录</el-link>
                </el-form-item>
                <el-form-item >
                    <el-button type="primary" @click="submitForm('dataForm')" style="width:320px" >注册</el-button>
                    <br>
                     <el-checkbox  v-model="formData.agreement"> 
                         我同意<nuxt-link to="">《用户使用协议》</nuxt-link>和<nuxt-link to="">《梦学谷隐私政策》</nuxt-link>
                    </el-checkbox>
                </el-form-item>
            </el-form>
        </el-row>
    </el-card>
</template>
<script>

export default {
    data() {
        return {
            formData: {},
            rules: { // 定义表单校验规则

            }
        }
    },
    methods: {
        submitForm(formName) {

        }
    }
}
</script>

<style >
/* 同意协议样式 */
.el-checkbox__input.is-checked+.el-checkbox__label {
    color: #606266;
}
a{
    color: #606266;
}
</style>