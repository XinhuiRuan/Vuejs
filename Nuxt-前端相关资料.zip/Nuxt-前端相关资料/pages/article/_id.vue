<template>
  <div>
    <el-row type="flex">
        <el-col :xs="24" :sm="24" :md="18" >
            <div class="article-left">
                <el-card >
                    <!-- 标题 -->
                    <div class="article-title">
                        <h1>Nuext.js+Vue.js+ElementUI+Axios 梦学谷博客</h1>
                        <div class="article-count">
                            <nuxt-link to="/user/" target="_blank" class="nickname"> 
                                <i class="el-icon-user-solid"></i> 小梦
                            </nuxt-link>
                          	<span>
                              <i class="el-icon-date"></i> 1小时前 
                              <i class="el-icon-thumb"></i> 100 
                              <i class="el-icon-view"></i> 9969 
                          	</span>
                        </div>
                        <el-tag size="small">html</el-tag>
                        <el-tag size="small">css</el-tag>
                        <el-tag size="small">vue.js</el-tag>
                    </div>
                    <!-- 内容 -->
                    <div class="article-content">
                        <div class="markdown-body" >内容区</div>
                    </div>
                  
                  <el-button icon="el-icon-thumb" type="primary" size="medium" plain>赞</el-button>
                </el-card>
								
                <!-- 评论区 -->
              	<div>
                  <h2>评论区</h2>
                  <el-card  >
                    
                  </el-card>
              	</div>
              
              	
            </div>
        </el-col>

        <!-- 右侧-->
        <el-col class="hidden-sm-and-down" :md="6">
            <el-row >
                <el-col>
                    文章目录
                </el-col>
            </el-row>
        </el-col> 
        
    </el-row>
  </div>
</template>

<style scoped>
@import '@/assets/css/blog/article.css'; /* 不要少了分号 */
</style>