import request from '@/utils/requestLeave'

export default {
    // 獲取單據列表  
    postOffFormList(data){
      return request({
        url: `/leave/PostOffFormList`,
        method: 'post',
        data
      })
    },
}