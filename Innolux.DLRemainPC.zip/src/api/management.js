import request from '@/utils/request'

export default{
    // 技能維護 ——> 獲取技能下拉框
    getSkillsOptions(){
      return request({
        url: `/tp/GetSkillsOptions`,
        method: 'get'
      })
    },

    // 技能維護 ——> 新增/上傳技能
    addSkills(data) {
      return request({
        url: `/tp/AddSkills`,
        method: 'post',
        data
      })
    },

    // 技能維護 ——> 刪除技能/專案
    removeById(params) {
        return request({
          url: `/tp/RemoveById`,
          method: 'post',
          data: params
        })
    },

    // 專案維護 ——> 獲取四個下拉框的數據
    getProjectsOptions(){
      return request({
        url: `/tp/GetProjectsOptions`,
        method: 'get'
      })
    },

    // 專案維護 ——> 新增/上傳專案
    addProjects(data) {
      return request({
        url: `/tp/AddProjects`,
        method: 'post',
        data
      })
    },
}