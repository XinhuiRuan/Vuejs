import request from '@/utils/request'
/**
 * 文件上传
 */
// export function fileUpload(fileobj,dir) {
//     let param = new FormData()
//     param.append('files',fileobj.file)
//     if (dir!=undefined) {
//       param.append('dir',dir)
//     }
//     return request({
//       method: 'post',
//       url: '/Utils/Upload',
//       headers: {'Content-Type':'multipart/form-data'},
//       data: param
//     })
// }

export function fileUpload(fileobj, ...items) {
  let param = new FormData()
  param.append('files',fileobj.file)
  for(let item of items){
    for(let prop in item){
      param.append(prop,item[prop])
    }
  }

  return request({
    method: 'post',
    url: '/Utils/Upload',
    headers: {'Content-Type':'multipart/form-data'},
    data: param
  })
}


/**
 * 文件删除
 */
export function DeleteFile(fileName,dir) {
  let param = new FormData()
  param.append('fileName',fileName)
  if (dir!=undefined) {
    param.append('dir',dir)
  }
  return request({
    method: 'post',
    url: '/Utils/DeleteFile',
    data: param
  })
}


/**
 * 文件地址获取
 */
export function GetFiles(dir) {
  return request({
    method: 'get',
    url: '/Utils/GetFiles',
    params: {dir}
  })
}