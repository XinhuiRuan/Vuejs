import request from '@/utils/requestOff'

export default {
    // 獲取班表
    getWorkSchedule(empno, startDate, endDate) {
        return request({
            url: `/dlOff/GetWorkSchedule?empno=${empno}&startDate=${startDate}&endDate=${endDate}`,
            method: 'get',
        })
    },

    // 獲取近期請假和加班信息
    getRecentOffAndOverTime(empno) {
        return request({
            url: `/dlOff/GetRecentOffAndOverTime?empno=${empno}`,
            method: 'get',
        })
    },

    // 得到预提请假单的信息
    getOffFormInfo(formno){
        return request({
            url: `/dlOff/GetOffFormInfo?formno=${formno}`,
            method: 'get',
        })
    },

    // 签核或駁回预提请假单
    handleForm(data) {
        return request({
            url: `/dlOff/PostHandleForm`,
            method: 'post',
            data
        })
    },
}