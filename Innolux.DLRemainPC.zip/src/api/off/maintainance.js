import request from '@/utils/requestOff'

export default{
    // 獲取每月的名額數據
    getMonthlyNumbers(empno, deptno, month){
      return request({
        url: `/dlOff/GetMonthlyNumbers?empno=${empno}&deptno=${deptno}&month=${month}`,
        method: 'get',
      })
    },

    // 提交名額設定表單
    postDayNumber(data){
      return request({
        url: `/dlOff/PostDayNumber`,
        method: 'post',
        data
      })
    },
}