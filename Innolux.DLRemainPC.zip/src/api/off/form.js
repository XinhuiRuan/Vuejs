import request from '@/utils/requestOff'

export default{
    // 获取单据的状态类型
    getFormStatus(){
      return request({
        url: `/dlOff/GetFormStatus`,
        method: 'get',
      })
    },

    // 獲取待簽核單據列表
    getOffFormList(params) {
        return request({
          url: `/dlOff/GetOffFormList`,
          method: 'post',
          data: params
        })
    },
}