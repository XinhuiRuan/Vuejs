/*
 * @Author: your name
 * @Date: 2019-07-31 15:34:37
 * @LastEditTime: 2020-03-14 15:23:58
 * @LastEditors: your name
 * @Description: In User Settings Edit
 * @FilePath: \Innolux.Events.vue\src\api\common.js
 */
import request from '@/utils/request'

/**
 * 
 * @param {string} query 
 * 通過query查詢人員
 */
export function seachUser(query) {
    return request({
      url: '/Common/SeachUser',
      method: 'get',
      params: { query }
    })
  }


  /**
 * 
 * @param {string} query 
 * 通過query查詢部門
 */
export function seachDept(query) {
  return request({
    url: '/Common/SeachDept',
    method: 'get',
    params: { query }
  })
}

/**
 * 獲取ID
 */
export function getNextId() {
    return request({
      url: '/Common/GetNextId',
      method: 'get'
    })
  }