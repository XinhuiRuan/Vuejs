import request from '@/utils/request'

export function getRoutes(token) {
    return request({
      url: '/user/GetRoutes',
      method: 'get',
      params: { token }
    })
  }