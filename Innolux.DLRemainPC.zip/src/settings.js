/*
 * @Author: your name
 * @Date: 2019-07-25 19:24:40
 * @LastEditTime: 2020-05-26 15:45:45
 * @LastEditors: your name
 * @Description: In User Settings Edit
 * @FilePath: \Innolux.Demo.vue\src\settings.js
 */ 
module.exports = {

  title: process.env.VUE_APP_BASE_TITLE,

  /**
   * @type {boolean} true | false
   * @description Whether fix the header
   */
  fixedHeader: false,

  /**
   * @type {boolean} true | false
   * @description Whether show the logo in sidebar
   */
  sidebarLogo: true,
  /**
   * @type {boolean} true | false
   * @description Whether need tagsView
   */
  tagsView: true,
}
