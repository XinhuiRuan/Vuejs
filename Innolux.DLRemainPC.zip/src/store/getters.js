const getters = {
  sidebar: state => state.app.sidebar,
  device: state => state.app.device,
  token: state => state.user.token,
  avatar: state => state.user.avatar,
  empno: state => state.user.empno,
  name: state => state.user.name,
  domainAccount: state => state.user.domainAccount,
  deptno: state => state.user.deptno,
  deptName: state => state.user.deptName,
  routes:state => state.permission.routes,
  staticRoutes:state=>state.permission.staticRoutes,
  roles:state=>state.permission.roles
}
export default getters
