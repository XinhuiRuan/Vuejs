import { login, logout, getInfo } from '@/api/user'
import { getToken, setToken, removeToken } from '@/utils/auth'
import { resetRouter } from '@/router'
import store from '@/store'

const state = {
  token: getToken(),
   empno:'',
   name: '',
  //empno:'18009380',
  //name: '阮鑫辉',
  domainAccount:'',
   deptno:'',
  //deptno:'9M091708',
  deptName:'績效管理課',
  avatar: ''
}

const mutations = {
  SET_TOKEN: (state, token) => {
    state.token = token
  },
  SET_EMPNO: (state, empno) => {
    state.empno = empno
  },
  SET_NAME: (state, name) => {
    state.name = name
  },
  SET_ACCOUNT: (state, domainAccount) => {
    state.domainAccount = domainAccount
  },
  SET_DEPTNAME: (state, deptName) => {
    state.deptName = deptName
  },
  SET_DEPTNO: (state, deptno) => {
    state.deptno = deptno
  },
  SET_AVATAR: (state, avatar) => {
    state.avatar = avatar
  }
}

const actions = {
  // user login
  login({ commit }, userInfo) {
    const { username, password } = userInfo
    return new Promise((resolve, reject) => {
      login({ username: username.trim(), password: password }).then(response => {
        
        commit('SET_TOKEN', response.token)
        setToken(response.token)
        resolve()
      }).catch(error => {
        reject(error)
      })
    })
  },

  // get user info
  getInfo({ commit, state }) {
    return new Promise((resolve, reject) => {
      getInfo(state.token).then(response => {
        const  data  = response

        if (!data) {
          reject('')
        }

        const { empNo,name,domainAccount, avatar,deptNo,briefName } = data
      
        commit('SET_EMPNO', empNo),
        commit('SET_NAME', name),
        commit('SET_ACCOUNT', domainAccount),
        commit('SET_DEPTNO', deptNo),
        commit('SET_DEPTNAME', briefName),
        commit('SET_AVATAR', avatar)
        resolve(data)
      }).catch(error => {
        reject(error)
      })
    })
  },

  // user logout
  logout({ commit, state }) {
    return new Promise((resolve, reject) => {
      logout(state.token).then(() => {
        commit('SET_TOKEN', '')
        commit('SET_EMPNO', '')
        removeToken()
        resetRouter()
        resolve()
      }).catch(error => {
        reject(error)
      })
    })
  },

  // remove token
  resetToken({ commit }) {
    return new Promise(resolve => {
      commit('SET_TOKEN', '')
      removeToken()
      resolve()
    })
  }
}

export default {
  namespaced: true,
  state,
  mutations,
  actions
}

