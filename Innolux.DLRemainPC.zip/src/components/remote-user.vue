<!--
 * @Description: In User Settings Edit
 * @Author: your name
 * @Date: 2019-08-28 17:11:55
 * @LastEditTime: 2019-09-18 15:19:29
 * @LastEditors: Please set LastEditors
 -->
<template>
  <div style="display:inline-block">
    <el-select
      class="el-input-event"
      v-model="person"
      filterable
      remote
      :placeholder="placeholder"
      :remote-method="searh"
      :loading="SearhPerson.loading"
      clearable
      @change="changeInput"
    >
      <el-option
        v-for="item in SearhPerson.options"
        :key="item.value"
        :label="item.label"
        :value="item"
      >
        <span style="float: left">{{ item.label }}</span>
        <span style="float: right; color: #8492a6; font-size: 13px">{{ item.value }}</span>
      </el-option>
    </el-select>
  </div>
</template>

<script>
import { seachUser } from "@api/common.js";
export default {
  name: "remoteUser",
  props: {
    empno:{
        type:String
    },
    name:{
        type:String
    },
    placeholder:{
        type:String,
        default:"工號或賬號或姓名"
    }
  },
  data() {
    return {
      SearhPerson: {
        loading: false,
        options: []
      },
      person:{},
    };
  },
  methods: {
    changeInput(){
        //更新父級empno屬性的值-父子組件雙向綁定的方式
         this.$emit('update:empno', this.person.value)
          this.$emit('update:name', this.person.label)
    },
    async searh(query) {
      if (query != "") {
        this.SearhPerson.loading = true;
        //遠端搜索
        var res = await this._SeachUser(query);
        this.SearhPerson.options = res.rows;
      }
    },
    _SeachUser(query) {
      return new Promise((resolve, reject) => {
        seachUser(query)
          .then(res => {
            this.SearhPerson.loading = false;
            resolve(res);
          })
          .catch(err => {
            this.SearhPerson.loading = false;
            reject(err);
          });
      });
    }
  }
};
</script>

<style lang="scss" scoped>
</style>