<!--
 * @Description: In User Settings Edit
 * @Author: your name
 * @Date: 2019-08-06 19:16:02
 * @LastEditTime: 2019-09-26 19:29:17
 * @LastEditors: Please set LastEditors
 -->
<template>
  <div class="upload-container">
    <el-button 
      class="upload-button"
      :style="{background:color,borderColor:color}"
      icon="el-icon-upload"
      size="mini"
      type="primary"
      @click=" dialogVisible=true"
    >上傳附件</el-button>
    <el-dialog append-to-body :visible.sync="dialogVisible">
      <el-upload
        :multiple="true"
        :file-list="fileList"
        :show-file-list="true"
        :on-remove="handleRemove"
        :on-success="handleSuccess"
        :before-upload="beforeUpload"
        :action="action"
        drag
      >
        <i class="el-icon-upload"></i>
        <div class="el-upload__text">
          将文件拖到此处，或
          <em>点击上传</em>
        </div>
        <div class="el-upload__tip" slot="tip">單個附件不得超出2M</div>
      </el-upload>
    </el-dialog>
  </div>
</template>

<script>
// import { getToken } from 'api/qiniu'

export default {
  name: "UploadFile",
  props: {
    color: {
      type: String,
      default: "#1890ff"
    },
    action: {
      type: String
    }
  },
  data() {
    return {
      dialogVisible: false,
      listObj: {},
      fileList: [],
      files: [],
    };
  },
  methods: {
    checkAllSuccess() {
      return Object.keys(this.listObj).every(
        item => this.listObj[item].hasSuccess
      );
    },
    handleSuccess(response, file) {
      const uid = file.uid;
      const objKeyArr = Object.keys(this.listObj);
      for (let i = 0, len = objKeyArr.length; i < len; i++) {
        if (this.listObj[objKeyArr[i]].uid === uid) {
          this.listObj[objKeyArr[i]].url = response.data.url;
          this.listObj[objKeyArr[i]].hasSuccess = true;
          this.files.push(this.listObj[objKeyArr[i]]);
         this.$emit("changeFiles",this.files)
          return;
        }
      }
    
    },
    handleRemove(file) {
      const uid = file.uid;
      const objKeyArr = Object.keys(this.listObj);
      for (let i = 0, len = objKeyArr.length; i < len; i++) {
        if (this.listObj[objKeyArr[i]].uid === uid) {
          delete this.listObj[objKeyArr[i]];
          break;
        }
      }

       for (let i = 0, len = this.files.length; i < len; i++) {
        if (this.files[i].uid === uid) {
         this.files.splice(i)
         this.$emit("changeFiles",this.files)
          break;
        }
      }
    },
    beforeUpload(file) {
      const _self = this;
      const _URL = window.URL || window.webkitURL;
      const fileName = file.name;
      const fileSize = file.size;
      const fileExtension = file.type;
      if (this.listObj.hasOwnProperty(fileName)) {
        this.$message.warning('名稱相同的文件已存在');
        return false;
      }
      if (fileSize/1024/1024>2) {
         this.$message.warning('上傳文件不能超過2MB');
         return false
      }
      this.listObj[fileName] = {
            hasSuccess: false,
            uid: file.uid,
            fileName,
            fileSize,
            fileExtension
      };
    }
  }
};
</script>

<style lang="scss" scoped>
    .upload-container{
      display: inline-block;
        .upload-button{
            margin: 10px;
        }
    }
    /deep/ .el-upload{
      width: 100%;
    }
    /deep/ .el-upload-dragger{
      width: 100%;
    }
    /deep/ .el-upload-list__item{
      font-size:18px;
    }
</style>
