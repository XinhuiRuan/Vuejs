<!--
 * @Author: your name
 * @Date: 2020-03-14 15:13:23
 * @LastEditTime: 2020-03-14 15:35:23
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \Innolux.Events.vue\src\components\remote-dept.vue
 -->
<template>
  <div style="display:inline-block">
    <el-select
      class="el-input-event"
      v-model="dept"
      filterable
      remote
      :placeholder="placeholder"
      :remote-method="searh"
      :loading="SearhDept.loading"
      clearable
      @change="changeInput"
    >
      <el-option
        v-for="item in SearhDept.options"
        :key="item.value"
        :label="item.label"
        :value="item"
      >
        <span style="float: left">{{ item.label }}</span>
        <span style="float: right; color: #8492a6; font-size: 13px">{{ item.value }}</span>
      </el-option>
    </el-select>
  </div>
</template>

<script>
import { seachDept } from "@api/common.js";
export default {
  name: "remoteDept",
  props: {
    deptno: {
      type: String
    },
    name: {
      type: String
    },
    placeholder: {
      type: String,
      default: "部門名稱或代碼"
    }
  },
  data() {
    return {
      SearhDept: {
        loading: false,
        options: []
      },
      dept: {}
    };
  },
  methods: {
    changeInput() {
      //更新父級empno屬性的值-父子組件雙向綁定的方式
      this.$emit("update:deptno", this.dept.value);
      this.$emit("update:name", this.dept.label);
    },
    async searh(query) {
      if (query != "") {
        this.SearhDept.loading = true;
        //遠端搜索
        var res = await this._SeachDept(query);
        this.SearhDept.options = res.rows;
      }
    },
    _SeachDept(query) {
      return new Promise((resolve, reject) => {
        seachDept(query)
          .then(res => {
            this.SearhDept.loading = false;
            resolve(res);
          })
          .catch(err => {
            this.SearhDept.loading = false;
            reject(err);
          });
      });
    }
  }
};
</script>

<style lang="scss" scoped>
</style>