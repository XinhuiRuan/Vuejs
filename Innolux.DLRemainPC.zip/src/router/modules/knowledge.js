import Layout from '@/layout'
//例子
/* 
const knowledgeRouter = {
  path: '/knowledge',
  component: Layout,
  name: 'Knowledge',
  meta: {
    title: '知识库管理',
    icon: 'example'
  },
  children: [
    {
      path: 'Faq',
      component: () => import('@/views/knowledge/faq/index'),
      name: 'Faq',
      meta: { title: '问题管理', noCache: false, icon: 'table' }
    },
    {
      path: 'ToStudy',
      component: () => import('@/views/knowledge/toStudy/index'),
      name: 'ToStudy',
      meta: { title: '智能学习', noCache: false, icon: 'table' }
    }
  ]
}
export default knowledgeRouter
 */