<!--
 * @Author: your name
 * @Date: 2019-07-25 19:24:40
 * @LastEditTime: 2020-05-26 16:21:58
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \Innolux.Demo.vue\src\views\dashboard\index.vue
--> 
<template>
  <div class="dashboard-container">
    <h1 class="dashboard-text">例子</h1>

    <remoteUser :empno.sync="empno" placeholder="工號或姓名"></remoteUser>
    <remoteDept :deptno.sync="deptno" placeholder="部門名稱或代碼"></remoteDept>

      <div class="dashboard-tinymce-box">
         <!-- 富文本 -->
      <Tinymce v-model="description" height="200" :UploadAction="TinymceUploadAction"></Tinymce>
      </div>
     

  </div>
</template>

<script>
import remoteUser from "@/components/remote-user.vue";
import remoteDept from "@/components/remote-dept.vue";
import Tinymce from "@/components/Tinymce/index";
export default {
  name: "Dashboard",
  components: {
    remoteUser,
    remoteDept,
    Tinymce
  },
  computed: {
     TinymceUploadAction() {
      return `${process.env.VUE_APP_BASE_API}/Utils/AutoUpload?subpath=1\\Tinymce`;
    }
  },
  data() {
    return {
      empno: "",
      deptno: "",
      description:''
    };
  }
};
</script>

<style lang="scss" scoped>
.dashboard {
  &-container {
    margin: 30px;
  }
  &-tinymce-box{
    margin-top: 20px;
  }
}
</style>
