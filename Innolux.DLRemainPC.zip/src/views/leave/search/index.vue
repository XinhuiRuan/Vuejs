<template>
  <div class>
    <div class="query_area">
      <el-form :inline="true" :model="queryParams">
        <el-form-item>
          <remote-dept @update:deptno="handleDept"></remote-dept>
        </el-form-item>
        <el-form-item>
          <el-input v-model="queryParams.empno" placeholder="请输入工號" clearable></el-input>
        </el-form-item>
        <!-- 下拉框 -->
        <el-form-item v-for="selection in Selections" :key="selection.key">
          <el-select v-model="queryParams[selection.key]" clearable :placeholder="selection.value">
            <el-option
              v-for="item in selection.options"
              :key="item.value"
              :label="item.label"
              :value="item.value"
            ></el-option>
          </el-select>
        </el-form-item>
        <br />

        <el-form-item>
          <el-date-picker
            v-model="queryParams.createdDate"
            type="daterange"
            range-separator="至"
            start-placeholder="預提開始日期"
            end-placeholder="預提結束日期"
            value-format="yyyy-MM-dd"
          ></el-date-picker>
        </el-form-item>
        <el-form-item>
          <el-date-picker
            v-model="queryParams.confirmedDate"
            type="daterange"
            range-separator="至"
            start-placeholder="核定開始日期"
            end-placeholder="核定結束日期"
            value-format="yyyy-MM-dd"
          ></el-date-picker>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="getLeaveFormList">查询</el-button>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="exportExcel()">全部導出</el-button>
        </el-form-item>
      </el-form>
    </div>

    <div class="table_area">
      <el-table
        ref="multipleTable"
        :data="signListTable"
        tooltip-effect="dark"
        style="width: 100%"
        highlight-current-row
        border
        @selection-change="handleSelectionChange"
      >
        <!-- <el-table-column type="selection"></el-table-column> -->
        <template v-for="col in tableCols">
          <el-table-column
            :key="col.prop"
            :prop="col.prop"
            :label="col.label"
            show-overflow-tooltip
          ></el-table-column>
        </template>
      </el-table>

      <!-- 按钮区域 -->
      <!-- <div class="btnGroup">
        <export-excel :SelectedRows="multipleSelection" :TableCols="tableCols" excelName="離職预提導出清單"></export-excel>
      </div>-->

      <!-- 分页区域 -->
      <div class="pagination">
        <el-pagination
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          :current-page="queryParams.currentPage"
          :page-sizes="pageSizes"
          :page-size="queryParams.pageSize"
          layout="total, sizes, prev, pager, next, jumper"
          :total="total"
        ></el-pagination>
      </div>

      <!-- 導出用的table -->
      <el-table v-show="false" id="exportTable" :data="multipleSelection">
        <el-table-column
          v-for="col in tableCols"
          :key="col.prop"
          :prop="col.prop"
          :label="col.label"
        ></el-table-column>
      </el-table>
    </div>
  </div>
</template>

<script>
import remoteDept from "@/components/remote-dept";
//import exportExcel from "@/components/ExportExcel";
import FileSaver from "file-saver";
import XLSX from "xlsx";
import SearchApi from "@/api/leave/search";
import store from "@/store";
import FormatDateUtil from "@/utils/formatDate";

export default {
  components: {
    remoteDept,
    //exportExcel
  },

  data() {
    return {
      queryParams: {
        userid: store.state.user.empno,
        name: store.state.user.name,
        empno: "",
        dept: "",
        createdDate: [],
        confirmedDate: [],
        isExcessive: "",
        status: "",
        pageSize: 10, // 每頁顯示的條數
        currentPage: 1
      },
      pageSizes: [10, 20, 50, 100],
      tableCols: [
        // table的欄位信息
        { prop: "empno", label: "工號" },
        { prop: "name", label: "姓名" },
        { prop: "telephone", label: "電話號碼" },
        { prop: "expectDate", label: "期望離職日期" },
        { prop: "reason", label: "離職原因" },
        { prop: "signStatus", label: "簽核状态" },
        { prop: "createdDate", label: "申請離職日期" },
        { prop: "formStatus", label: "單據狀態" },
        { prop: "deptNo", label: "組織代碼" },
        { prop: "deptName", label: "課名稱" },
        { prop: "deptNoCh", label: "廠處名稱" },
        { prop: "signDateLine", label: "團長簽核時間" },
        { prop: "signDateManager", label: "課長簽核時間" },
        { prop: "interview", label: "訪談原因" },
        { prop: "confirmedDate", label: "課長核定離職日期" },
        { prop: "lineName", label: "關愛團長姓名" },
        { prop: "managerName", label: "課長姓名" },
        { prop: "stayDays", label: "距離申請天數" }
      ],
      Selections: [
        // 下拉框的信息
        {
          key: "status",
          value: "單據状态",
          options: [
            { value: "1", label: "離職" },
            { value: "2", label: "不離職" }
          ]
        },
        {
          key: "isExcessive",
          value: "是否超5天簽核",
          options: [
            { value: "N", label: "5天以內" },
            { value: "Y", label: "5天以上" }
          ]
        }
      ],
      total: 0,
      signListTable: [],
      multipleSelection: [],
      selectedFormno: "",
      dialogVisible: false
    };
  },

  created() {
    // 默認核定日期為上月最後一天到當月最後一天
    var d = new Date();
    var d1 = FormatDateUtil.formatDate(d);
    var d2 = new Date(d1.slice(0, 8) + "01");
    d2.setDate(d2.getDate() - 1);
    this.queryParams.confirmedDate.push(FormatDateUtil.formatDate(d2)); // 核定開始日期

    d2.setMonth(d2.getMonth() + 1);
    this.queryParams.confirmedDate.push(FormatDateUtil.formatDate(d2)); // 核定結束日期

    this.getLeaveFormList();
  },

  methods: {
    // 表格單選或多選觸發該事件
    handleSelectionChange(selectedRows) {
      this.multipleSelection = selectedRows;
    },
    // 改變每頁的條數展示
    handleSizeChange(val) {
      this.queryParams.pageSize = val;
      this.getLeaveFormList();
    },
    // 跳轉到其他頁面
    handleCurrentChange(val) {
      this.queryParams.currentPage = val;
      this.getLeaveFormList();
    },

    // 查詢待簽核列表
    getLeaveFormList(action, callback) {
      // 拆解預提查詢日期 和 核定查詢日期
      for (let key in this.queryParams) {
        if (key === "createdDate" || key === "confirmedDate") {
          let date = this.queryParams[key];
          if (date) {
            this.queryParams[key + "From"] = date[0];
            this.queryParams[key + "To"] = date[date.length - 1];
          } else {
            this.queryParams[key + "From"] = this.queryParams[key + "To"] = "";
          }
        }
      }

      let params = this.queryParams;
      if (action === "export") {
        // 如果是導出需要取消分頁內容
        delete params.pageSize;
        delete params.currentPage;
      }

      SearchApi.postOffFormList(params).then(res => {
        if (res.success) {
          let data = res.data;
          if (action === "export") {
            this.multipleSelection = data.rows;
            this.$nextTick(function(){
              callback()
            }
            )
          } else {
            this.total = data.total;
            this.signListTable = data.rows;
          }
        }
      });
    },

    // 获取部门代码
    handleDept(value) {
      this.queryParams.dept = value;
    },
    // 全部導出
    exportExcel() {
      this.getLeaveFormList("export", () => {
        /* generate workbook object from table */
        let wb = XLSX.utils.table_to_book(
          document.querySelector("#exportTable")
        );
        /* get binary string as output */
        let wbout = XLSX.write(wb, {
          bookType: "xlsx",
          bookSST: true,
          type: "array"
        });
        try {
          FileSaver.saveAs(
            new Blob([wbout], { type: "application/octet-stream" }),
            "離職预提導出清單.xlsx"
          );
        } catch (e) {
          if (typeof console !== "undefined") console.log(e, wbout);
        }
        return wbout;
      });
    }
  }
};
</script>

<style scoped>
.query_area {
  width: 96%;
  margin: 2% auto 0 auto;
}
.el-form-item {
  margin-right: 2%;
}

.table_area {
  width: 98%;
  margin: 0 auto;
}
.table_area .btnGroup {
  margin: 1% 1% 1% 0;
  display: inline-block;
}
.table_area .pagination {
  display: inline-block;
}
.pagination {
  margin-top: 1%;
}

/* 重新設置行高度 */
.el-table__header tr,
.el-table__header th {
  padding: 0;
  height: 44px;
}
.el-table__body tr,
.el-table__body td {
  padding: 0;
  height: 44px;
}
</style>