<template>
  <div class>
    <div class="query_area">
      <el-form :inline="true" :model="queryParams">
        <!-- <el-form-item>
          <remote-user></remote-user>
        </el-form-item>-->
        <el-form-item>
          <remote-dept @update:deptno="handleDept"></remote-dept>
        </el-form-item>

        <el-form-item v-for="selection in Selections" :key="selection.key">
          <el-select v-model="queryParams[selection.key]" :placeholder="selection.value">
            <el-option
              v-for="item in selection.options"
              :key="item.value"
              :label="item.label"
              :value="item.value"
            ></el-option>
          </el-select>
        </el-form-item>

        <el-form-item>
          <el-button type="primary" @click="getOffFormList">查询</el-button>
        </el-form-item>
      </el-form>
    </div>

    <div class="table_area">
      <el-table
        ref="multipleTable"
        :data="signListTable"
        tooltip-effect="dark"
        style="width: 100%"
        highlight-current-row
        border
        @selection-change="handleSelectionChange"
        @row-click="handleRowClick"
      >
        <el-table-column type="selection" :selectable="isSelectable"></el-table-column>
        <template v-for="col in tableCols">
          <el-table-column
            :key="col.prop"
            :prop="col.prop"
            :label="col.label"
            show-overflow-tooltip
          ></el-table-column>
        </template>
      </el-table>

      <!-- 按钮区域 -->
      <div class="btnGroup">
        <el-button
          v-if="page === 'sign'"
          :disabled="multipleSelection.length == 0"
          @click="handleForm"
          type="primary"
        >批量簽核</el-button>
        <export-excel
          v-if="page === 'search'"
          :SelectedRows="multipleSelection"
          :TableCols="tableCols"
          excelName="请假预提導出清單"
        ></export-excel>
      </div>

      <!-- 分页区域 -->
      <div class="pagination">
        <el-pagination
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          :current-page="queryParams.currentPage"
          :page-sizes="pageSizes"
          :page-size="queryParams.pageSize"
          layout="total, sizes, prev, pager, next, jumper"
          :total="total"
        ></el-pagination>
      </div>
    </div>

    <!-- 單據詳細信息頁面組件 -->
    <el-dialog :visible.sync="dialogVisible" width="70%" title="預約請假單詳情" center>
      <form-detail :formno="selectedFormno" @getSelectedFormInfo="handleForm"></form-detail>
    </el-dialog>
  </div>
</template>

<script>
// import remoteUser from "@/components/remote-user";
import remoteDept from "@/components/remote-dept";
import exportExcel from "@/components/ExportExcel";
import formDetail from "@/views/off/sign/detail";
import FormApi from "@/api/off/form";
import SignApi from "@/api/off/sign";
import store from "@/store";

export default {
  components: {
    // remoteUser,
    remoteDept,
    exportExcel,
    formDetail
  },

  props: {
    page: {
      default: "sign" // 默认为签核界面
    }
  },

  data() {
    return {
      queryParams: {
        empno: store.state.user.empno,
        name: store.state.user.name,
        dept: "",
        isExcessive: "",
        pageSize: 10, // 每頁顯示的條數
        currentPage: 1,
        currentLength: 0, // 當前已存在列表的數量
        type: "",
        status: ""
      },
      pageSizes: [10, 20, 50],
      tableCols: [
        // table的欄位信息
        { prop: "isExcessive", label: "類別" },
        { prop: "dept_no", label: "組織代碼" },
        { prop: "brief_name", label: "組織單位" },
        { prop: "empno", label: "工號" },
        { prop: "name", label: "姓名" },
        { prop: "startDate", label: "預提開始時間" },
        { prop: "endDate", label: "預提結束時間" },
        { prop: "hours", label: "預提時數" },
        { prop: "status", label: "状态" }
      ],
      Selections: [
        // 下拉框的信息
        {
          key: "isExcessive",
          value: "類別",
          options: [
            { value: "N", label: "名額內" },
            { value: "Y", label: "超额" }
          ]
        },
        { key: "status", value: "單據状态",  options: []}
      ],
      total: 0,
      signListTable: [],
      multipleSelection: [],
      selectedFormno: "",
      dialogVisible: false
    };
  },

  created() {
    if (this.page === "sign") {
      // 签核页面查询框不需要栏位“状态”, table不需要栏位“状态”
      this.Selections.pop();
      this.tableCols.pop();
    } else if (this.page === "search") {
      // 查询页面需要去查询状态的下拉框
      this.getFormStatus();
    }

    this.getOffFormList();
  },

  methods: {
    // 表格單選或多選觸發該事件
    handleSelectionChange(selectedRows) {
      this.multipleSelection = selectedRows;
    },
    // 改變每頁的條數展示
    handleSizeChange(val) {
      this.queryParams.pageSize = val;
      this.getOffFormList();
    },
    // 跳轉到其他頁面
    handleCurrentChange(val) {
      this.queryParams.currentPage = val;
      this.getOffFormList();
    },

    // 签核页面設置TABLE：只有“名額內”的單子才能批量簽核
    isSelectable(row, index) {
      if (this.page === "sign") {
        return row.isExcessive === "名額內";
      } else {
        return true;
      }
    },

    // 當單機一行時觸發，將行單號傳給簽核詳情界面
    handleRowClick(row, column, event) {
      if (this.page === "sign") {
        this.selectedFormno = row.formno;
        this.dialogVisible = true;
      }
    },

    // 获取状态下拉框的数据
    getFormStatus() {
      FormApi.getFormStatus().then(res => {
        if (res.success) {
          let data = res.data;
          let tmpObj = [];
          for (let item of data) {
            tmpObj.push({
              value: item.value,
              label: item.text
            });
          }
          
          this.Selections[1].options = tmpObj;
        //  this.Selections.push (
        //  { key: "status", value: "單據状态",  options: tmpObj})
        }
      });
    },

    // 查詢待簽核列表
    getOffFormList() {
      this.signListTable = [];
      // 后台统一使用currentLength进行查询，而不是currentPage
      this.queryParams.currentLength =
        (this.queryParams.currentPage - 1) * this.queryParams.pageSize;
      this.queryParams.type = this.page;

      FormApi.getOffFormList(this.queryParams).then(res => {
        if (res.success) {
          let data = res.data;
          this.total = data.total;
          this.signListTable = data.rows;
        }
      });
    },

    // 获取部门代码
    handleDept(value) {
      this.queryParams.dept = value
    },

    // 簽核或駁回預提請假單（3 -> 核准；4 -> 駁回）
    handleForm(param, operation = 3) {
      let rows = [];
      let dataType = Object.prototype.toString.call(param);
      if (dataType.indexOf("Object") > 0) {
        // 是子組件傳過來的單子
        rows.push(param);
      } else {
        // 是父組件批量選擇的行
        rows = this.multipleSelection;
      }

      let obj = {
        empno: this.queryParams.empno,
        name: this.queryParams.name,
        operation,
        rows
      };
      // 組裝簽核需要的數據
      SignApi.handleForm(obj).then(res => {
        if (res.success) {
          this.$message({
            message: "操作成功",
            type: "success"
          });
          // 重新查詢數據
          this.dialogVisible = false;
          this.getOffFormList();
        }
      });
    }
  }
};
</script>

<style scoped>
.query_area {
  width: 96%;
  margin: 2% auto 0 auto;
}
.el-form-item {
  margin-right: 2%;
}

.table_area {
  width: 96%;
  margin: 0 auto;
}
.table_area .btnGroup {
  margin: 1% 1% 1% 0;
  display: inline-block;
}
.table_area .pagination {
  display: inline-block;
}
.pagination {
  margin-top: 1%;
}

/* 重新設置行高度 */
.el-table__header tr,
.el-table__header th {
  padding: 0;
  height: 44px;
}
.el-table__body tr,
.el-table__body td {
  padding: 0;
  height: 44px;
}
</style>