<template>
  <div class>
    <div class="info_area">
      <el-form ref="form" :model="formInfo" label-width="80px" size="medium">
        <el-form-item label="員工工號" style="display:inline-block;">
          <el-input readonly v-model="formInfo.empno"></el-input>
        </el-form-item>
        <el-form-item label="員工姓名" style="display:inline-block;">
          <el-input readonly v-model="formInfo.name"></el-input>
        </el-form-item>
        <el-form-item label="組織單位" style="display:inline-block;">
          <el-input readonly v-model="formInfo.brief_name"></el-input>
        </el-form-item>

        <el-form-item label="請假時間">
          <el-col :span="6">
            <el-form-item prop="startDate">
              <el-input readonly v-model="formInfo.startDate"></el-input>
            </el-form-item>
          </el-col>
          <el-col class="line" style="text-align:center" :span="1">~</el-col>
          <el-col :span="6">
            <el-form-item prop="endDate">
              <el-input readonly v-model="formInfo.endDate"></el-input>
            </el-form-item>
          </el-col>

          <el-col :span="5">
            <el-form-item label="假別" style="display:inline-block;">
              <el-input readonly v-model="formInfo.offType"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="5">
            <el-form-item label="時數" style="display:inline-block;">
              <el-input readonly v-model="formInfo.hours"></el-input>
            </el-form-item>
          </el-col>
        </el-form-item>

        <!-- 班表 -->
        <el-form-item>
          <el-tag v-for="tag in scheduleTags" :key="tag.name" :type="tag.type">{{tag.name}}</el-tag>
        </el-form-item>

        <el-form-item label="事由說明">
          <el-col :span="12">
            <el-input
              readonly
              resize="none"
              :autosize="{minRows: 1}"
              type="textarea"
              v-model="formInfo.reason"
            ></el-input>
          </el-col>
        </el-form-item>

        <el-form-item label="意見欄">
          <el-col :span="12">
            <el-input
              resize="none"
              :autosize="{minRows: 3}"
              type="textarea"
              v-model.trim="formInfo.remark"
              maxlength="200"
              show-word-limit
            ></el-input>
          </el-col>
        </el-form-item>
      </el-form>
    </div>

    <!-- 額外信息：折疊面板-->
    <el-collapse v-model="activeNames">
      <!-- 近期請假和加班信息 -->
      <el-collapse-item class="extra_table" name="1">
        <template slot="title">
          <span class="title">近期請假和加班信息</span>
        </template>

        <el-table
          ref="multipleTable"
          :data="recentListTable"
          tooltip-effect="dark"
          style="width: 92%; margin: 0 auto;"
          highlight-current-row
          border
        >
          <template v-for="col in recentTableCols">
            <el-table-column
              :key="col.prop"
              :prop="col.prop"
              :label="col.label"
              show-overflow-tooltip
            ></el-table-column>
          </template>
        </el-table>
      </el-collapse-item>

      <!-- 簽核歷程 -->
      <el-collapse-item class="sign_log" name="2">
        <template slot="title">
          <span class="title">簽核歷程</span>
        </template>

        <el-timeline>
          <el-timeline-item
            v-for="(log,index) in timelinesData"
            :key="index"
            :timestamp="log.headline"
            :icon="log.icon"
            :color="log.color"
            :size="log.size"
            placement="top"
          >
            <el-card v-if="log.content">
              <h4 v-text="log.content"></h4>
            </el-card>
          </el-timeline-item>
        </el-timeline>
      </el-collapse-item>
    </el-collapse>

    <!-- 按鈕區域 -->
    <div slot="footer" class="dialog-footer">
      <!-- 只有超额单子才显示驳回按钮 -->
      <el-button type="danger" @click="onDisagree" v-show="formInfo.isExcessiveId === 'Y'">駁回</el-button>
      <el-button type="primary" @click="onAgree">核准</el-button>
    </div>
  </div>
</template>

<script>
import SignApi from "@/api/off/sign";

export default {
  components: {},

  props: ["formno"],

  data() {
    return {
      formInfo: {},

      scheduleTags: [], // 班表
      recentTableCols: [
        { prop: "oneMonthOff", label: "近一個月請假時數" },
        { prop: "threeMonthOff", label: "近三個月請假時數" },
        { prop: "halfYearOff", label: "近半年請假時數" },
        { prop: "curMonthOver", label: "本月加班時數" },
        { prop: "lastMonthOver", label: "上月加班時數" },
        { prop: "lastLastMonthOver", label: "前兩月加班時數" }
      ],
      recentListTable: [],
      activeNames: ["1"], // 折叠面板的展开页
      timelinesData: [] // 时间线的数据
    };
  },

  created() {
    this.getInitialData();
  },

  watch: {
    // 監控當父組件傳過來的formno改變時，重新查詢初始數據
    formno() {
      this.getInitialData();
    }
  },

  methods: {
    async getInitialData() {
      // 先獲取預提請假單的詳細信息
      await this.getOffFormInfo();
      // 獲取班表
      this.getWorkSchedule();
      // 獲取近期請假和加班信息
      this.getRecentOffAndOverTime();
    },

    // 獲取預提請假單的詳細信息
    getOffFormInfo() {
      return SignApi.getOffFormInfo(this.formno).then(res => {
        if (res.success) {
          let data = res.data;
          this.formInfo = data;
          let tmpArr = [];
          // 组装签核记录的时间线
          for (let log of this.formInfo.signLog) {
            let str = log.title + " " + log.status;

            tmpArr.push({
              content: log.content,
              headline: log.date ? str + "於 " + log.date : str,
              color: log.date ? "#0bbd87" : ""
              // icon: log.date ? 'el-icon-check' : ''
            });
          }

          this.timelinesData = tmpArr;
        }
      });
    },

    // 獲取班表
    getWorkSchedule() {
      SignApi.getWorkSchedule(
        this.formInfo.empno,
        this.formInfo.startDate,
        this.formInfo.endDate
      ).then(res => {
        if (res.success) {
          let data = res.data;
          let tmpArr = [];
          for (let item of data) {
            // 組裝顯示的額班表格式
            let dateArr = item.datetime.split("-");
            let name = dateArr[1] + "-" + dateArr[2] + " " + item.datecode;
            tmpArr.push({
              name,
              type: item.datecode === "GEDA" ? "" : "danger"
            });
          }

          this.scheduleTags = tmpArr;
        }
      });
    },

    // 獲取近期請假和加班信息
    getRecentOffAndOverTime() {
      SignApi.getRecentOffAndOverTime(this.formInfo.empno).then(res => {
        if (res.success) {
          let data = res.data;
          this.recentListTable = [data];
        }
      });
    },

    // 核准
    onAgree() {
      this.$emit("getSelectedFormInfo", this.formInfo, 3);
    },

    // 駁回
    onDisagree() {
      // 卡控
      if (!this.formInfo.remark) {
        this.$message({
          message: "意見欄不能為空",
          type: "warning"
        });
        return;
      }

      this.$confirm("確認駁回單據嗎?", "確認提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      })
        .then(() => {
          // confirm 駁回單據
          this.$emit("getSelectedFormInfo", this.formInfo, 4);
        })
        .catch(() => {});
    }
  }
};
</script>

<style scoped>
.el-collapse {
  margin-top: 2%;
}
.el-collapse-item .title {
  font-weight: bold;
  color: #606266;
}
/* .el-timeline-item__timestamp{
font-weight: bold;
color:rgb(104, 63, 63);
} */

.dialog-footer {
  margin-top: 2%;
  text-align: right;
}

.el-tag {
  margin-right: 1%;
}
</style>