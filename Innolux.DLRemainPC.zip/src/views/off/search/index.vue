<template>
  <div class>
    <!-- 引入签核界面的组件 -->
    <sign-component :page="page"></sign-component>
  </div>
</template>

<script>
import signComponent from "@/views/off/sign";

export default {
  components: {
    signComponent
  },

  data() {
    return {
      page: 'search'
    };
  },

  methods: {},
};
</script>

<style scoped>

</style>