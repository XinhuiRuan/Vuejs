<template>
  <div class>
    <!-- 信息區域 -->
    <el-form
      ref="form"
      :model="formInfo"
      label-width="120px"
      size="medium"
      class="info-form"
      inline
    >
      <el-form-item label="組織編號">
        <el-input readonly v-model="formInfo.deptName"></el-input>
      </el-form-item>
      <el-form-item label="管控比例">
        <el-input readonly v-model="formInfo.rate"></el-input>
      </el-form-item>
      <el-form-item label="最大可設定名額">
        <el-input readonly v-model="formInfo.monthlyMaxTotal"></el-input>
      </el-form-item>
      <el-form-item label="當前設定名額">
        <el-input readonly v-model="formInfo.monthlyCurTotal"></el-input>
      </el-form-item>
      <el-form-item label="剩餘可申請名額">
        <el-input readonly v-model="formInfo.monthlyLeft"></el-input>
      </el-form-item>
      <el-form-item style="margin-left: 4%;">
        <el-button type="primary" v-show="calendarData.length > 0" @click="onSubmit">提交名額</el-button>
      </el-form-item>
    </el-form>

    <el-calendar>
      <template slot="dateCell" slot-scope="{date, data}">
        <!--自定义内容-->
        <!-- 日期區域 -->
        <div>{{ data.day.split('-').slice(1).join('-') }}</div>
        <!-- 名額數量區域 -->
        <div
          class="content"
          v-for="(item,index) in calendarData"
          :key="index"
          @click="showDialog(data.day)"
        >
          <div v-if="(item.months).indexOf(data.day.split('-').slice(1)[0]) != -1">
            <div v-if="(item.days).indexOf(data.day.split('-').slice(2).join('-'))!=-1">
              <div>
                <span>剩餘名額：{{item.content[data.day.split('-').slice(2).join('-')]["left"]}}</span>
              </div>
              <div>
                <span>設定名額：{{item.content[data.day.split('-').slice(2).join('-')]["total"]}}</span>
              </div>
            </div>
            <div v-else></div>
          </div>
          <div v-else></div>
        </div>
      </template>
    </el-calendar>

    <!-- 彈出框（名額設定） -->
    <el-dialog title="名額設定" :visible.sync="dialogFormVisible" width="25%" center>
      <!-- 表單區域 -->
      <el-form ref="form" :model="numberForm" label-width="80px" class="dialog-form">
        <el-form-item label="當前日期">
          <el-input disabled v-model="numberForm.date"></el-input>
        </el-form-item>
        <el-form-item label="剩餘名額">
          <el-input disabled v-model="numberForm.left"></el-input>
        </el-form-item>
        <el-form-item label="總共名額">
          <el-input v-model.trim="numberForm.total" autocomplete="off"></el-input>
        </el-form-item>
      </el-form>
      <!-- 按鈕區域 -->
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialogFormVisible = false">取 消</el-button>
        <el-button type="primary" @click="onChange">确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import MaintainanceApi from "@/api/off/maintainance";
import store from "@/store";
import FormatDateUtil from "@/utils/formatDate";

export default {
  components: {},

  data() {
    return {
      curMonth: new Date(),
      formInfo: {
        deptName: store.state.user.deptName,
        rate: "",
        monthlyCurTotal: "",
        monthlyMaxTotal: "",
        monthlyLeft: ""
      },
      calendarData: [
        // {
        //   months: ["09", "10"], //当前月
        //   days: ["11", "12", "13"], //天
        //   content: "已有名額/總共名額：23/47"
        // }
      ],
      dialogFormVisible: false,
      numberForm: {
        date: "",
        left: 0,
        total: 0
      },
      preTotal: null // 記錄修改之前的值
      //   isChanged: false // 記錄是否修改過數據
    };
  },

  created() {
    // 剛進入頁面，查詢今天的數據
    this.getMonthlyNumbers(new Date());

    // 在 上个月、今天、下个月 这三个按钮上添加点击事件
    // function confirmJump(date){
    //   if (this.isChanged) {
    //       this.$confirm("確認不提交最新總共名額，前往其他月份嗎？", "提示", {
    //         confirmButtonText: "确定",
    //         cancelButtonText: "取消",
    //         type: "warning"
    //       }).then(() => {
    //         this.getMonthlyNumbers(date);
    //         this.isChanged = false // 初始為未改變
    //       });
    //   }else{
    //     // 沒有改變，直接跳轉
    //     this.getMonthlyNumbers(date);
    //   }
    // }

    this.$nextTick(() => {
      // 点击前一个月
      let prevBtn = document.querySelector(
        ".el-calendar__button-group .el-button-group>button:nth-child(1)"
      );
      prevBtn.addEventListener("click", e => {
        let d = new Date(this.curMonth);
        d.setMonth(d.getMonth() - 1);
        this.getMonthlyNumbers(d);
        //confirmJump.call(this,d);
      });

      //点击下一个月
      let nextBtn = document.querySelector(
        ".el-calendar__button-group .el-button-group>button:nth-child(3)"
      );
      nextBtn.addEventListener("click", e => {
        let d = new Date(this.curMonth);
        d.setMonth(d.getMonth() + 1);
        this.getMonthlyNumbers(d);
        //confirmJump.call(this,d);
      });

      //点击今天
      let todayBtn = document.querySelector(
        ".el-calendar__button-group .el-button-group>button:nth-child(2)"
      );
      todayBtn.addEventListener("click", e => {
        this.getMonthlyNumbers(new Date());
        //confirmJump.call(this,new Date());
      });
    });
  },

  // http://www.manongjc.com/detail/19-ejuiftzsjarsfjx.html

  methods: {
    // 根據月份獲取當月的數據，date為Datetime格式
    getMonthlyNumbers(date) {
      let dateArr = FormatDateUtil.formatDate(date).split("-");
      let year = dateArr[0];
      let month = dateArr[1];
      this.curMonth = year + "-" + month;

      let empno = store.state.user.empno;
      let deptno = store.state.user.deptno;

      MaintainanceApi.getMonthlyNumbers(empno, deptno, this.curMonth).then(
        res => {
          this.calendarData = []
          if (res.success) {
            let data = res.data;
            this.formInfo.rate = data.rate;
            this.formInfo.monthlyCurTotal = data.monthlyCurTotal;
            this.formInfo.monthlyMaxTotal = data.monthlyMaxTotal;
            this.formInfo.monthlyLeft = data.monthlyLeft;

            let days = []; // 記錄當前月日期的數組
            let content = {}; // 記錄內容
            for (let item of data.rows) {
              let day = item.date.substr(item.date.length - 2);
              days.push(day);
              content[day] = {
                // 屬性名為 dd
                left: item.left, // 剩餘名額
                total: item.total // 設定名額
              };
            }

            this.calendarData = [
              {
                months: [month],
                days,
                content
              }
            ];
          }else{
            this.$message({
              message: res.message,
              type: "warning"
            });
          }

          // 修改日曆的標題
          // let title = document.querySelector(
          //   ".el-calendar__header .el-calendar__title"
          // );
          // title.innerText = `${year} 年 ${month} 月 ${store.state.user.deptName} 管控比例${this.rate}（已有名額：${this.monthlyUsed}；總共名額：${this.monthlyTotal}）`;
        }
       
      );
    },

    // 彈出名額設定的表單
    showDialog(day) {
      let item = this.calendarData[0].content[day.substr(day.length - 2)];
      // 只有剩餘名額大於0，才能再編輯
      // if (item.left - 0 > 0) {
      this.dialogFormVisible = true;
      // 給彈出框內表單賦初始值
      this.numberForm.date = day;
      this.numberForm.left = item.left;
      this.numberForm.total = item.total;
      this.preTotal = item.total;
      // } else {
      //   this.$message({
      //     message: "已不存在剩餘名額，不能進行編輯",
      //     type: "warning"
      //   });
      // }
    },

    // 彈出框表單確認修改名額
    onChange() {
      let diff = this.numberForm.total - this.preTotal;
      if (diff === 0) {
        this.dialogFormVisible = false;
        return;
      }

      if (!/(^[0-9]\d*$)/.test(this.numberForm.total)) {
        this.$message({
          message: "修改失敗，總設定名額需要輸入正整數",
          type: "warning"
        });
        return false;
      }

      if (this.numberForm.total - 0 < this.preTotal - this.numberForm.left) {
        this.$message({
          message: "修改失敗，總設定名額不能小於已預約名額",
          type: "warning"
        });
        return false;
      }

      let day = this.numberForm.date.substr(this.numberForm.date.length - 2);
      this.calendarData[0].content[day].left += diff;
      this.calendarData[0].content[day].total = this.numberForm.total;
      this.formInfo.monthlyCurTotal += diff; // 這個月總設定名額需要同步修改
      this.formInfo.monthlyLeft += diff;
      this.dialogFormVisible = false;
      // this.isChanged = true // 記錄被修改過
    },

    // 提交名額設定的表單
    onSubmit() {
      if (this.formInfo.monthlyCurTotal > this.formInfo.monthlyMaxTotal) {
        this.$message({
          message: "修改失敗，當前設定名額不能大於最大可設定名額",
          type: "warning"
        });
        return false;
      }

      // 處理每日名額的數據
      let rows = [];
      for (let day in this.calendarData[0].content) {
        let item = this.calendarData[0].content[day];
        rows.push({
          date: this.curMonth + "-" + day,
          left: item.left,
          total: item.total
        });
      }

      let obj = {
        month: this.curMonth,
        empno: store.state.user.empno,
        deptno: store.state.user.deptno,
        monthlyCurTotal: this.formInfo.monthlyCurTotal,
        monthlyLeft: this.formInfo.monthlyLeft,
        rows
      };
      MaintainanceApi.postDayNumber(obj).then(data => {
        this.dialogFormVisible = false;
        this.$message({
          message: "修改成功",
          type: "success"
        });
        // 重新查數據
        this.getMonthlyNumbers(new Date(this.curMonth));
      });
    }
  }
};
</script>

<style>
.info-form {
  margin-top: 1%;
}

.is-selected {
  color: #1989fa;
}

.content {
  margin-top: 6%;
}

.dialog-form {
  width: 90%;
  margin: 0 auto;
}

/* 取消灰色日期的默認點擊事件 */
.el-calendar-table:not(.is-range) td.next,
.el-calendar-table:not(.is-range) td.prev {
  pointer-events: none;
}

.disabledDate {
  pointer-events: none;
}
</style>