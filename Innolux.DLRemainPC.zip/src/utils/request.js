import axios from 'axios'
import { MessageBox, Message } from 'element-ui'
import store from '@/store'
import router from '@/router'
import { getToken } from '@/utils/auth'

// 按需导入 ElementUI 组件 实现Loading加载数据和异常统一处理
// import { Loading} from 'element-ui';

// // 加载数据时打开和关闭动效对象
// const loading = {
//   // 注意：loadingInstance 实例采用单例模式创建，防止响应异常时频繁切换路由时加载动效重复创建
//   loadingInstance : null, // Loading实例

//   open(){ // 打开加载
//       //console.log('加载中', this.loadingInstance);
//       if(this.loadingInstance === null) { // 创建单例, 防止切换路由重复加载
//           this.loadingInstance = Loading.service({
//               text: "拼命加载中...",
//               //target: '.main', // 效果显示区域, div.main在AppMain.vue文件中
//               target: '.loadingArea',
//               // background: 'rgba(0, 0, 0, 0.5)' // 遮罩背景色
//           })
//       }
//   },

//   close(){ // 关闭加载
//       if(this.loadingInstance !== null) {
//           this.loadingInstance.close();
//       }
//       this.loadingInstance = null // 关闭后实例重新赋值null, 下次让它重新创建
//   }
// }

const service = axios.create({
  baseURL: process.env.VUE_APP_BASE_API
 // timeout: 15000// 请求超时时间
})

// 请求拦截器
service.interceptors.request.use(
  config => {
   // loading.open(); //打开加载效果
    // 在请求发送之前做一些处理
    if (store.getters.token) {
      // let each request carry token
      // ['X-Token'] is a custom headers key
      // please modify it according to the actual situation
      config.headers['X-Token'] = getToken()
    }
    return config
  },
  error => {
    // 发送失败
    //console.log(error)
   // loading.close(); //关闭加载效果
    Promise.reject(error)
  }
)
// 响应拦截器
service.interceptors.response.use(
response => {
  //loading.close(); //关闭加载效果
  if (response.headers && (response.headers['content-type'] === 'application/x-msdownload' || response.headers['content-type'] === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')) {
    return response.data
  }
  // dataAxios 是 axios 返回数据中的 data（不需要）
  const dataAxios = response.data
  // 这个状态码是和后端约定的
  const { code } = dataAxios
  // 根据 code 进行判断
  if (code >1000) {
      //后台设定了1000以上的为自定义的异常
      //1001,Token相关验证失败
      if (code==1001) {
        store.dispatch('user/resetToken').then(() => {
          location.reload()
        })
      }
      else
      return Promise.reject(dataAxios)
  }
   else {
    return dataAxios.data
  }
},
error => {
  //loading.close(); //关闭加载效果
   // 判断请求超时
if (error.code === 'ECONNABORTED' && error.message.indexOf('timeout') !== -1) {
    error.message="请求超时请重试";
}
if (error.message.indexOf('Network Error') !== -1) {
  error.message="网络错误";
}
  if (error && error.response) {
    switch (error.response.status) {
      case 400: error.message = '请求错误'; break
      case 401: error.message = '未授权，请登录'; break
      case 403: error.message = '拒绝访问'; break
      case 404: error.message = `请求地址出错: ${error.response.config.url}`; break
      case 408: error.message = '请求超时'; break
      case 500: error.message = '服务器内部错误'; break
      case 501: error.message = '服务未实现'; break
      case 502: error.message = '网关错误'; break
      case 503: error.message = '服务不可用'; break
      case 504: error.message = '网关超时'; break
      case 505: error.message = 'HTTP版本不受支持'; break
      default: break
    }
  }
  return Promise.reject(error)
}
)
export default service
