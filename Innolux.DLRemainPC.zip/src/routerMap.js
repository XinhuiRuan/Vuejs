import Layout from '@/layout'

//動態路由-例子
/* export default  {
    '/knowledge':Layout,
    '/knowledge/Faq':()=>import('@/views/knowledge/faq/index'),
    '/knowledge/ToStudy':()=>import('@/views/knowledge/toStudy/index')
} */