(function (Vue) {
	const STORAGE_KEY = 'items_vuejs';
	// 用于本地存储、提取数据
	const ItemsStorage= {
		// 提取数据
		fetch: function(){
			// 获取JSON字符串，转为数组
			return JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
		},

		// 存储数据
		save: function(value){
			// 以JSON格式存储
			localStorage.setItem(STORAGE_KEY, JSON.stringify(value));
		}
	}

	const items = [
		{
			id: 1,
			content: 'vue.js',
			completed: false //是否完成
		},
		{
			id: 2,
			content: 'java',
			completed: true
		},
		{
			id: 3,
			 content: 'pyhton',
			completed: false
		}
	];

	var vm = new Vue({
		el: "#todoapp",
		data: {
			//items,
			items: ItemsStorage.fetch(),
			currentIndex: null,
			filterStatus: null
		},

		methods:{
			addItem(event){
				var content = event.target.value.trim();
				if(!content){
					return;
				}
				var id = this.items.length + 1;
				this.items.push({
					id,
					content,
					completed: false
				})
				event.target.value = null;
			},

			clearCompleted(){
				this.items = this.items.filter((item)=>{
					return !item.completed;
				});
			},

			destory(index){
				this.items.splice(index,1);
			},

			toEditing(index){
				this.currentIndex = index;
				//this.items[index].isEditing = true;
			},
			cancelEdit(){
				this.currentIndex = null;
				//this.items[index].isEditing = true;
			},
			finishEdit(item, index,$event){
				var val = $event.target.value.trim();
				if(!val){
					this.items.splice(index, 1);
					return;
				}else{
					item.content = val;
				}
				this.currentIndex = null;
			}
		},

		computed: {
			remaining(){
				var remainItems = this.items.filter((item)=>{
					return !item.completed;
				})
				return remainItems.length;
			},

			toggleAll: {
				get(){
					return !this.remaining;
				},

				set(newValue){
					this.items.forEach((item)=>{
						item.completed = newValue;
					})
				}
			},

			filterItems(){
				switch(this.filterStatus){
					case "active":
						return this.items.filter(item => !item.completed);
						break;
					case "completed":
						return this.items.filter(item => item.completed);
						break;
					default:
						return this.items;
						break;
				}
			}
		},

		watch:{
			items: {
				deep: true,
				handler: function(newValue, oldValue){
					ItemsStorage.save(newValue);
				}
			}
		},

		directives: {
			'focus': { // 指令名，
				// 刷新页面自动获取焦点
				inserted: function (el, binding) {
					//被 v-focus 作用的那个元素在刷新页面后会自动 获取焦点
					el.focus();
				},
				// 用于编辑时的input，因为元素有更新
				update:function (el, binding) {
					//被 v-focus 作用的那个元素在刷新页面后会自动 获取焦点
					// 只有双击的那个元素才能获取焦点
					if(binding.value){
						el.focus();
					}
				}
			}
		}
	})

	//地址路由发生改变触发事件
	window.onhashchange = function(){
		var hash = window.location.hash.substr(2).trim();
		vm.filterStatus = hash || "all";
	}

	window.onhashchange();
})(Vue);
