<template>
  <h1>{{ msg }}</h1>
</template>

<script>
  export default {
    data: () => ({ msg: 'hi' })
  }
</script>

<style>
h1 { color: red }
</style>
