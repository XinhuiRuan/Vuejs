  import router from './index'
  import store from '../store'
  import axios from "axios"
  
  // 全局守卫
  router.beforeEach((to, from, next) => {
    const { user, token} = store.state
    const { requiredLogin } = to.meta

    if(!user.isLogin){
      // 未登入
      if(token){
        axios.defaults.headers.common.Authorization = `Bearer ${token}`
        store.dispatch('fetchCurrentUser').then(() => {
          if(to.name === 'login'){
            next('/')
          }else{
            next()
          }
        }).catch((e) => {
          console.log(e)
          store.dispatch('logout')
          next('/login')
        })

      }else{
        if(requiredLogin){
          // 需要登入才能访问的页面
          next('/login')
        }else{
          next()
        }
      }
    }else{
      // 已登入
      if(to.name === 'login'){
        next('/')
      }else{
        next()
      }
    }
  })
