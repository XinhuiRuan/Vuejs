import { createStore } from 'vuex';
import axios from 'axios'

export interface ResponseType<T = {}> {
    code: number;
    msg: string;
    data: T;
}
export interface UserProps {
    isLogin: boolean;
    _id?: string;
    nickName?: string;
    column?: string;
    email?: string;
}
export interface ImageProps {
    _id?: string;
    url?: string;
    createdAt?: string;
}
export interface ColumnProps {
    _id?: string;
    title?: string;
    avatar?: ImageProps;
    description?: string;
}
export interface PostProps {
    _id: string;
    title: string;
    excerpt: string;
    image?: ImageProps | string;
    createdAt: string;
    column: string;
    author?: string;
}
export interface GlobalDataProps {
    token: string;
    loading: boolean;
    columns: ColumnProps[];
    columnById: ColumnProps;
    posts: PostProps[];
    user: UserProps;
    error: GlobalErrorProps;
}
export interface GlobalErrorProps {
    status: boolean;
    message?: string;
}

const getAndCommit = async (url: string, mutationName: string, commit: any) => {
    const resp = await axios.get(url)
    const data = 'list' in resp.data.data ? resp.data.data.list : resp.data.data
    commit(mutationName, data)
    return data
}
const postAndCommit = async (url: string, mutationName: string, commit: any, params?: any) => {
    const resp = await axios.post(url, { params })
    if (resp) {
        commit(mutationName, resp.data.data)
        return resp.data.data
    }
}

const store = createStore<GlobalDataProps>({
    state: {
        token: localStorage.getItem('token') || '',
        loading: false,
        columns: [],
        columnById: {},
        posts: [],
        user: {
            isLogin: true,
            nickName: 'Xinhui',
            column: '5f3e86d62c56ee13bb83096c'
        },
        // user: {
        //     isLogin: false
        // },
        error: {
            status: false,
        }
    },

    getters: {
        // getColumnById: (state) => {
        //     return (id: string) => {
        //         return state.columns.find(c => c._id === id)
        //     }
        // },
        // getPostsByCid: (state) => {
        //     return (id: string) => {
        //         return state.posts.filter(post => post.column === id)
        //     }
        // }
    },

    mutations: {
        SET_TOKEN(state, rowData) {
            state.token = rowData
            if (rowData) {
                // 设置默认token
                axios.defaults.headers.common.Authorization = `Bearer ${rowData}`
                // 本地存储token
                localStorage.setItem('token', rowData)
            } else {
                // 本地删除token
                localStorage.removeItem('token')
                delete axios.defaults.headers.common.Authorization
            }
        },
        SET_USER(state, rowData) {
            state.user = {
                isLogin: true,
                ...rowData
            }
        },
        SET_LOADING(state, status) {
            state.loading = status
        },
        SET_COLUMNS(state, rowData) {
            state.columns = rowData
        },
        SET_COLUMN(state, rowData) {
            state.columnById = rowData
        },
        SET_POSTS(state, newPost) {
            state.posts.push(newPost)
        },
        SET_ERROR(state, error: GlobalErrorProps) {
            state.error = error
        }
    },

    actions: {
        // 登入
        login({ commit, }, params) {
            return postAndCommit(`/user/login`, 'SET_TOKEN', commit, params)
        },
        // 获取用户信息
        fetchCurrentUser({ commit }) {
            return postAndCommit(`/user/current`, 'SET_USER', commit)
        },
        // 登出
        logout({ commit }) {
            commit('SET_TOKEN', '')
        },

        // 获得专栏列表
        fetchColumns(context) {
            // axios.get('/colmuns').then(resp => {
            //     context.commit('SET_COLUMNS', resp.data.data.list)
            // })
            return getAndCommit('/colmuns', 'SET_COLUMNS', context.commit)
        },

        // 获得一个专栏详情
        fetchColumn({ commit }, cid) {
            return getAndCommit(`/column?cid=${cid}`, 'SET_COLUMN', commit)
        },

        // 获得属于专栏的文章列表
        fetchPosts({ commit }, cid) {
            return getAndCommit(`/column/posts?cid=${cid}`, 'SET_POSTS', commit)
        },

        // 新建一篇新文章
        createPost({ commit }, newPost){
            debugger
            return postAndCommit(`/post`, 'SET_POSTS', commit, newPost)
        }
    }
})

export default store