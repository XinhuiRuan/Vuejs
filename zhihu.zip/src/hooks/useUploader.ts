interface CheckCondition {
    formats?: string[];
    size?: number;
}
type ErrorType = 'size' | 'format' | null

// 文件上传之前的通用检查函数
export const BeforeUploadCheck =  (file: File, condition: CheckCondition) => {
    const { formats, size } = condition
    const isValidFormat = formats ? formats.includes(file.type) : true
    const isValidSize = size ? (file.size / 1024 / 1024) < size : true

    let error: ErrorType = null
    if (!isValidFormat) error = 'format'
    if (!isValidSize) error = 'size'

    return {
        passed: isValidFormat && isValidSize,
        error
    }
};