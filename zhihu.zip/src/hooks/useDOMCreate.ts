import { onUnmounted } from "vue";

function useDOMCreate(nodeId: string){
    // 动态将组件添加到index.html文件
    const node = document.createElement('div')
    node.id = nodeId
    document.body.appendChild(node)

    // 需要动态去掉dom节点 
    onUnmounted(() => {
        document.body.removeChild(node)
    })
}

export default useDOMCreate