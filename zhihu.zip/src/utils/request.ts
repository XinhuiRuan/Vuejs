import axios from 'axios'
import store from '../store'

axios.defaults.baseURL = 'http://mengxuegu.com:7300/mock/5fe99cba5b350029c77c9d1a/zhihu'

// 请求拦截器
axios.interceptors.request.use(config => {
    // Do something before request is sent
    store.commit('SET_LOADING', true)
    store.commit('SET_ERROR', { status: false })
    return config;
}, error => {
    // Do something with request error
    return Promise.reject(error);
});

// 响应拦截器
axios.interceptors.response.use(response => {
    // Do something before response is sent
    store.commit('SET_LOADING', false)
    return response;
}, e => {
    // Do something with response error
    const {error} = e.response.data
    store.commit('SET_ERROR', {
        status: true,
        message: error
    })
    store.commit('SET_LOADING', false)
    return Promise.reject(error);
});