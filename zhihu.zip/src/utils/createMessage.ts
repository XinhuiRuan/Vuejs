import { createApp } from 'vue'
import Message from '../components/Message.vue'
type MessageType = "success" | "error" | "default";

const createMessage = (message: string, type: MessageType, timeout = 2000) => {
    // 用js创建一个组件
    const messageInstance = createApp(Message, {
        message,
        type
    })

    // 挂载
    const mountNode = document.createElement('div')
    document.body.appendChild(mountNode)
    messageInstance.mount(mountNode)
    setTimeout(() => {
        messageInstance.unmount(mountNode)
        document.body.removeChild(mountNode)
    }, timeout)
}

export default createMessage