<template>
  <div>
    <validate-form @form-submit="onFormSubmit">
      <div class="mb-3">
        <label for="exampleInputEmail1" class="form-label">邮箱地址</label>
        <validate-input :rules="emailRules" v-model="emailVal" type="text" placeholder="请输入邮箱地址"></validate-input>
      </div>
      <div class="mb-3">
        <label for="exampleInputEmail1" class="form-label">密码</label>
        <validate-input
          :rules="passwordRules"
          v-model="passwordVal"
          type="password"
          placeholder="请输入密码"
        ></validate-input>
      </div>

      <!-- <template #submit>
        <span class="btn btn-danger">Submit</span>
      </template>-->
    </validate-form>
  </div>
</template>

<script lang="ts">
import { defineComponent, ref } from "vue";
// 特别注意这个是 useRouter 而不是 useRoute，差一个字母，作用千差万别，那个是获得路由信息，这个是定义路由的一系列行为
import { useRouter } from "vue-router";
import { useStore } from "vuex";
import ValidateInput, { RulesProp } from "../components/ValidateInput.vue";
import ValidateForm from "../components/ValidateForm.vue";
import CreateMessage from "../utils/createMessage"

export default defineComponent({
  name: "Login",
  components: {
    ValidateInput,
    ValidateForm
  },

  setup() {
    // 邮箱
    const emailRules: RulesProp = [
      { type: "required", message: "电子邮箱地址不能为空" },
      { type: "email", message: "请输入正确的电子邮箱格式" }
    ];
    const emailVal = ref();

    // 密码
    const passwordRules: RulesProp = [
      { type: "required", message: "密码不能为空" }
    ];
    const passwordVal = ref();

    // 获取路由
    const router = useRouter();
    const store = useStore();
    const onFormSubmit = (result: boolean) => {
      if (result) {
        const params = {
          email: emailVal.value,
          paddword: passwordVal.value
        };
        store.dispatch("login", params).then(() => {
          // router.push方法跳转到另外一个url，它接受的参数和router-link的to里面的参数是完全一致的，其实router link内部和这个router分享的是一段代码       
         store.dispatch("fetchCurrentUser", params).then(() => {
            CreateMessage('登入成功', 'success')
            setTimeout(() => {
              router.push("/");
            }, 2000)
          })
        }).catch(err => {
          console.log(err)
        })
      }
    };

    return {
      emailRules,
      emailVal,
      passwordRules,
      passwordVal,
      onFormSubmit
    };
  }
});
</script>

<style>
</style>