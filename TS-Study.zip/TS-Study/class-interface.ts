interface IRadio{
    switchRadio(trigger: boolean): void
}

interface IBattery{
    checkBatteryStatus(): void
}

interface IRadioWithBattery extends IRadio{
    checkBatteryStatus(): void
}


class Car implements IRadio{
    switchRadio(trigger: boolean){

    }
}

// class Cellphone implements IRadio,IBattery {
//     switchRadio(trigger: boolean){
        
//     }
//     checkBatteryStatus(){

//     }
// }
class Cellphone implements IRadioWithBattery {
    switchRadio(trigger: boolean){
        
    }
    checkBatteryStatus(){

    }
}