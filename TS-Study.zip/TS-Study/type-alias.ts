// type alias
let sum: (x: number, y:number) => number
const result = sum(1,2)

type PlusType = (x: number, y:number) => number
let sum2: PlusType
const result2 = sum2(2,3)

type StrOrNum = string | number
let result3: StrOrNum = '123'
result3 = 456


// 字面量
const str: 'name' = 'name'
type Directions = 'UP' | 'DOWN' | 'LEFT' | 'RIGHT'
let toWhere: Directions = 'LEFT'


// 交叉類型
interface IName{
    name: string
}
type IPerson = IName & {age: number}
let person: IPerson = {
    name: '123',
    age:28
}