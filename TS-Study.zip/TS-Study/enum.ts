// 数字枚举
enum Direction{
    Up = 10, // 不写10，默认为0
    Down,
    Left,
    Right
}

console.log(Direction.Up) // 0
console.log(Direction[11]) // Down


// 字符串枚举
enum Direction2{
    Up = 'up', 
    Down = 'down',
    Left = 'left',
    Right = 'right'
}
let value = 'up'
if(value === Direction2.Up){
    console.log('go up')
}


// 常量枚举 (提升性能)
const enum Direction3{
    Up = 'up', 
    Down = 'down',
    Left = 'left',
    Right = 'right'
}
let value3 = 'up'
if(value3 === Direction3.Up){
    console.log('go up')
}