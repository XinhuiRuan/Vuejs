interface IPerson{
    name: string
    age?: number // ?表示可选属性
    readonly sex: string // 只读属性
}

let people: IPerson = {
    name: 'Ruan',
    age: 28,
    sex: 'male'
}
