function add1(x: number, y: number, z?: number): number{
    return x + y
}
let result1 = add1(2, 5)

let add2 = (x: number, y: number, z?: number): number => {
    return x + y
}
let add3: (x: number, y: number, z?: number) => number = add2


interface ISum{
    (x: number, y: number, z?: number): number
}
let add4: ISum = add2