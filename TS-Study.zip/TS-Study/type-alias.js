var sum;
// const result = sum(1,2)
console.log(sum);
