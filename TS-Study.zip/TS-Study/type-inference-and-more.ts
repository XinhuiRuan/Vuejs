let str = 'str'

let numOrStr: number | string 
numOrStr = 'abc'
numOrStr = 123
numOrStr.toString()
// numOrStr.length // 会报错，必须是number和string都具有的方法

function getLength(input: number | string): number {
    const str = input as string // 类型断言
    if(str.length){
        return str.length
    }else{
        const number = input as number
        return number.toString().length
    }   
}

// type guard
function getLength2(input: number | string): number {
    if(typeof input === 'string'){
        return input.length
    }else{
        return input.toString().length
    }
}