let age: number = 18

let firstName: string = 'Ruan'

let fullName: string = `Hello, ${firstName}`

let arrOfNums: number[] = [1,2,3]

let user: [string, number] = ['ruan', 26]
user.push(123)
