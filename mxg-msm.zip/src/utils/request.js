import axios from "axios"

// 学习理解路线：
// 第一步：不封装axios对象，直接异步请求数据
// axios.get('/db.json').then(response => {
//     console.log("get1", response.data);
// }).catch(error => {
//     console.log(error);
// })


// 第二步：手动创建一个axios对象, 用于设置相关属性和拦截器，参考: https://github.com/axios/axios#creating-an-instance
const request = axios.create({
    // 请求配置参考: https://github.com/axios/axios#request-config
    // 根据不同环境设置 baseURL, 最终发送请求时的URL为: baseURL + 发送请求时写URL ,
    // 比如设置baseURL: '/dev-api'， 使用request.get('/test')时, 最终发送请求是: /dev-api/test
    //baseURL: '/', // 默认是 /

    //baseURL: '/dev-api',
    // 使用根目录下的 .env.development 与 .env.production 中配置 VUE_APP_BASE_API
    baseURL: process.env.VUE_APP_BASE_API, 

    timeout: 5000 // 请求超时，设置5000ms
})

// 发送请求后设置拦截器（之后实现具体功能）
// Add a request interceptor
request.interceptors.request.use(function (config) {
    // Do something before request is sent
    return config;
}, function (error) {
    // Do something with request error
    return Promise.reject(error);
});

// 接收请求前设置拦截器（之后实现具体功能）
// Add a response interceptor
request.interceptors.response.use(function (response) {
    // Do something with response data
    return response;
}, function (error) {
    // Do something with response error
    return Promise.reject(error);
});


// 自己封装好axios之后，接着去api/test.js下接着看代码
export default request // 导出 axios 对象