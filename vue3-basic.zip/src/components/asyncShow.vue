<template>
  <div class>
      {{result}}
  </div>
</template>

<script>
import { defineComponent } from "vue";

export default defineComponent({
    setup(){
        return new Promise((resolve) => {
            setTimeout(() => {
                resolve({
                    result: 42
                })
            }, 3000)
        })
    }
})
</script>

<style scoped>

</style>