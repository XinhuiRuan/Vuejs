import { ref } from "vue";
import axios from 'axios';

// 添加一个参数作为要使用的地址
function useUrlLoader<T>(url: string){
    // 声明几个ref，代表不同的状态和结果
    const result = ref<T | null>(null)
    const loading = ref(true)
    const loaded = ref(false)
    const error = ref(null)

    axios.get(url)
    .then(resp => {
        loading.value = false
        loaded.value = true
        result.value = resp.data
    })
    .catch(err => {
        error.value = err
        loading.value = false
    })

    return {
        result,
        loading,
        loaded,
        error
    }
}

export default useUrlLoader

