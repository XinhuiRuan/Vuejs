<template>
  <div id="app">
    <!-- <img alt="Vue logo" src="./assets/logo.png" /> -->
    <!-- <HelloWorld msg="Welcome to Your Vue.js + TypeScript App"/> -->
    <h1>{{count}}</h1>
    <h2>{{double}}</h2>
   
    <Suspense>
      <template #default>
        <!-- 展示异步回调的结果，等两个都传回结果了才显示 -->
        <div>
          <async-show />
          <dog-show />
        </div>     
      </template>
      <template #fallback>
        <!-- 展示异步回调还没结果时的内容 -->
        <h2>Loading！...</h2>
      </template>
    </Suspense>

    <h3>距离X轴：{{x}}  距离Y轴：{{y}}</h3>
    <modal :isOpen = "modalIsOpen" @close-modal="onModalClose"> My Modal Is Open</modal>
    <button @click="onModalOpen">Open Modal</button><br>
    <ul>
      <li v-for="number in numbers" :key="number">
        <h3>{{number}}</h3>
      </li>
    </ul>
    <h1>person：{{person.name}}</h1>
    <button @click="increase">+1</button><br>
    <h3 v-if="loading">Loading!...</h3>
    <!-- <img v-if="loaded" :src="result.message" alt=""> -->
    <img v-if="loaded" :src="result[0].url" alt="">
  </div>
</template>

<script lang="ts">
//import HelloWorld from './components/HelloWorld.vue';
import UseMousePosition from './hooks/useMousePosition';
import UseUrlLoader from './hooks/useUrlLoader';
import modal from './components/modal.vue';
import asyncShow from './components/asyncShow.vue';
import dogShow from './components/dogShow.vue';
import { defineComponent, ref, computed, reactive, toRefs, onMounted, onUpdated,onUnmounted, onRenderTriggered, onRenderTracked,onErrorCaptured,watch } from "vue";

interface DataProps {
  count: number;
  double: number;
  increase: () => void;
  numbers: number[];
  person: { name?: string };
}

export default defineComponent({
  name: "App",
  components:{modal, asyncShow, dogShow},
  setup() {
    /* 生成响应式对象方法一：ref的妙用和使用computed */
    // const count = ref(0)
    // const double = computed(() => {
    //   return count.value * 2
    // })
    // const increase = () => {
    //   count.value++
    // }

    // return {
    //   count,
    //   increase,
    //   double
    // }

    /* 生成响应式对象方法二：使用reactive进行改造 */
    const data: DataProps = reactive({
      count: 0,
      double: computed(() => {
        return data.count * 2;
      }),
      increase: () => {
        data.count++
      },
      // 测试vue2的bug被vue3修复
      numbers: [1, 2, 3],
      person: {}
    });
    data.numbers[0] = 5;
    data.person.name = "Ruan";

    const refData = toRefs(data);


    /* 使用生命周期函数 */
    // onMounted(() => {
    //   console.log('mounted')
    // })
    // onUpdated(() => {
    //   console.log('updated')
    // })
    // // 重新render时记录哪些值发生变化
    // onRenderTriggered((event) => {
    //   console.log('onRenderTriggered',event)
    // })
    // onRenderTracked((hook) => {
    //   console.log('onRenderTracked', hook)
    // })


    /* 使用watch侦测变化，侦测的必须是响应式对象 */
    // watch(data, (newValue, oldValue) => {
          // 由于data不是响应式对象，所以oldValue和newValue都为同一值
    //   console.log('data - oldValue', oldValue)
    //   console.log('data - newValue：', newValue)
    // })
    // watch(refData.count, (newValue, oldValue) => {
    //   console.log('refData.count - oldValue', oldValue)
    //   console.log('refData.count - newValue：', newValue)  
    // })
    //const greetings = ref('Hello!')
    // watch 多个值，返回的也是多个值的数组
    // watch([greetings, data], (newValue, oldValue) => {
    //   console.log('oldValue', oldValue)
    //   console.log('newValue：', newValue)  
    //   document.title = 'updated' + greetings.value + data.count
    // })
    // 除了使用refData，也可以使用getter的写法watch reactive对象中的一项
    // watch([greetings, () => data.count], (newValue, oldValue) => {
    //   console.log('oldValue', oldValue)
    //   console.log('newValue：', newValue)  
    //   document.title = 'updated' + greetings.value + data.count
    // })


    /* 模块化开发：第一部分 —— 鼠标追踪器 */
    // 将组件内逻辑抽象成可复用的函数
    const {x, y} = UseMousePosition()
    // 使用TS的泛型改造
    interface DogResult{
      message: string;
      status: string;
    }
    // const {result,loading,loaded} = UseUrlLoader<DogResult>('https://dog.ceo/api/breeds/image/random')
    // watch(result, () => {
    //   if(result.value){
    //     console.log("value",result.value.message)
    //   }
    // })

    interface CatResult{
      id: string;
      url: string;
      width: string;
      height: string;
    }
    const {result,loading,loaded} = UseUrlLoader<CatResult[]>('https://api.thecatapi.com/v1/images/search?limit=1')
    watch(result, () => {
      if(result.value){
        console.log("value",result.value[0].url)
      }
    })

    /* Teleport - 瞬间移动 */
    const modalIsOpen = ref(false)
    const onModalOpen = () => {
      modalIsOpen.value = true
    }
    const onModalClose = () => {
      modalIsOpen.value = false
    }

    return {
      ...refData,
      x,
      y,
      result,
      loading,
      loaded,
      modalIsOpen,
      onModalOpen,
      onModalClose
    };
  },

  
});
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
