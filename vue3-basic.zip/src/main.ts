import { createApp } from 'vue'
import App from './App.vue'

// Vue3的全局API修改：app就是一个App的实例，现在再设置任何的配置是在不同的app实例上面的，不会像vue2 一样发生任何的冲突
const app = createApp(App)

// app.config.isCustomElement = tag => tag.startsWith('app-')
// app.use(/* ... */)
// app.mixin(/* ... */)
// app.component(/* ... */)
// app.directive(/* ... */)
// app.config.globalProperties.customProperty = () => {}

// 当配置结束以后，我们再把App使用mount方法挂载到固定的DOM的节点上
app.mount('#app')
