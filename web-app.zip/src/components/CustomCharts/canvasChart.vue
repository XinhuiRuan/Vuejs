<template>
  <div>
    <canvas
      id="myCanvas"
      width="300"
      height="300"
    ></canvas>
  </div>
</template>

<script>
export default {
  data() {
    return {};
  },

  components: {},

  mounted() {
    this.drawCanvas();
  },

  methods: {
    drawCanvas() {
      var canvas = document.getElementById("myCanvas");
      if (!canvas.getContext) return; // 处理浏览器不兼容canvas的情况
      var context = canvas.getContext("2d");

      // 给画布设置背景图
      var img = new Image();
      img.src = require("@/assets/test_image/bg.png");
      img.onload = function () {
        var axis_margin = 35,
          // 设置坐标轴相关的初始值
          axis_origin = {
            x: axis_margin, // left的值
            y: canvas.height - axis_margin, // right的值
          },
          xAxis_end = {
            x: axis_margin + img.width,
            y: canvas.height - axis_margin,
          },
          yAxis_end = {
            x: axis_margin,
            y: canvas.height - axis_margin - img.height,
          },
          // 设置刻度相关的初始值
          xAxis_tick_width = 100,
          yAxis_tick_width = 50,
          xAxis_tick_count = img.width / xAxis_tick_width,
          yAxis_tick_count = img.height / yAxis_tick_width;

        context.strokeStyle = "black";
        context.lineWidth = 1.0;

        /*绘制x轴*/
        context.beginPath();
        context.moveTo(axis_origin.x, axis_origin.y); // 起点
        context.lineTo(xAxis_end.x, xAxis_end.y);
        context.stroke();
        /*绘制x轴上的刻度线*/
        for (let i = 1; i < xAxis_tick_count; ++i) {
          context.beginPath();
          context.moveTo(axis_origin.x + i * xAxis_tick_width, axis_origin.y);
          context.lineTo(
            axis_origin.x + i * xAxis_tick_width,
            axis_origin.y + 10
          );
          context.stroke();
        }
        /*绘制x轴上的刻度字*/
        context.fillStyle = "blue";
        context.font = "12pt Calibri";
        context.textAlign = "center";
        context.textBaseline = "top";
        for (let j = 0; j <= xAxis_tick_count; ++j) {
          context.fillText(
            j * xAxis_tick_width,
            axis_origin.x + j * xAxis_tick_width,
            axis_origin.y + 10
          );
        }

        /*绘制y轴*/
        context.beginPath();
        context.moveTo(axis_origin.x, axis_origin.y); // 起点
        context.lineTo(yAxis_end.x, yAxis_end.y);
        context.stroke();
        /*绘制y轴上的刻度*/
        for (var i = 1; i < yAxis_tick_count; ++i) {
          context.beginPath();
          context.moveTo(axis_origin.x, axis_origin.y - i * yAxis_tick_width);
          context.lineTo(
            axis_origin.x - 10,
            axis_origin.y - i * yAxis_tick_width
          );
          context.stroke();
        }
        /*绘制y轴上的刻度字*/
        context.textAlign = "right";
        context.textBaseline = "middle";
        for (let j = 0; j <= yAxis_tick_count; ++j) {
          context.fillText(
            j * yAxis_tick_width,
            axis_origin.x - 10,
            axis_origin.y - j * yAxis_tick_width
          );
        }
        
        context.drawImage(img, axis_origin.x, axis_margin + 3);

        // 画骨架图
        context.fillStyle="#EE7700";
context.beginPath();
context.arc(100,canvas.height - 100,2,0,Math.PI*2,true);
context.fill();

context.beginPath();
context.arc(180,canvas.height - 70,2,0,Math.PI*2,true);
context.fill();

context.strokeStyle = "#EE7700";
context.beginPath();
          context.moveTo(100, canvas.height - 100);
          context.lineTo(
            180,
            canvas.height - 70
          );
          context.stroke();
      };
    },
  },
};
</script>

<style scoped>
</style>