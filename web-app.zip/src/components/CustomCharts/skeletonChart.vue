<template>
  <div>
    <div
      id="myChart2"
      ref="myChart2"
      :style="{ width: '40vw', height: '50vh' }"
    ></div>
  </div>
</template>

<script>
import echarts from "echarts";

export default {
  props: {
    // 骨架图的标题
    title: {
      type: String,
    },
    // X轴的名字
    xAxisName: {
      type: String,
    },
    // Y轴的名字
    yAxisName: {
      type: String,
    },
    // 数据
    data: {
      type: Array,
    },
    // 路径
    links: {
      type: Array,
    },
  },

  data() {
    return {};
  },

  watch: {
      // 监控切换图表
      data(){
          // 需要重新生成图表
          this.drawChart2();
      }
  },

  components: {},

  mounted() {
    this.drawChart2();
  },

  methods: {
    drawChart2() {
      const myChart = echarts.init(document.getElementById("myChart2"));

      // 绘制图表
      myChart.setOption({
        title: {
          text: this.title,
          x: "center",
          y: "top",
        },
        xAxis: {
          type: "value",
        },
        yAxis: {
          type: "value",
          scale: true,
        },
        series: [
          {
            type: "graph",
            coordinateSystem: "cartesian2d",
            data: this.data,
            links: this.links,
            lineStyle: {
              color: "#333",
            },
            itemStyle: {
              color: function (params) {
                //通过判断选中的名字改变柱子的颜色样式
                if (params.value[2] === "people") {
                  return "green"; //点击后的颜色
                } else {
                  return "blue"; //默认颜色
                }
              },
            },
            symbolSize: 8,
          },
        ],
      });
    },

  },
};
</script>

<style scoped>
</style>