<template>
  <div>
    <div
      id="myChart"
      ref="myChart"
      :style="{ width: '50vw', height: '50vh' }"
    ></div>
  </div>
</template>

<script>
import echarts from "echarts";

export default {
  props: {
    // 散点图的标题
    title: {
      type: String,
    },
    // X轴的名字
    xAxisName: {
      type: String,
    },
    // X轴的数据
    xAxisData: {
      type: Array,
    },
    // Y轴的名字
    yAxisName: {
      type: String,
    },
    // Y轴的数据
    yAxisData: {
      type: Array,
    },
  },

  data() {
    return {};
  },

  watch: {
      // 监控切换图表
      xAxisData(){
          // 需要重新生成图表
          this.drawChart1();
      }
  },

  components: {},

  mounted() {
    this.drawChart1();
  },

  methods: {
    drawChart1() {
      const myChart = echarts.init(document.getElementById("myChart"));

      // 绘制图表
      myChart.setOption({
          title: {
            text: this.title,
            x: "center",
            y: "top",
          },
        legend: {
          right: 10,
          top: 20,
          data: ["left", "right"],
        },
        xAxis: {
          name: this.xAxisName,
        //   nameLocation: "middle",
        //   nameGap: 25,
          splitLine: {
            lineStyle: {
              type: "dashed",
            },
          },
        },
        yAxis: {
          name: this.yAxisName,
        //   nameLocation: "middle",
        //   nameGap: 35,
          splitLine: {
            lineStyle: {
              type: "dashed",
            },
          },
          scale: true,
        },
        series: [
          {
            name: "left",
            data: this.xAxisData,
            type: "scatter",
            // symbolSize: function (data) {
            //   return Math.sqrt(data[2]) / 5e2;
            // },
            //   emphasis: {
            //     label: {
            //       show: true,
            //       formatter: function (param) {
            //         return param.data[0] + ', ' + param.data[1];
            //       },
            //       position: "top",
            //     },
            //   },
            symbolSize: 8,
            itemStyle: {
              color: "red",
            },
          },
          {
            name: "right",
            data: this.yAxisData,
            type: "scatter",
            // symbolSize: function (data) {
            //   return Math.sqrt(data[2]) / 5e2;
            // },
            //   emphasis: {
            //     label: {
            //       show: true,
            //       formatter: function (param) {
            //         return param.data[0] + ', ' + param.data[1];
            //       },
            //       position: "top",
            //     },
            //   },
            symbolSize: 8,
            itemStyle: {
              color: "green",
            },
          },
        ],
      });
    },
  },
};
</script>

<style scoped>
</style>