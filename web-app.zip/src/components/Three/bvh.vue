<template>
  <div>
    <div id="container">
      <el-button
        style="position: absolute;padding: 10px;width: 9%;"
        @click="pause"
      >
        {{ (action && action.paused) ? '继续' : '暂停' }}
      </el-button>
      <div
        class="block"
        style="position: absolute;left: 12%;width: 85%;"
      >
        <el-slider v-model="currFrame" :max="frameLength" :step="1" />
      </div>
    </div>
  </div>
</template>

<script>
import * as THREE from 'three'
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls'
import { WEBGL } from 'three/examples/jsm/WebGL'
// 测试数据
const json = require('../../../public/static/models/3Ddata.json')

export default {
  name: 'ThreeBvh',
  props: {
    modelPath: {
      type: String,
      default: 'static/models/pirouette.bvh'
    },
    width: {
      type: [Number, String],
      default: 600,
      validator: function(value) {
        return Number(value) >= 0
      }
    },
    height: {
      type: [Number, String],
      default: 400,
      validator: function(value) {
        return Number(value) >= 0
      }
    }
  },
  data() {
    return {
      container: null,
      camera: null,
      scene: null,
      renderer: null,
      mesh: null,
      clock: null,
      controls: null,
      action: null,
      // 为了让骨架显示到正中间，对根关节进行偏移处理
      rootOffset: [-50, 100, 150],
      // 缩放比例
      scale: 0.15,
      // 表示每个bone点，在每一帧数据的位置。用于解析数据
      boneIndexMap: {
        root: 0, // 盆骨中心点
        rhip: 1, // 右盆骨点
        rkne: 2, // 右膝盖
        rank: 3, // 右脚踝
        lhip: 4, // 左盆骨点
        lkne: 5, // 左膝盖
        lank: 6, // 左脚踝
        belly: 7, // 身体中心点
        neck: 8, // 脖子
        nose: 9, // 鼻子
        head: 10, // 头
        lsho: 11, // 左肩膀
        lelb: 12, // 左手肘
        lwri: 13, // 左手腕
        rsho: 14, // 右肩膀
        relb: 15, // 右手肘
        rwri: 16 // 右手腕
      },
      frameTime: 0.05,
      frameLength: 0,
      currFrame: 0
    }
  },
  watch: {
    currFrame: function(value) {
      // 手动 根据slider的值，设置动画进度
      this.action.time = value * this.action.getClip().duration / this.frameLength
    }
  },
  mounted() {
    const container = document.getElementById('container')
    this.container = container
    // WebGL兼容性检查
    if (!WEBGL.isWebGLAvailable()) {
      const warning = WEBGL.getWebGLErrorMessage()
      container.appendChild(warning)
      console.log(warning)
    } else {
      this.init()
      this.animate()
    }
  },
  methods: {
    init: function() {
      const _this = this
      const container = _this.container
      // 时钟
      const clock = new THREE.Clock()
      // 场景
      const scene = new THREE.Scene()
      // 场景下沉50，让人物显示在正中间
      scene.position.set(0, -50, 0)
      _this.scene = scene
      // 相机
      const camera = new THREE.PerspectiveCamera(
        60,
        _this.width / _this.height,
        1,
        10000
      )
      camera.position.set(0, 400, 400)
      // 设置相机方向(指向的场景对象)
      camera.lookAt(scene.position)
      // scene.background = new THREE.Color(0xeeeeee)
      scene.add(new THREE.GridHelper(4000, 40))
      // 渲染器
      const renderer = new THREE.WebGLRenderer({ antialias: true })
      renderer.setPixelRatio(container.devicePixelRatio)
      renderer.setSize(_this.width, _this.height)
      container.appendChild(renderer.domElement)
      // 缩放控制
      const controls = new OrbitControls(camera, renderer.domElement)
      controls.minDistance = 300
      controls.maxDistance = 1000

      // 点光源
      const point = new THREE.PointLight(0xffffff)
      point.position.set(0, 0, 0)
      scene.add(point)
      // 环境光
      const ambient = new THREE.AmbientLight(0x444444)
      scene.add(ambient)
      /**
       * 辅助坐标系  参数250表示坐标系大小，可以根据场景大小去设置
       */
      // let axisHelper = new THREE.AxesHelper(250)
      // scene.add(axisHelper)

      this.lastTime = new Date()
      _this.loadMyModel()
      // 相关对象存储到this中
      _this.clock = clock
      _this.camera = camera
      _this.renderer = renderer
      _this.controls = controls
    },
    animate: function() {
      requestAnimationFrame(this.animate)
      // 更新混合器相关的时间
      if (this.mixer) {
        this.mixer.update(this.clock.getDelta())
        // 在动画非暂停状态下，不断刷新：当前进度时间->this.currFrame显示到滑动条上
        if (!this.action.paused) {
          this.currFrame = Math.round(this.action.time / this.action.getClip().duration * this.frameLength)
          // console.log('currFrame:', this.currFrame)
        }
      }
      // 刷新
      this.renderer.render(this.scene, this.camera)
    },
    loadMyModel: function() {
      const _this = this
      const scene = this.scene
      const boneIndexMap = this.boneIndexMap
      const scale = _this.scale
      // 创建 bone，要设置名称。
      // !!! 后面需要根据 name属性+boneIndexMap 寻找父节点数据
      const neck = new THREE.Bone() // 脖子
      neck.name = 'neck'
      const nose = new THREE.Bone() // 鼻子
      nose.name = 'nose'
      // root是根节点
      const root = new THREE.Bone() // 盆骨中心点
      root.name = 'root'
      const lsho = new THREE.Bone() // 左肩膀
      lsho.name = 'lsho'
      const lelb = new THREE.Bone() // 左手肘
      lelb.name = 'lelb'
      const lwri = new THREE.Bone() // 左手腕
      lwri.name = 'lwri'
      const lhip = new THREE.Bone() // 左盆骨点
      lhip.name = 'lhip'
      const lkne = new THREE.Bone() // 左膝盖
      lkne.name = 'lkne'
      const lank = new THREE.Bone() // 左脚踝
      lank.name = 'lank'
      const rsho = new THREE.Bone() // 右肩膀
      rsho.name = 'rsho'
      const relb = new THREE.Bone() // 右手肘
      relb.name = 'relb'
      const rwri = new THREE.Bone() // 右手腕
      rwri.name = 'rwri'
      const rhip = new THREE.Bone() // 右盆骨点
      rhip.name = 'rhip'
      const rkne = new THREE.Bone() // 右膝盖
      rkne.name = 'rkne'
      const rank = new THREE.Bone() // 右脚踝
      rank.name = 'rank'
      const belly = new THREE.Bone() // 身体中心点
      belly.name = 'belly'
      const head = new THREE.Bone() // 头
      head.name = 'head'
      // bone间父子关系
      root.add(belly)
      belly.add(neck)
      neck.add(lsho, nose, rsho)
      nose.add(head)
      lsho.add(lelb)
      lelb.add(lwri)
      rsho.add(relb)
      relb.add(rwri)
      root.add(lhip)
      lhip.add(lkne)
      lkne.add(lank)
      root.add(rhip)
      rhip.add(rkne)
      rkne.add(rank)
      // bone列表
      // ！！！必须严格按照 boneIndexMap 中的顺序，关系到三维坐标的解析
      const bones = [
        root,
        rhip,
        rkne,
        rank,
        lhip,
        lkne,
        lank,
        belly,
        neck,
        nose,
        head,
        lsho,
        lelb,
        lwri,
        rsho,
        relb,
        rwri
      ]
      _this.bones = bones
      // 解决算法结果与当前坐标系方向不同，把根节点绕x轴旋转90度。参数是弧度=2π/4
      root.rotateX(Math.PI / 2)
      // 骨架显示
      const skeleton = new THREE.Skeleton(bones)
      // 骨架辅助显示
      const skeletonHelper = new THREE.SkeletonHelper(root)
      // allow animation mixer to bind to THREE.SkeletonHelper directly
      skeletonHelper.skeleton = skeleton
      // bone group
      const boneContainer = new THREE.Group()
      boneContainer.add(root)
      scene.add(skeletonHelper)
      scene.add(boneContainer)

      // 动作信息
      const frameTime = this.frameTime
      // 离散时间点 -> 每一帧的时间点0开始。所有bone点都相同
      const time = []
      // 存放所有Bone的轨迹
      const tracks = []
      // 每帧数据包含所有bone，拆成每个Bone一个数组
      // 注意！！！把绝对坐标转换为相对坐标
      const arraysByBone = []
      for (let index = 0; index < json.length; index++) {
        // 一帧画面里的所有Bone三维数据
        const element = json[index]
        if (element.length === 0) {
          continue
        }
        time.push(index * frameTime)
        for (let j = 0; j < element.length; j++) {
          /**
           * ！！！处理 绝对坐标转换为相对坐标；
           * 逻辑：1. 当前节点坐标-父节点坐标
           *      2. 父子节点关系，从 bones 中 Bone的父子关系获得；
           *      3. 当前数据是哪个bone？依赖于：
           *          (1)bones数组的顺序与单帧中三维数据的顺序完全相同；
           *          (2)创建Bone时设置name属性+boneIndexMap。
           */
          const bone = this.bones[j]
          const relativePoi = []
          if (bone.name === 'root') {
            relativePoi.push(element[j][0] * scale + _this.rootOffset[0])
            relativePoi.push(element[j][1] * scale + _this.rootOffset[1])
            relativePoi.push(element[j][2] * scale + _this.rootOffset[2])
          } else {
            const parentBoneName = bone.parent.name
            relativePoi.push(element[j][0] * scale - element[boneIndexMap[parentBoneName]][0] * scale)
            relativePoi.push(element[j][1] * scale - element[boneIndexMap[parentBoneName]][1] * scale)
            relativePoi.push(element[j][2] * scale - element[boneIndexMap[parentBoneName]][2] * scale)
          }
          // 在第一次循环时，arraysByBone还是空的；先添加单bone的数组
          if (arraysByBone.length <= j) {
            arraysByBone.push([relativePoi])
          } else {
            arraysByBone[j].push(relativePoi)
          }
        }
      }
      // 为每个Bone 生成关键帧数据
      // 注意：在上一步已经转换为相对坐标
      for (let i = 0; i < arraysByBone.length; i++) {
        const boneArr = arraysByBone[i]
        const positions = []
        for (let j = 0; j < boneArr.length; j++) {
          // positions 需要单个相对三维坐标x,y,z 依次放入
          positions.push(...boneArr[j])
        }
        // 生成单个bone的track数据
        tracks.push(new THREE.VectorKeyframeTrack('.bones[' + this.bones[i].name + '].position', time, positions))
      }
      console.log('frameNum:', time.length, 'lastTime:', time[time.length - 1], 'boneNum:', tracks.length)
      const clip = new THREE.AnimationClip('animation', -1, tracks)
      // 动画播放
      // 骨骼网格模型作为参数创建一个混合器
      const mixer = new THREE.AnimationMixer(skeletonHelper)
      this.mixer = mixer
      // 解析动作状态对应剪辑对象clip中的关键帧数据
      // 保存动画操作对象，用于暂停/播放
      this.action = mixer.clipAction(clip).setEffectiveWeight(1.0).play()
      console.log('load 3Ddata success !')
      this.frameLength = time.length
    },
    // 暂停继续播放函数
    pause: function() {
      if (this.action.paused) {
        this.action.paused = false
      } else {
        this.action.paused = true
      }
    }
  }
}
</script>
<style>
#container {
  /* border: 1px solid red */
}
</style>
