<template>
  <div>
    <el-container class="container">
      <el-main>
        <el-tabs v-model="activeName" @tab-click="handleClick">
          <el-tab-pane label="采集视频" name="first">
            <div class="video1">
              <div
                v-for="(item, i) in list"
                :key="i"
                style="margin-bottom: 30px"
              >
                <div class="video2">
                  <video :id="'myVideo' + item.id" class="video-js">
                    <source :src="item.src" type="rtmp/flv" />
                  </video>
                </div>
              </div>
            </div>
          </el-tab-pane>
          <el-tab-pane label="三维图" name="second">
            <three-bvh width="640" height="360" />
          </el-tab-pane>

          <el-tab-pane label="步态图" name="third">
            <scatter-chart
              v-if="activeName === 'third'"
              :title="scatterTitle"
              :xAxisName="scatterXAxisName"
              :yAxisName="scatterYAxisName"
              :xAxisData="scatterXAxisData"
              :yAxisData="scatterYAxisData"
            ></scatter-chart>
          </el-tab-pane>

          <el-tab-pane label="骨架图" name="fourth">
            <skeleton-chart 
              v-if="activeName === 'fourth'"
              :title="skeletonTitle"
              :xAxisName="scatterXAxisName"
              :yAxisName="scatterYAxisName"
              :data="skeletonData"
              :links="skeletonLinks"
              style="display: inline-block;"
            ></skeleton-chart>
            <canvas-chart style="display: inline-block;"></canvas-chart>
          </el-tab-pane>
        </el-tabs>
        <br />
        <el-row type="flex" justify="end" v-if="activeName === 'first' || activeName === 'second'">
          <el-button>摄像_1</el-button>
          <el-button>摄像_2</el-button>
          <el-button>摄像_3</el-button>
          <el-button>摄像_4</el-button>
          <el-button>摄像_5</el-button>
          <el-button>摄像_6</el-button>
        </el-row>
        <!-- 按钮区域，切换图表 -->
        <el-row v-else-if="activeName === 'third' ">
          <el-button
            v-for="(name, index) in scatterButtons"
            :key="index"
            v-text="name"
            @click="handleScatterBtnClick(index)"
          ></el-button>
        </el-row>
        <el-row v-else-if="activeName === 'fourth' ">
          <el-button
            v-for="(name, index) in skeletonButtons"
            :key="index"
            v-text="name"
            @click="handleSkeletonBtnClick(index)"
          ></el-button>
        </el-row>
      </el-main>
      <el-aside width="500px">
        <span>视频列表</span>
        <span style="margin-left: 120px">
          <el-input
            v-model="input"
            placeholder="按姓名搜索"
            style="width: 40%"
          />
          <el-button type="primary" plain>搜索</el-button>
        </span>
        <br />
        <br />
        <el-table :data="tableData" style="width: 100%">
          <el-table-column type="expand">
            <template slot-scope="props">
              <el-form label-position="left" inline class="demo-table-expand">
                <el-form-item
                  v-for="(item, index) in props.row.gaits"
                  label="采集视频"
                  style="width: 100%"
                >
                  <el-button type="text" style="margin-left: 80px">
                    {{ props.row.caseUserName }}-{{ item.cgCameraId }}
                  </el-button>
                  <template>
                    <el-button
                      type="text"
                      class="button-right"
                      style="margin-left: 80px"
                      >删除</el-button
                    >
                  </template>
                </el-form-item>
              </el-form>
            </template>
          </el-table-column>
          <el-table-column label="姓名" prop="caseUserName" />
          <el-table-column label="性别">
            <template slot-scope="props">
              {{ props.row.caseUserSex == "0" ? "女" : "男" }}
            </template>
          </el-table-column>
          <el-table-column label="年龄" prop="caseUserAge" width="100%" />
          <el-table-column fixed="right" label="操作" width="100">
            <template slot-scope="scope">
              <el-button
                type="text"
                size="mini"
                @click="handleEdit(scope.$index, scope.row)"
                >编辑</el-button
              >
              <el-button
                type="text"
                size="mini"
                @click="handleDelete(scope.$index, scope.row)"
                >删除</el-button
              >
            </template>
          </el-table-column>
        </el-table>

        <el-dialog
          title="提示"
          :visible.sync="deleteaVisible"
          width="30%"
          :before-close="handleClose"
        >
          <span>此操作将永久删除该人员信息, 是否继续?</span>
          <span slot="footer" class="dialog-footer">
            <el-button @click="deleteaVisible = false">取 消</el-button>
            <el-button type="submit" @click="deleteUser()">确 定</el-button>
          </span>
          <el-form :model="deleteForm" style="display: none">
            <el-input v-model="deleteForm.caseId" />
          </el-form>
        </el-dialog>
        <el-dialog
          style="width: 65%; margin: 0 auto"
          title="编辑人员列表"
          :visible.sync="dialogFormVisible"
        >
          <el-form :model="form">
            <el-form-item label="姓名" style="display: none">
              <el-input
                v-model="form.caseUserId"
                placeholder="请选择姓名"
                autocomplete="off"
                style="width: 200px"
              />
            </el-form-item>
            <el-form-item label="姓名" :label-width="formLabelWidth">
              <el-input
                v-model="form.caseUserName"
                placeholder="请选择姓名"
                autocomplete="off"
                style="width: 200px"
              />
            </el-form-item>
            <el-form-item label="性别" :label-width="formLabelWidth">
              <el-select
                v-model="form.caseUserSex == '0' ? '女' : '男'"
                autocomplete="off"
                placeholder="请选择性别"
                class="input"
              >
                <el-option label="男" :value="1" />
                <el-option label="女" :value="0" />
              </el-select>
            </el-form-item>
            <el-form-item label="年龄" :label-width="formLabelWidth">
              <el-input
                v-model="form.caseUserAge"
                autocomplete="off"
                placeholder="请选择年龄"
                style="width: 200px"
              />
            </el-form-item>
            <el-form-item label="体重" :label-width="formLabelWidth">
              <el-input
                v-model="form.caseUserWeight"
                autocomplete="off"
                placeholder="输入体重"
                style="width: 200px"
                class="input"
              />
            </el-form-item>
            <el-form-item label="身高" :label-width="formLabelWidth">
              <el-input
                v-model="form.caseUserHeight"
                autocomplete="off"
                placeholder="输入身高"
                style="width: 200px"
                class="input"
              />
            </el-form-item>
          </el-form>
          <div slot="footer" class="dialog-footer">
            <el-button @click="dialogFormVisible = false">取 消</el-button>
            <el-button type="primary" @click="editUser">确 定</el-button>
          </div>
        </el-dialog>
      </el-aside>
    </el-container>
  </div>
</template>

<script>
import "video.js/dist/video-js.css";
import "vue-video-player/src/custom-theme.css";
import { videoPlayer } from "vue-video-player";
import "videojs-flash";
import { getUser } from "../api/camera";
import ThreeBvh from "../components/Three/bvh";
import { editUser } from "../api/camera";
import { deleteUser } from "../api/camera";
import ScatterChart from "@/components/CustomCharts/scatterChart.vue";
import SkeletonChart from "@/components/CustomCharts/skeletonChart.vue";
import CanvasChart from "@/components/CustomCharts/canvasChart.vue";
import CustomChartsApi from "@/api/customCharts";

export default {
  components: {
    videoPlayer,
    ThreeBvh,
    ScatterChart,
    SkeletonChart,
    CanvasChart
  },
  data() {
    return {
      list: [
        {
          src: "rtmp://127.0.0.1:1935/live/test",
          id: 0,
          pic: "",
        },
      ],
      deleteaVisible: false,
      activeName: "first",
      tableData: [],
      input: "",
      videoSrc: "",
      // 表单

      dialogTableVisible: false,
      dialogFormVisible: false,
      form: {
        caseUserId: "",
        caseUserName: "",
        caseUserSex: "",
        caseUserAge: "",
        caseUserHeight: "",
        caseUserWeight: "",
      },
      deleteForm: {
        CaseId: "",
      },
      formLabelWidth: "120px",
      scatterButtons: [
        "脚踝高度",
        "膝盖角度",
        "跨步时间",
        "跨步长度",
        "步长长度",
        "步宽长度",
        "步频",
        "步速",
      ],
      scatterTitle: '脚踝高度图',
      scatterXAxisName: "帧数", // X轴相关数据
      scatterXAxisData: [],
      scatterYAxisName: "脚踝高度(单位:mn)", // Y轴相关数据
      scatterYAxisData: [],
      skeletonButtons: [
        "正视图",
        "侧视图",
        "俯视图"
      ],
      skeletonTitle: '正视图',
      skeletonXAxisName: "", // X轴相关数据
      skeletonYAxisName: "", // Y轴相关数据
      skeletonData: [],
      skeletonLinks: [],
    };
  },
  created() {
    console.log("created");
    //this.getUser()

    // if (location.href.indexOf('?xyz=') < 0) {
    //   location.href = location.href + '?xyz=' + Math.random()
    //   location.reload()
    // }
  },
  mounted() {
    //this.initVideo()
  },
  methods: {
    initVideo() {
      // 初始化视频方法 循环列表获取每个视频的id
      this.list.map((item, i) => {
        const myPlayer = this.$video("myVideo" + item.id, {
          // 确定播放器是否具有用户可以与之交互的控件。没有控件，启动视频播放的唯一方法是使用autoplay属性或通过Player API。
          controls: true,
          // 自动播放属性,muted:静音播放
          // autoplay: "muted",
          autoplay: true,
          // 建议浏览器是否应在<video>加载元素后立即开始下载视频数据。
          preload: "auto",
          // 设置视频播放器的显示宽度（以像素为单位）
          width: "640px",
          // 设置视频播放器的显示高度（以像素为单位）
          height: "360px",
          // 封面图
          poster: item.pic,
        });
      });
    },
    handleClick(tab, event) {
      console.log(tab, event);
      if (tab.index == 0) {
        location.reload();
      }

     if(tab.index === '2'){
        this.getScatterData(0)
      }else if(tab.index === '3'){
         this.getSkeletonData(0)
      }
    },
    handleClose(done) {
      this.$confirm("确认关闭？")
        .then((_) => {
          done();
        })
        .catch((_) => {});
    },
    // 编辑
    handleEdit(index, row) {
      this.dialogFormVisible = true;
      this.form = row;
      console.log(index, row);
    },
    editUser() {
      this.dialogFormVisible = false;
      console.log(this.form);
      editUser(this.form)
        .then((res) => {
          if (res.code == 200) {
            // alert("保存成功")
          } else {
            // alert("保存失败")
          }
        })
        .catch((err) => {
          //  alert("保存失败")
        });
    },
    handleDelete(index, row) {
      this.deleteaVisible = true;
      this.deleteForm = row;
      // console.log(row);
    },
    deleteUser() {
      this.deleteaVisible = false;
      var id = this.deleteForm.caseId;
      deleteUser(id)
        .then((res) => {
          console.log("调用了delete方法");
          if (res.code == 200) {
            // alert("保存成功")
          } else {
            // alert("保存失败")
          }
        })
        .catch((err) => {
          //  alert("保存失败")
        });
      this.$router.go(0);
    },
    getUser() {
      getUser()
        .then((res) => {
          console.log(res);
          if (res.code == 200) {
          } else {
            // alert("保存失败")
            console.log(res.data);
            return;
          }
          console.log(res.data);
          res.data.forEach(function (item, index) {
            item.gaits = [];
            for (let index = 1; index < 7; index++) {
              var gait = {
                cgId: "",
                cgCaseId: "",
                cgStime: "2021-1-6",
                cgEtime: "",
                cgCameraId: "00" + index,
                cgIp: "",
                cgPath: "",
                no_5: "",
                no_6: "",
              };
              item.gaits.push(gait);
            }
          });
          console.log(res.data);
          this.tableData = res.data;
        })
        .catch((err) => {
          // alert("保存失败")
        });
    },

    // 散件图，点击自定义图表的按钮
    handleScatterBtnClick(index) {
      // 根据点击不同的图表，给子组件传递不同的数据
      switch (index) {
        case 0:
          this.scatterTitle = "脚踝高度图";
          this.scatterXAxisName = "帧数";
          this.scatterYAxisName = "脚踝高度(单位:mn)";
          break;
        case 1:
          this.scatterTitle = "膝盖角度图";
          this.scatterXAxisName = "帧数";
          this.scatterYAxisName = "膝盖角度(单位:度)";
          break;
        case 2:
          this.scatterTitle = "跨步时间图";
          this.scatterXAxisName = "步数";
          this.scatterYAxisName = "跨步时间(单位:s)";
          break;
        case 3:
          this.scatterTitle = "跨步长度图";
          this.scatterXAxisName = "步数";
          this.scatterYAxisName = "跨步长度(单位:m)";
          break;
        case 4:
          this.scatterTitle = "步长长度图";
           this.scatterXAxisName = "步数";
          this.scatterYAxisName = "步长长度(单位:m)";
          break;
        case 5:
          this.scatterTitle = "布宽长度图";
          this.scatterXAxisName = "步数";
          this.scatterYAxisName = "布宽长度(单位:m)";
          break;
        case 6:
          this.scatterTitle = "步频图";
          this.scatterXAxisName = "步数";
          this.scatterYAxisName = "步频(单位:次/min)";
          break;
        case 7:
          this.scatterTitle = "步速图";
          this.scatterXAxisName = "步数";
          this.scatterYAxisName = "步速(单位:m/s)";
          break;
      }

      this.getScatterData(index)
    },

    // 查询散点图的数据
    getScatterData(index){
      CustomChartsApi.getScatterData(index).then( res => {
        this.scatterXAxisData = res.data.xAxisData
        this.scatterYAxisData = res.data.yAxisData
      }).catch( err => {
        console.log('getScatterData() Error: ', err)
      })
    },

    // 骨架图，点击自定义图表的按钮
    handleSkeletonBtnClick(index){
      // 根据点击不同的图表，给子组件传递不同的数据
      switch (index) {
        case 0:
          this.skeletonTitle = "正视图";
          break;
        case 1:
          this.skeletonTitle = "侧视图";
          break;
        case 2:
          this.skeletonTitle = "俯视图";
          break;
      }

      this.getSkeletonData(index)
    },

      // 查询骨架图的数据
    getSkeletonData(index){
      CustomChartsApi.getSkeletonData(index).then( res => {
        this.skeletonData = res.data.data
        this.skeletonLinks = res.data.links
      }).catch( err => {
        console.log('getSkeletonData() Error: ', err)
      })
    }
  },
};
</script>
<style scoped>
.demo-table-expand {
  font-size: 0;
}
.demo-table-expand label {
  width: 90px;
  color: #99a9bf;
}
.demo-table-expand .el-form-item {
  margin-right: 0;
  margin-bottom: 0;
  width: 50%;
}
.customWidth {
  width: 80%;
}
</style>
