<template>
  <div id="three-demo">
    <el-tabs>
      <el-tab-pane label="BVH模型">
        <three-bvh width="900" height="600" />
      </el-tab-pane>
    </el-tabs>
  </div>
</template>

<script>
import ThreeBvh from '../../components/Three/bvh'
export default {
  components: {
    ThreeBvh
  }
}
</script>
<style scoped>
#three-demo {
  position: absolute;
  left: 100px;
  top: 10px;
  border: 1px solid darkgray;
}
</style>
