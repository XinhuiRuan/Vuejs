<template>
  <div>
    <el-button class="el-icon-plus" type="success" @click="dialogFormVisible1 = true" />
    <el-dialog title="Watrix" :visible.sync="dialogFormVisible1">
      <el-form :model="camera">
        <el-form-item label="名称" :label-width="formLabelWidth">
          <el-input v-model="camera.camName" autocomplete="off" />
        </el-form-item>
        <el-form-item label="IP" :label-width="formLabelWidth">
          <el-input v-model="camera.camIp" autocomplete="off" />
        </el-form-item>
        <el-form-item label="RTSP" :label-width="formLabelWidth">
          <el-input v-model="camera.camRtsp" autocomplete="off" />
        </el-form-item>
        <el-form-item label="摄像机朝向" :label-width="formLabelWidth">
          <el-input v-model="camera.camToward" autocomplete="off" />
        </el-form-item>
        <el-form-item label="水平偏移角度" :label-width="formLabelWidth">
          <el-input v-model="camera.camAngle" autocomplete="off" />
        </el-form-item>
        <el-form-item label="运行状态" :label-width="formLabelWidth">
          <el-input v-model="camera.camSatus" autocomplete="off" />
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialogFormVisible1 = false">取 消</el-button>
        <el-button type="primary" @click="addCamera">确 定</el-button>
      </div>
    </el-dialog>

    <el-input
      v-model="input"
      placeholder="IP搜索"
      clearable
      style="width: 10%; margin-left: 1095px"
    />
    <!-- 搜索 -->
    <el-button round style="margin-left: -8px" type="primary" icon="el-icon-search" />
    <el-table :data="tableData" border style="width: 100%">
      <template>
        <!-- <el-table-column prop="camId" label="序号" width="60" /> -->
        <el-table-column prop="camName" label="名称" width="165" />
        <el-table-column prop="camIp" label="IP" width="195" />
        <el-table-column prop="camRtsp" label="Rtsp" width="245" />
        <el-table-column prop="camToward" label="摄像机朝向" width="165" />
        <el-table-column prop="camAngle" label="水平偏移角度" width="165" />
        <el-table-column prop="camSatus" label="运行状态" width="165" />
        <el-table-column prop="operate" label="操作" width="230">
          <template slot-scope="scope">
            <el-button type="text" size="mini" @click="handleClick(scope.row)">修改</el-button>
            <el-dialog title="Watrix" :visible.sync="dialogFormVisible2">
              <el-form :model="deleteForm" style="display:none">
                <el-form-item label="Id" :label-width="formLabelWidth">
                  <el-input v-model="deleteForm.camId" autocomplete="off" />
                </el-form-item>
                <el-form-item label="名称" :label-width="formLabelWidth">
                  <el-input v-model="deleteForm.camName" autocomplete="off" />
                </el-form-item>
                <el-form-item label="IP" :label-width="formLabelWidth">
                  <el-input v-model="deleteForm.camIp" autocomplete="off" />
                </el-form-item>
                <el-form-item label="RTSP" :label-width="formLabelWidth">
                  <el-input v-model="deleteForm.camRtsp" autocomplete="off" />
                </el-form-item>
                <el-form-item label="摄像机朝向" :label-width="formLabelWidth">
                  <el-input v-model="deleteForm.camToward" autocomplete="off" />
                </el-form-item>
                <el-form-item label="水平偏移角度" :label-width="formLabelWidth">
                  <el-input v-model="deleteForm.camAngle" autocomplete="off" />
                </el-form-item>
                <el-form-item label="运行状态" :label-width="formLabelWidth">
                  <el-input v-model="deleteForm.camSatus" autocomplete="off" />
                </el-form-item>
              </el-form>
              <div slot="footer" class="dialog-footer">
                <el-button @click="dialogFormVisible2 = false">取 消</el-button>
                <el-button type="primary" @click="editCamera">确 定</el-button>
              </div>

            </el-dialog>
            <el-button type="text" size="mini" @click="handleDelete(scope.$index, scope.row)">删除</el-button>
            <el-dialog
              title="提示"
              :visible.sync="dialogVisible"
              width="30%"
              :before-close="handleClose"
            >
              <span>确定要删除吗</span>
              <span slot="footer" class="dialog-footer">
                <el-button @click="dialogVisible = false">取 消</el-button>
                <el-button type="submit" @click="deleteCamera">确 定</el-button>
              </span>
            </el-dialog>
          </template>
        </el-table-column>
      </template>
    </el-table>
  </div>

</template>

<script>
import { addCamera } from '../api/query'
import { getCamera } from '../api/query'
import { deleteCamera } from '../api/query'
import { editCamera } from '../api/query'
export default {
  data() {
    return {
      dialogTableVisible: false,
      dialogFormVisible1: false,
      dialogFormVisible2: false,
      form: {
      },
      deleteForm: {
      },
      camera: {
      },
      formLabelWidth: '120px',
      dialogVisible: false,
      tableData: [
      ],
      input: ''
    }
  },
  created() {
    console.log('created')
    this.getCamera()
  },
  methods: {
    handleClose(done) {
      this.$confirm('确认关闭？')
        .then(_ => {
          done()
        })
        .catch(_ => {})
    },
    handleClick(row) {
      this.dialogFormVisible2 = true
      console.log(row)
      this.camera = row
    },
    // 查询摄像头
    getCamera() {
      getCamera().then(res => {
        console.log(res)

        if (res.code === 200) {
          this.tableData = res.data
        } else {
          // alert("保存失败")
          console.log(res.data)
          return
        }
      })
        // eslint-disable-next-line handle-callback-err
        .catch(err => {
        // alert("保存失败")
        })
    },
    // 编辑
    editCamera() {
      this.dialogFormVisible2 = false
      // this.camera = row;
      console.log(this.camera)
      editCamera(this.camera)
        .then((res) => {
          if (res.code === 200) {
            // alert("保存成功")
          } else {
            // alert("保存失败")
          }
        })
        // eslint-disable-next-line handle-callback-err
        .catch((err) => {
          //  alert("保存失败")
        })
    },
    handleDelete(index, row) {
      this.dialogVisible = true
      this.deleteForm = row
      // console.log(row);
    },
    // 删除
    deleteCamera() {
      this.deleteaVisible = false
      this.dialogVisible = true
      var id = this.deleteForm.camId
      console.log(id)
      deleteCamera(id)
        .then((res) => {
          console.log('调用了delete方法')
          if (res.code === 200) {
            // alert("保存成功")
          } else {
            // alert("保存失败")
          }
        })
        // eslint-disable-next-line handle-callback-err
        .catch((err) => {
          //  alert("保存失败")
        })
      this.$router.go(0)
    },
    // 增加摄像头
    addCamera() {
      this.dialogFormVisible1 = false
      console.log(this.camera)
      addCamera(this.camera)
        .then(res => {
          if (res.code === 200) {
            // alert("保存成功")
          } else {
            // alert("保存失败")
          }
        })
        // eslint-disable-next-line handle-callback-err
        .catch(err => {
        //  alert("保存失败")
        })
      this.dialogVisible = false
    }
  }
}
</script>

