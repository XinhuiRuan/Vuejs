<template>
  <div>
    <el-container class="container">
      <el-main width="600px">

        <div class="video1" style="text-align:center">
          <div v-for="(item,i) in list" :key="i" style="margin-bottom: 30px">
            <div class="video2">
              <video :id="'myVideo'+item.id" class="video-js">
                <source :src="item.src" type="rtmp/flv">
              </video>
            </div>
          </div>
        </div>

        <el-row type="flex" justify="end" style="margin-top:550px">
          <el-button>还原</el-button>
          <el-button>中止</el-button>
          <el-button>开始</el-button>
          <el-button>结束</el-button>
        </el-row>
      </el-main>

      <el-aside width="400px">
        <el-switch
          v-model="value"
          active-text="编辑"
          inactive-text="新增"
        />
        <el-button
          v-if="value"
          type="primary"
          icon="el-icon-search"
          style="margin-left:20px"
          @click="getTableUser"
        >搜索病人</el-button>

        <el-tabs v-if="!value">
          <el-tab-pane label="人员信息" name="info">
            <el-collapse v-model="activeNames" @change="handleChange">
              <el-collapse-item title="基本信息" name="1">
                <el-form v-model="user" label-width="80px">
                  <el-form-item label="姓名">
                    <el-input
                      v-model="user.caseUserName"
                      placeholder="输入姓名"
                      class="input"
                    />
                  </el-form-item>
                  <el-form-item label="性别">
                    <el-select
                      v-model="user.caseUserSex"
                      placeholder="请选择性别"
                      class="input"
                    >
                      <el-option label="男" :value="1" />
                      <el-option label="女" :value="0" />
                    </el-select>
                  </el-form-item>
                  <el-form-item label="年龄">
                    <el-input
                      v-model="user.caseUserAge"
                      placeholder="输入年龄"
                      class="input"
                    />
                  </el-form-item>
                  <el-form-item label="体重">
                    <el-input
                      v-model="user.caseUserWeight"
                      placeholder="输入体重"
                      class="input"
                    />
                  </el-form-item>
                  <el-form-item label="身高">
                    <el-input
                      v-model="user.caseUserHeight"
                      placeholder="输入身高"
                      class="input"
                    />
                  </el-form-item>
                </el-form>
              </el-collapse-item>
              <el-collapse-item title="右侧信息" name="2">
                <el-form :model="user" label-width="80px">
                  <el-form-item label="腿长">
                    <el-input
                      v-model="user.caseUserRightLegLength"
                      placeholder="输入腿长"
                      class="input"
                    />
                  </el-form-item>
                  <el-form-item label="轴距">
                    <el-input
                      v-model="user.caseUserRightWheelBase"
                      placeholder="输入轴距"
                      class="input"
                    />
                  </el-form-item>
                  <el-form-item label="膝盖宽度">
                    <el-input
                      v-model="user.caseUserRightKneeWidth"
                      placeholder="输入膝盖宽度"
                      class="input"
                    />
                  </el-form-item>
                  <el-form-item label="脚踝宽度">
                    <el-input
                      v-model="user.caseUserRightAnkleWidth"
                      placeholder="输入脚踝宽度"
                      class="input"
                    />
                  </el-form-item>
                </el-form>
              </el-collapse-item>
              <el-collapse-item title="左侧信息" name="3">
                <el-form :model="user" label-width="80px">
                  <el-form-item label="腿长">
                    <el-input
                      v-model="user.caseUserLeftLegLength"
                      placeholder="输入腿长"
                      class="input"
                    />
                  </el-form-item>
                  <el-form-item label="轴距">
                    <el-input
                      v-model="user.caseUserLeftWheelBase"
                      placeholder="输入轴距"
                      class="input"
                    />
                  </el-form-item>
                  <el-form-item label="膝盖宽度">
                    <el-input
                      v-model="user.caseUserLeftKneeWidth"
                      placeholder="输入膝盖宽度"
                      class="input"
                    />
                  </el-form-item>
                  <el-form-item label="脚踝宽度">
                    <el-input
                      v-model="user.caseUserLeftAnkleWidth"
                      placeholder="输入脚踝宽度"
                      class="input"
                    />
                  </el-form-item>
                </el-form>
              </el-collapse-item>
              <div class="login-btn">
                <el-button @click="goback(-0)">取消</el-button>
                <el-button type="primary" @click="addUser">保存</el-button>
              </div>
            </el-collapse>
          </el-tab-pane>
        </el-tabs>

        <el-tabs v-if="value">
          <el-tab-pane label="详细信息" name="info">
            <el-collapse v-model="activeNames" @change="handleChange">
              <el-collapse-item title="基本信息" name="1">
                <el-form v-model="searchUser" label-width="80px">
                  <el-form-item label="姓名">
                    <el-input
                      v-model="searchUser.caseUserName"
                      placeholder="输入姓名"
                      class="input"
                    />
                  </el-form-item>
                  <el-form-item label="性别">
                    <el-select
                      v-model="searchUser.caseUserSex"
                      placeholder="请选择性别"
                      class="input"
                    >
                      <el-option label="男" :value="1" />
                      <el-option label="女" :value="0" />
                    </el-select>
                  </el-form-item>
                  <el-form-item label="年龄">
                    <el-input
                      v-model="searchUser.caseUserAge"
                      placeholder="输入年龄"
                      class="input"
                    />
                  </el-form-item>
                  <el-form-item label="体重">
                    <el-input
                      v-model="searchUser.caseUserWeight"
                      placeholder="输入体重"
                      class="input"
                    />
                  </el-form-item>
                  <el-form-item label="身高">
                    <el-input
                      v-model="searchUser.caseUserHeight"
                      placeholder="输入身高"
                      class="input"
                    />
                  </el-form-item>
                </el-form>
              </el-collapse-item>
              <el-collapse-item title="右侧信息" name="2">
                <el-form :model="searchUser" label-width="80px">
                  <el-form-item label="腿长">
                    <el-input
                      v-model="searchUser.caseUserRightLegLength"
                      placeholder="输入腿长"
                      class="input"
                    />
                  </el-form-item>
                  <el-form-item label="轴距">
                    <el-input
                      v-model="searchUser.caseUserRightWheelBase"
                      placeholder="输入轴距"
                      class="input"
                    />
                  </el-form-item>
                  <el-form-item label="膝盖宽度">
                    <el-input
                      v-model="searchUser.caseUserRightKneeWidth"
                      placeholder="输入膝盖宽度"
                      class="input"
                    />
                  </el-form-item>
                  <el-form-item label="脚踝宽度">
                    <el-input
                      v-model="searchUser.caseUserRightAnkleWidth"
                      placeholder="输入脚踝宽度"
                      class="input"
                    />
                  </el-form-item>
                </el-form>
              </el-collapse-item>
              <el-collapse-item title="左侧信息" name="3">
                <el-form :model="searchUser" label-width="80px">
                  <el-form-item label="腿长">
                    <el-input
                      v-model="searchUser.caseUserLeftLegLength"
                      placeholder="输入腿长"
                      class="input"
                    />
                  </el-form-item>
                  <el-form-item label="轴距">
                    <el-input
                      v-model="searchUser.caseUserLeftWheelBase"
                      placeholder="输入轴距"
                      class="input"
                    />
                  </el-form-item>
                  <el-form-item label="膝盖宽度">
                    <el-input
                      v-model="searchUser.caseUserLeftKneeWidth"
                      placeholder="输入膝盖宽度"
                      class="input"
                    />
                  </el-form-item>
                  <el-form-item label="脚踝宽度">
                    <el-input
                      v-model="searchUser.caseUserLeftAnkleWidth"
                      placeholder="输入脚踝宽度"
                      class="input"
                    />
                  </el-form-item>
                </el-form>
              </el-collapse-item>
              <div class="login-btn">
                <el-button @click="goback(-0)">取消</el-button>
                <el-button type="primary" @click="addUser">保存</el-button>
              </div>
            </el-collapse>
          </el-tab-pane>
          <el-tab-pane label="采集视频" name="vedios">
            <el-table
              :data="tableData"
              style="width: 100%;height:100%"
              max-height="550"
            >
              <el-table-column fixed prop="date" label="日期" width="100" />
              <el-table-column prop="caseUserName" label="姓名" width="100" />
              <el-table-column prop="no" label="摄像编号" width="50" />
              <el-table-column fixed="right" label="操作" width="80">
                <template slot-scope="scope">
                  <el-button
                    type="text"
                    size="small"
                    @click.native.prevent="deleteRow(scope.$index, tableData)"
                  >
                    移除
                  </el-button>
                </template>
              </el-table-column>
            </el-table>
          </el-tab-pane>
        </el-tabs>
      </el-aside>
    </el-container>

    <el-dialog
      style="width: 65%; margin: 0 auto"
      :visible.sync="dialogFormVisible"
    >
      <span>
        <label style="font-size:20px"> 选择病人</label>
        <span :model="casedata">
          <el-input
            v-model="casedata.caseUserName"
            placeholder="按姓名搜索"
            style="width: 40%;margin-left:50px"
          />
        </span>
        <el-button type="primary" plain @click="getSelectUser">搜索</el-button>
      </span>
      <el-table
        ref="singleTable"
        :data="tableUserData"
        highlight-current-row
        style="width: 100%"
        @current-change="handleCurrentChange"
      >
        <el-table-column
          type="index"
          width="50"
        />
        <el-table-column
          property="caseUserName"
          label="姓名"
          width="120"
        />
        <el-table-column
          label="性别"
          width="120"
        >
          <template slot-scope="props">
            {{ props.row.caseUserSex == "0" ? "女" : "男" }}
          </template>
        </el-table-column>
        <el-table-column
          property="caseUserAge"
          label="年龄"
        />
      </el-table>

      <div slot="footer" class="dialog-footer">
        <el-button @click="dialogFormVisible = false">取 消</el-button>
        <el-button type="primary" @click="showUser">确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import { getSelectUser } from '../api/collection'
import { addUser } from '../api/collection'
import { getUser } from '../api/camera'
import 'video.js/dist/video-js.css'
import 'vue-video-player/src/custom-theme.css'
import { videoPlayer } from 'vue-video-player'
import 'videojs-flash'

export default {
  name: 'Video',
  name: 'Collection',
  components: {
    videoPlayer
  },
  // mounted() {
  //   //第二种方法
  //   if (window.performance.navigation.type == 1) {
  //     console.log("页面被刷新");

  //   } else {
  //     console.log("首次被加载");
  //   }
  // },
  data() {
    return {
      list: [
        {
          src: 'rtmp://127.0.0.1:1935/live/test',
          id: 0,
          pic: ''
        }
      ],
      // 搜索框
      casedata: {
        caseUserName: ''
      },
      // switch
      value: true,
      // dialog
      dialogTableVisible: false,
      dialogFormVisible: false,
      searchData: [
        {
          date: 'test',
          name: '王小虎',
          address: '上海市'
        },
        {
          date: 'test',
          name: '王小虎',
          address: '上海市'
        },
        {
          date: 'test',
          name: '王小虎',
          address: '上海市'
        },
        {
          date: 'test',
          name: '王小虎',
          address: '上海市'
        }
      ],
      user: {},
      searchUser: {},
      formLabelWidth: '120px',
      tableUserData: {},
      activeNames: ['1'],
      tableData: [
        {
          date: '2021-01-07',
          caseUserName: '银河水滴',
          no: '1'
        },
        {
          date: '2021-01-07',
          caseUserName: '银河水滴',
          no: '2'
        },
        {
          date: '2021-01-07',
          caseUserName: '银河水滴',
          no: '3'
        },
        {
          date: '2021-01-07',
          caseUserName: '银河水滴',
          no: '4'
        },
        {
          date: '2021-01-07',
          caseUserName: '银河水滴',
          no: '5'
        },
        {
          date: '2021-01-07',
          caseUserName: '银河水滴',
          no: '6'
        }
      ]
    }
  },
  created() {
    console.log('created')
    this.getUser()

    if (location.href.indexOf('?xyz=') < 0) {
      location.href = location.href + '?xyz=' + Math.random()
      location.reload()
    }

    //  if (window.performance.navigation.type == 1) {

    //   location.reload();
    //   window.performance.navigation.type++;
    // } else {
    //   console.log("首次被加载");
    // }
  },
  // //调用视频流方法
  mounted() {
    this.initVideo()
  },
  methods: {
    //   beforeDestroy() {
    //   this.$refs.videojs.dispose();
    // },

    // 搜索框
    getSelectUser() {
      console.log(this.casedata)
      getSelectUser(this.casedata)
        .then((res) => {
          console.log(this.casedata)
          // console.log(res);
          if (res.code == 200) {
            console.log(res.data)
          } else {
            // alert("保存失败");
            console.log(res.data)
            return
          }
          console.log(res.data)
        })
        .catch((err) => {
          // alert("保存失败");
        })
      console.log(res.data)
      res.data = this.tableUserData
    },
    // 视频流
    initVideo() {
      // 初始化视频方法 循环列表获取每个视频的id
      this.list.map((item, i) => {
        const myPlayer = this.$video('myVideo' + item.id, {
          // 确定播放器是否具有用户可以与之交互的控件。没有控件，启动视频播放的唯一方法是使用autoplay属性或通过Player API。
          controls: true,
          // 自动播放属性,muted:静音播放
          // autoplay: "muted",
          autoplay: true,
          // muted : muted,
          // 建议浏览器是否应在<video>加载元素后立即开始下载视频数据。
          preload: 'auto',
          // 设置视频播放器的显示宽度（以像素为单位）
          width: '640px',
          // 设置视频播放器的显示高度（以像素为单位）
          height: '360px',
          // 封面图
          poster: item.pic
        })
      })
    },
    // 表格显示点击信息
    handleCurrentChange(val) {
      this.currentRow = val
      console.log(val)
      this.searchUser = val
    },
    showUser(val) {
      this.dialogFormVisible = false
    },
    deleteRow(index, rows) {
      rows.splice(index, 1)
    },
    onSubmit: function() {},
    handleChange: function() {},
    goback(index) {
      this.$router.go(index)
    },
    // 添加user
    addUser() {
      console.log(this.user)
      addUser(this.user)
        .then((res) => {
          if (res.code == 200) {
            // alert("保存成功")
          } else {
            // alert("保存失败")
          }
        })
        .catch((err) => {
          //  alert("保存失败")
        })
      this.dialogFormVisible = false
      this.$router.go(0)
    },
    // 查询user
    getUser() {
      getUser()
        .then((res) => {
          console.log(res)
          if (res.code == 200) {
          } else {
            alert('保存失败')
            console.log(res.data)
            return
          }
          console.log(res.data)
          this.userData = res.data
        })
        .catch((err) => {
          alert('保存失败')
        })
    },
    // 查询dialog中的user
    getTableUser() {
      this.dialogFormVisible = true
      getUser()
        .then((res) => {
          console.log(res)
          if (res.code == 200) {
          } else {
            alert('保存失败')
            console.log(res.data)
            return
          }
          console.log(res.data)
          this.tableUserData = res.data
        })
        .catch((err) => {
          alert('保存失败')
        })
    }
  }
}
</script>
<style scoped>
.container {
  height: 100%;
  width: 100%;
}
.input {
  width: 180px;
}
.login-btn {
  margin-left: 100px;
}
.demo-table-expand {
  font-size: 0;
}
.demo-table-expand label {
  width: 90px;
  color: #99a9bf;
}
.demo-table-expand .el-form-item {
  margin-right: 0;
  margin-bottom: 0;
  width: 50%;
}
.video2 {
  float: left;
  /*padding-left: 10px;*/
  /*padding-right: 10px;*/
  /*padding-bottom: 10px;*/
  padding: 0 5px 5px 5px;
}
</style>
