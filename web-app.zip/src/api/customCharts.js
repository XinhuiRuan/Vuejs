import request from '@/utils/requestMock'

export default {
    // 得到散点图的数据
    getScatterData(index) {
        return request({
            url: `/customCharts/GetScatterData?index=${index}`,
            method: "get"
        })
    },

    // 得到骨架图的数据
    getSkeletonData(index) {
        return request({
            url: `/customCharts/GetSkeletonData/${index}`,
            method: "get"
        })
    },
}