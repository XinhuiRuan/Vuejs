import request from '@/utils/request'

export function addUser(data) {
  return request({
    url: 'http://localhost:9090/api/add',
    method: 'post',
    data
  })
}
export function getUser() {
  return request({
    url: 'http://localhost:9090/api/select',
    method: 'get'
  })
}

export function getSelectUser(data) {
  return request({
    url: 'http://localhost:9090/api/case/select',
    method: 'post',
    data
  })
}

