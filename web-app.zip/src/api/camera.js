import request from '@/utils/request'

export function getUser() {
  return request({
    url: 'http://localhost:9090/api/select',
    method: 'get'
  })
}

export function editUser(data) {
  return request({
    url: 'http://localhost:9090/api/edit',
    method: 'post',
    data
  })
}

export function deleteUser(id) {
  return request({
    url: `http://localhost:9090/api/delete/${id}`,
    method: 'delete'
  })
}
