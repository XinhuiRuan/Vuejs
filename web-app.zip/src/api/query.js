import request from '@/utils/request'

export function getCamera() {
  return request({
    url: 'http://localhost:9090/api/camera/select',
    method: 'get'
  })
}

export function addCamera(data) {
  return request({
    url: 'http://localhost:9090/api/camera/add',
    method: 'post',
    data
  })
}

export function deleteCamera(id) {
  return request({
    url: `http://localhost:9090/api/camera/delete/${id}`,
    method: 'delete'
  })
}

export function editCamera(data) {
  return request({
    url: 'http://localhost:9090/api/camera/edit',
    method: 'put',
    data
  })
}

