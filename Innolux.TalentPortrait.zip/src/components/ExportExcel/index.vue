<template>
  <div class="display">
    <el-button @click="exportExcel()" :disabled="SelectedRows.length == 0">導出</el-button>

    <el-table v-show="false" id="exportTable" :data="SelectedRows">
        <el-table-column v-for="col in TableCols" :key="col.prop" :prop="col.prop" :label="col.label"></el-table-column>
    </el-table>
  </div>
</template>

<script>
import FileSaver from "file-saver";
import XLSX from "xlsx";

export default {
  props:{
      SelectedRows: Array, // 父組件選擇需要導出的行
      TableCols: Array, // 父組件需要導出的table的行
      excelName: String // 導出的excel名字
  },
  components: {},
  name: "exportExcel",
  data() {
    return {};
  },

  methods: {
    exportExcel() {
      /* generate workbook object from table */
      let wb = XLSX.utils.table_to_book(
        document.querySelector("#exportTable")
      );
      /* get binary string as output */
      let wbout = XLSX.write(wb, {
        bookType: "xlsx",
        bookSST: true,
        type: "array"
      });
      try {
        FileSaver.saveAs(
          new Blob([wbout], { type: "application/octet-stream" }),
          this.excelName + ".xlsx"
        );
      } catch (e) {
        if (typeof console !== "undefined") console.log(e, wbout);
      }
      return wbout;
    }
  }
};
</script>

<style scoped>
.display{
  display: inline-block;
}
</style>