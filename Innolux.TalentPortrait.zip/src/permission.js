import router from './router'
import store from './store'
import { Message } from 'element-ui'
import NProgress from 'nprogress' // progress bar
import 'nprogress/nprogress.css' // progress bar style
import { getToken } from '@/utils/auth' // get token from cookie
import getPageTitle from '@/utils/get-page-title'
import { resetRouter } from '@/router'
import errRoutes from '@/router/modules/error-page.js'
import routerMap from '@/routerMap.js'

NProgress.configure({ showSpinner: false }) // NProgress Configuration

const whiteList = ['/login'] // no redirect whitelist

router.beforeEach(async(to, from, next) => {
  // start progress bar
  NProgress.start()
  // set page title
  document.title = getPageTitle(to.meta.title)
  
  // determine whether the user has logged in
  const hasToken = getToken()
  
  if (hasToken) {
    if (to.path === '/login') {
      // if is logged in, redirect to the home page
      next({ path: '/' })
      NProgress.done()
    } else {
      const hasGetUserInfo = store.getters.empno
      if (hasGetUserInfo) {
        
        next()
      } else {
        try {
          //獲取userinfo
          await store.dispatch('user/getInfo')
          //刪除tagsView
          await store.dispatch('tagsView/delAllViews', null, { root: true })

          
          //獲取動態路由
          const accessRoutes= await store.dispatch('permission/generateRoutes', hasToken)
          
          //添加動態路由
          router.addRoutes(accessRoutes.concat(errRoutes))
          //將動態路由渲染到菜單欄
          console.log( store.getters.routes)
          store.getters.routes.forEach((item,index) => {
            router.options.routes[index] = item;
         })
         //權限驗證，無權限的路由指向401
         let tempath=[]
         store.getters.routes.forEach(item=>{
            if (item.redirect) {
              tempath.push(item.redirect)
            }
            else{
              if (item.children && item.children.length>0) {
                item.children.forEach(child=>{
                  tempath.push(`${item.path}/${child.path}`)
                })
              }
              else{
                tempath.push(item.path)
              }
            }
          
         })
         if (!tempath.includes(to.path)) {
           next('/error/401')
            return
         }
         console.log(router.options)
         console.log(tempath)
         
          next({ ...to, replace: true }) //菜单权限更新完成,重新进一次当前路由
        } catch (error) {
          // remove token and go to login page to re-login
          await store.dispatch('user/resetToken')
          Message.error(error || 'Has Error')
          next(`/login?redirect=${to.path}`)
          NProgress.done()
        }
      }
    }
  } else {
    /* has no token*/

    if (whiteList.indexOf(to.path) !== -1) {
      // in the free login whitelist, go directly
      next()
    } else {
      // other pages that do not have permission to access are redirected to the login page.
      next(`/login?redirect=${to.path}`)
      NProgress.done()
    }
  }
})

router.afterEach(() => {
  // finish progress bar
  NProgress.done()
})
