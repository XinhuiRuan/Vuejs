import { constantRoutes } from '@/router'
import { getRoutes } from '@api/permission'
import routerMap from '@/routerMap.js'
import $usedUtils  from '@/utils/usedUtils.js'


function generateRoutesFromMenu(asyncRoutes = []){
  asyncRoutes.forEach((item)=>{
     item.component=routerMap[item.componentMap];
     item.path='/'+item.name
     if (item.children && item.children.length > 0) {
       item.children=transferChildren(item.children); 
     }
  })
  return asyncRoutes
}

function transferChildren(childrenArr){    
  //格式化name,component,meta属性  
  console.log(childrenArr)  
  childrenArr.map((cur,index)=>{
      cur.name = cur.name;
      cur.component = routerMap[cur.componentMap];
      cur.path = cur.name;
      if( cur.children && cur.children.length > 0){
          transferChildren(cur.children)
      }
  })
  return childrenArr
}

const state = {
  routes: [],
  roles:[],
  staticRoutes: constantRoutes.concat([])
}

const mutations = {
  SET_ROUTES: (state, routes) => {
    state.staticRoutes= state.staticRoutes.filter(item=>{
      return item.id==undefined
    })
    state.routes = state.staticRoutes.concat(routes)
  },
  SET_ROLES: (state, source) => {
    let roles =[]
    source.forEach(item=>{
      item.meta.roles.forEach(role=>{
        if (roles.indexOf(role)<=-1) {
          roles.push(role)
        }
      })
    })
 
    state.roles=roles;

  }
}

const actions = {
  generateRoutes({ commit,state }, token) {
    return new Promise((resolve,reject) => {
      getRoutes(token).then(res=>{
        commit('SET_ROLES', res)
       let cloneData = JSON.parse(JSON.stringify(res)); // 对源数据深度克隆
       cloneData= cloneData.filter(father => {
        // 循环所有项，并添加children属性
        let branchArr = cloneData.filter(child => father.id == child.parentId); // 返回每一项的子级数组
        branchArr.length > 0 ? (father.children = branchArr) : ""; //给父级添加一个children属性，并赋值
        return father.parentId == 0; //返回第一层
      });
      let accessedRoutes= generateRoutesFromMenu(cloneData);
       //$usedUtils.arrayDiff(constantRoutes,accessedRoutes,"name")
        commit('SET_ROUTES', accessedRoutes)
        resolve(accessedRoutes)
      }).catch(err=>{
        reject(err)
      })
     
    })
  }
}

export default {
  namespaced: true,
  state,
  mutations,
  actions
}
