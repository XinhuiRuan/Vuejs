import request from '@/utils/request'

export default{
    // 我的畫像 ——> 獲取基本信息
    getInfos(empno) {
        return request({
          url: `/tp/GetPersonInfo?empno=${empno}`,
          method: 'get'
        })
    },

    // 我的畫像 ——> 必備知識一階
    getKnowledgeFirst(params) {
        return request({
          url: `/tp/GetKnowledgeFirst`,
          method: 'post',
          data: params
        })
    },

    // 我的畫像 ——> 必備知識二階
    getKnowledgeSecond(params) {
        return request({
          url: `/tp/GetKnowledgeSecond`,
          method: 'post',
          data: params
        })
    },

    // 我的畫像 ——> 已訓課程明細
    getStudiedList(params) {
      return request({
        url: `/tp/GetStudiedList`,
        method: 'post',
        data: params
      })
    },

    // 我的畫像 ——> 專業技能
    getSkills(params) {
        return request({
          url: `/tp/GetSkills`,
          method: 'post',
          data: params
        })
    },

    // 我的畫像 ——> 專案經驗
    getProjects(params) {
      return request({
        url: `/tp/GetProjects`,
        method: 'post',
        data: params
      })
    },

    // 我的畫像 ——> 任職履歷
    getExperience(empno) {
      return request({
        url: `/tp/GetExperience?empno=${empno}`,
        method: 'get'
      })
  },
}