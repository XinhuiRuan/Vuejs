<template>
  <div class="app-container">
    <div>
      <span v-permission="['admin']" class="permission-alert">
        仅
        <el-tag class="permission-tag" size="small">admin</el-tag>可以看到
      </span>
      <el-tag
        v-permission="['admin']"
        class="permission-sourceCode"
        type="info"
      >v-permission="['admin']"</el-tag>
    </div>

    <div>
      <span v-permission="['hr']" class="permission-alert">
        仅
        <el-tag class="permission-tag" size="small">hr</el-tag>可以看到
      </span>
      <el-tag v-permission="['hr']" class="permission-sourceCode" type="info">v-permission="['hr']"</el-tag>
    </div>

    <el-tabs type="border-card" style="width:550px;margin-top:20px;">
      <el-tab-pane v-if="checkPermission(['admin'])" label="Admin">
        Admin 可以看到
        <el-tag class="permission-sourceCode" type="info">v-if="checkPermission(['admin'])"</el-tag>
      </el-tab-pane>

      <el-tab-pane v-if="checkPermission(['hr'])" label="hr">
        hr 可以看到
        <el-tag class="permission-sourceCode" type="info">v-if="checkPermission(['hr'])"</el-tag>
      </el-tab-pane>

      <el-tab-pane v-if="checkPermission(['admin','hr'])" label="Admin-OR-Hr">
        Both admin or hr 都可以看到
        <el-tag class="permission-sourceCode" type="info">v-if="checkPermission(['admin','hr'])"</el-tag>
      </el-tab-pane>
    </el-tabs>
  </div>
</template>

<script>
import permission from "@/directive/permission/index.js"; // 权限判断指令
import checkPermission from "@/utils/permission"; // 权限判断函数
export default {
  name: "demo",
  data() {
    return {};
  },
  methods: {
    checkPermission
  },
  directives: {
    permission
  }
};
</script>
<style lang="scss" scoped>
.app-container {
  /deep/ .permission-alert {
    width: 320px;
    margin-top: 15px;
    background-color: #f0f9eb;
    color: #67c23a;
    padding: 8px 16px;
    border-radius: 4px;
    display: inline-block;
  }
  /deep/ .permission-sourceCode {
    margin-left: 15px;
  }
  /deep/ .permission-tag {
    background-color: #ecf5ff;
  }
}
</style>
