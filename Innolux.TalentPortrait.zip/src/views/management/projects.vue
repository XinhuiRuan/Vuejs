<template>
  <div class>
   
    <div class="query_area" v-if="!isPortraitPage">
      <el-form :inline="true" :model="queryParams">
        <el-form-item>
          <el-col :span="11">
            <el-form-item prop="queryDateFrom">
              <el-date-picker
                type="date"
                placeholder="專案起始時間"
                v-model="queryParams.queryDateFrom"
                style="width: 100% "
                value-format="yyyy-MM-dd"
              ></el-date-picker>
            </el-form-item>
          </el-col>
          <el-col class="line" :span="1">~</el-col>
          <el-col :span="11">
            <el-form-item prop="queryDateTo">
              <el-date-picker
                type="date"
                placeholder="專案起始時間"
                v-model="queryParams.queryDateTo"
                style="width: 100% "
                value-format="yyyy-MM-dd"
              ></el-date-picker>
            </el-form-item>
          </el-col>
        </el-form-item>
        <el-form-item>
          <remote-user></remote-user>
        </el-form-item>
        <el-form-item>
          <remote-dept></remote-dept>
        </el-form-item>
        <br />

        <el-form-item v-for="selection in Selections" :key="selection.key">
          <el-select v-model="queryParams[selection.key]" :placeholder="selection.value">
            <el-option
              v-for="item in selection.options"
              :key="item.value"
              :label="item.label"
              :value="item.value"
            ></el-option>
          </el-select>
        </el-form-item>

        <el-form-item>
          <el-button type="primary" @click="getProjectsTable">查询</el-button>
          <upload-excel-btn
            v-if="!isSignPage"
            :tableCols="tableCols"
            :page="'projects'"
            @uploadFlag="handleUploadResult"
          ></upload-excel-btn>
        </el-form-item>
      </el-form>
    </div>
    <div class="table_area">
      <el-table
        ref="multipleTable"
        :data="projectsTable"
        tooltip-effect="dark"
        style="width: 100%"
        highlight-current-row
        border
        @selection-change="handleSelectionChange"
        @row-click="handleRowClick"
      >
        <el-table-column v-if="!(isSignPage || isPortraitPage)" type="selection"></el-table-column>
        <template v-for="col in tableCols">
          <el-table-column
            :key="col.prop"
            :prop="col.prop"
            :label="col.label"
            show-overflow-tooltip
          ></el-table-column>
        </template>
      </el-table>
      <div class="btnGroup" v-if="!(isSignPage || isPortraitPage)">
        <el-button @click="removeProjects()" :disabled="multipleSelection.length == 0">刪除</el-button>
        <export-excel :SelectedRows="multipleSelection" :TableCols="tableCols" excelName="專案維護導出清單"></export-excel>
      </div>
      <div class="pagination">
        <el-pagination
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          :current-page="queryParams.currentPage"
          :page-sizes="pageSizes"
          :page-size="queryParams.pageSize"
          layout="total, sizes, prev, pager, next, jumper"
          :total="total"
        ></el-pagination>
      </div>
    </div>
  </div>
</template>

<script>
import portraitApi from "@/api/portrait";
import managementApi from "@/api/management";
import remoteUser from "@/components/remote-user";
import remoteDept from "@/components/remote-dept";
import uploadExcelBtn from "@/views/management/uploadExcelBtn";
import exportExcel from "@/components/ExportExcel";

export default {
  props: ["isSignPage", "isPortraitPage","portraitEmpno"],

  components: {
    remoteUser,
    remoteDept,
    exportExcel,
    uploadExcelBtn
  },

  data() {
    return {
      userId: "18009380", // 之後需要去狀態管理取值
      queryParams: {
        // 查詢框內的信息
        dept: "",
        empno: "",
        project: "",
        type: "",
        expansion: "",
        benefit: "",
        role: "",
        queryDateFrom: "",
        queryDateTo: "",
        pageSize: 10, // 每頁顯示的條數
        currentPage: 1 // 當前頁
      },
      Selections: [
        // 下拉框的信息
        { key: "type", value: "專案類別", options: [] },
        { key: "expansion", value: "可平展性", options: [] },
        { key: "benefit", value: "達成效益", options: [] },
        { key: "role", value: "角色", options: [] }
      ],
      pageSizes: [10, 20, 50],
      tableCols: [
        // table的欄位信息
        { prop: "empno", label: "工號" },
        { prop: "name", label: "姓名" },
        { prop: "dept", label: "廠處" },
        { prop: "project", label: "專案名稱" },
        { prop: "type", label: "專案類別" },
        { prop: "expansion", label: "可平展性" },
        { prop: "benefit", label: "達成效益" },
        { prop: "startDate", label: "起始時間" },
        { prop: "endDate", label: "結束時間" },
        { prop: "role", label: "角色" },
        { prop: "grade", label: "積分" }
      ],
      total: 0,
      projectsTable: [],
      multipleSelection: []
    };
  },

  created() {
    this.initPage();
  },

  methods: {
    // 根據不同的頁面進入，初始化數據
    initPage() {
      if (this.isSignPage == true) {
        // 專案的簽核界面需要重新設置table的欄位信息：將角色和積分欄位替換掉成PM和進度
        this.tableCols.pop()
        this.tableCols.pop()
        this.tableCols.push({
          prop: "pm", label: "PM"
        })
        this.tableCols.push({
          prop: "signState", label: "進度"
        })

        // 下拉框需要刪除角色欄位
        this.Selections.pop();
      }else if(this.isPortraitPage == true){
        // 第一步：修改分頁器
        this.queryParams.pageSize = 5;
        this.pageSizes = [5, 10, 20];
        // 第二步：我的畫像頁面需要刪除前三個欄位：工號，姓名，廠處；新增年份、狀態欄位
        this.tableCols.splice(0, 3);
        this.tableCols.unshift({
          prop: "year", label: "年份"
        })
        this.tableCols.push({
          prop: "signState", label: "進度"
        })
        // 第三步：立刻查詢table
        this.queryParams.empno = this.portraitEmpno;
        this.getProjectsTable();
      }

      if(this.isPortraitPage != true){
        this.getProjectsOptions();
      }
    },

    // 獲取後台維護的四個下拉框的數據
    getProjectsOptions() {
      managementApi
        .getProjectsOptions()
        .then(response => {
          // 遍歷將options賦值給下拉框
          for (let item in response) {
            for (let selection of this.Selections) {
              if (selection.key == item) {
                selection.options = response[item];
              }
            }
          }
        })
        .catch(error => {
          this.$message.error(error.message);
        });
    },

    // 後台查詢，獲得專案表格的數據
    getProjectsTable() {
      portraitApi
        .getProjects(this.queryParams)
        .then(response => {
          this.total = response.total;
          this.projectsTable = response.rows;
          // this.$message.success("查詢成功");
        })
        .catch(error => {
          this.$message.error(error.message);
        });
    },
    // 用於專案簽核：當單機一行時觸發，將行id傳給父組件
    handleRowClick(row, column, event) {
      if (this.isSignPage == true) {
        this.$emit("getClickedRowId", row.id);
      }
    },

    // 表格單選或多選觸發該事件
    handleSelectionChange(selectedRows) {
      this.multipleSelection = selectedRows;
    },
    // 改變每頁的條數展示
    handleSizeChange(val) {
      this.queryParams.pageSize = val;
      this.getProjectsTable();
    },
    // 跳轉到其他頁面
    handleCurrentChange(val) {
      this.queryParams.currentPage = val;
      this.getProjectsTable();
    },

    // 刪除技能
    removeProjects() {
      // 給傳給後台的數據加上刪除的操作人
      let params = {
        rows: this.multipleSelection,
        type: "projects",
        updateBy: this.userId
      };
      managementApi
        .removeById(params)
        .then(response => {
          this.$message.success("刪除成功！");
          // 刪除成功，重新查詢數據
          this.getProjectsTable();
        })
        .catch(error => {
          this.$message.error(error.message);
        });
    },

    // 子組件成功上傳EXCEL之後，重新查詢Table
    handleUploadResult(flag) {
      if (flag) {
        this.getProjectsTable();
      }
    }
  }
};
</script>

<style>
.query_area {
  width: 96%;
  margin: 2% auto 0 auto;
}
.el-form-item {
  margin-right: 2%;
}

.table_area {
  width: 96%;
  margin: 0 auto;
}
.table_area .btnGroup {
  margin: 1% 1% 1% 0;
  display: inline-block;
}
.table_area .pagination {
  display: inline-block;
}
.pagination {
  margin-top: 1%;
}

/* 重新設置行高度 */
.el-table__header tr,
.el-table__header th {
  padding: 0;
  height: 44px;
}
.el-table__body tr,
.el-table__body td {
  padding: 0;
  height: 44px;
}
</style>