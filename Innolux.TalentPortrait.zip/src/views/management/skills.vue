<template>
  <div class>
    <div class="query_area" v-if="!isPortraitPage">
      <el-form :inline="true" :model="queryParams">
        <el-form-item>
          <el-col :span="11">
            <el-form-item prop="queryDateFrom">
              <el-date-picker
                type="date"
                placeholder="提交時間"
                v-model="queryParams.queryDateFrom"
                style="width: 100% "
                value-format="yyyy-MM-dd"
              ></el-date-picker>
            </el-form-item>
          </el-col>
          <el-col class="line" :span="1">-</el-col>
          <el-col :span="11">
            <el-form-item prop="queryDateTo">
              <el-date-picker
                type="date"
                placeholder="提交時間"
                v-model="queryParams.queryDateTo"
                style="width: 100% "
                value-format="yyyy-MM-dd"
              ></el-date-picker>
            </el-form-item>
          </el-col>
        </el-form-item>
        <el-form-item>
          <remote-user></remote-user>
        </el-form-item>
        <el-form-item>
          <remote-dept></remote-dept>
        </el-form-item>
        <br />

        <el-form-item>
          <el-select v-model="queryParams.skillType" placeholder="技能類別">
            <el-option
              v-for="item in skillTypeOptions"
              :key="item.value"
              :label="item.label"
              :value="item.value"
            ></el-option>
          </el-select>
        </el-form-item>
        <el-form-item>
          <el-input v-model.trim="queryParams.skillName" placeholder="技能名稱"></el-input>
        </el-form-item>

        <el-form-item>
          <el-button type="primary" @click="getSkillsTable">查询</el-button>
          <upload-excel-btn :tableCols="tableCols" :page="'skills'" @uploadFlag="uploadResult"></upload-excel-btn>
        </el-form-item>
      </el-form>
    </div>
    <div class="table_area">
      <el-table
        ref="multipleTable"
        :data="skillsTable"
        tooltip-effect="dark"
        style="width: 100%"
        highlight-current-row
        border
        @selection-change="handleSelectionChange"
      >
        <el-table-column type="selection" v-if="!isPortraitPage"></el-table-column>
        <template v-for="col in tableCols">
          <el-table-column
            v-if="col.prop != 'path'"
            :key="col.prop"
            :prop="col.prop"
            :label="col.label"
            show-overflow-tooltip
          ></el-table-column>
          <el-table-column
            v-else
            :key="col.prop"
            :prop="col.prop"
            :label="col.label"
            show-overflow-tooltip
          >
            <template slot-scope="scope">
              <a v-if="scope.row.path" :href="scope.row.path" target="_blank">
                <el-button type="info" plain icon="el-icon-link" circle size="mini"></el-button>
              </a>
            </template>
          </el-table-column>
        </template>
        <el-table-column label="操作" v-if="!isPortraitPage">
          <template slot-scope="scope">
            <el-upload
              multiple
              action
              accept=".jpg, .jpeg, .png"
              :http-request="customUploadFile"
              :show-file-list="false"
            >
              <el-button
                @click="recordRowId(scope.row.id)"
                size="mini"
                type="primary"
                plain
                round
              >上傳附件</el-button>
            </el-upload>
            <!--  -->
          </template>
        </el-table-column>
      </el-table>
      <div class="btnGroup" v-if="!isPortraitPage">
        <el-button @click="removeSkills()" :disabled="multipleSelection.length == 0">刪除</el-button>
        <export-excel :SelectedRows="multipleSelection" :TableCols="tableCols" excelName="技能維護導出清單"></export-excel>
      </div>
      <div class="pagination">
        <el-pagination
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          :current-page="queryParams.currentPage"
          :page-sizes="pageSizes"
          :page-size="queryParams.pageSize"
          layout="total, sizes, prev, pager, next, jumper"
          :total="total"
        ></el-pagination>
      </div>
    </div>
  </div>
</template>

<script>
import portraitApi from "@/api/portrait";
import managementApi from "@/api/management";
import { fileUpload } from "@/api/file";
import remoteUser from "@/components/remote-user";
import remoteDept from "@/components/remote-dept";
import uploadExcelBtn from "@/views/management/uploadExcelBtn";
import exportExcel from "@/components/ExportExcel";

export default {
  props: ["isPortraitPage", "portraitEmpno"],

  components: {
    remoteUser,
    remoteDept,
    uploadExcelBtn,
    exportExcel
  },

  data() {
    return {
      userId: "18009380", // 之後需要去狀態管理取值
      queryParams: {
        dept: "",
        empno: "",
        skillType: "",
        skillName: "",
        queryDateFrom: "",
        queryDateTo: "",
        pageSize: 10, // 每頁顯示的條數
        currentPage: 1 // 當前頁
      },
      pageSizes: [10, 20, 50],
      skillTypeOptions: [],
      tableCols: [
        { prop: "empno", label: "工號" },
        { prop: "name", label: "姓名" },
        { prop: "dept", label: "廠處" },
        { prop: "skillType", label: "技能類別" },
        { prop: "skillName", label: "技能名稱" },
        { prop: "skillLevel", label: "等級" },
        { prop: "getTime", label: "獲得時間" },
        { prop: "skillGoal", label: "積分" },
        { prop: "path", label: "附件" }
      ],
      total: 0,
      skillsTable: [],
      curRowId: "",
      multipleSelection: []
    };
  },

  created() {
    this.initPage()
  },

  methods: {
    // 根據不同的頁面進入，初始化數據
    initPage() {
      if (this.isPortraitPage == true) {
        // 作為我的畫像的子組件進入
        // 第一步：修改分頁器
        this.queryParams.pageSize = 5;
        this.pageSizes = [5, 10, 20];
        // 第二步：修改table的顯示欄位：刪除前三個欄位：工號，姓名，廠處；新增狀態欄位
        this.tableCols.splice(0, 3);
        this.tableCols.push({
          prop: "signState",
          label: "狀態"
        });
        // 第三步：立刻查詢table
        this.queryParams.empno = this.portraitEmpno;
        this.getSkillsTable();
      } else {
        // 正常進入技能維護頁面需要查詢下拉框數據
        this.getSkillsOptions();
      }
    },
   
    // 獲取後台維護的技能類別下拉選項
    getSkillsOptions() {
      managementApi
        .getSkillsOptions()
        .then(response => {
          this.skillTypeOptions = response;
        })
        .catch(error => {
          this.$message.error(error.message);
        });
    },

    // 後台查詢，獲得技能表格的數據
    getSkillsTable() {
      portraitApi
        .getSkills(this.queryParams)
        .then(response => {
          this.total = response.total;
          this.skillsTable = response.rows;
          // this.$message.success("查詢成功");
        })
        .catch(error => {
          this.$message.error(error.message);
        });
    },
    // 點擊上傳附件，得到當前行的ID
    recordRowId(rowId) {
      this.curRowId = rowId;
    },

    // 表格單選或多選觸發該事件
    handleSelectionChange(selectedRows) {
      this.multipleSelection = selectedRows;
    },
    // 改變每頁的條數展示
    handleSizeChange(val) {
      this.queryParams.pageSize = val;
      this.getSkillsTable();
    },
    // 跳轉到其他頁面
    handleCurrentChange(val) {
      this.queryParams.currentPage = val;
      this.getSkillsTable();
    },

    // 刪除技能
    removeSkills() {
      // 給傳給後台的數據加上刪除的操作人
      let params = {
        rows: this.multipleSelection,
        type: "skills",
        updateBy: this.userId
      };
      managementApi
        .removeById(params)
        .then(response => {
          this.$message.success("刪除成功！");
          // 刪除成功，重新查詢數據
          this.getSkillsTable();
        })
        .catch(error => {
          this.$message.error(error.message);
        });
    },

    // 子組件成功上傳EXCEL之後，重新查詢Table
    uploadResult(flag) {
      if (flag) {
        this.getSkillsTable();
      }
    },

    // 自定義上傳文件方法
    customUploadFile(file) {
      console.log('file',file)
      fileUpload(file, { id: this.curRowId })
        .then(response => {
          for (let row of this.skillsTable) {
            if (row.id == this.curRowId) {
              row.path = response.path;
              break;
            }
          }
          this.$message.success("上傳成功");
        })
        .catch(error => {
          this.$message.error(error.message);
        });
    }
  }
};
</script>

<style>
.query_area {
  width: 96%;
  margin: 2% auto 0 auto;
}
.el-form-item {
  margin-right: 2%;
}

.table_area {
  width: 96%;
  margin: 0 auto;
}
.table_area .btnGroup {
  margin: 1% 1% 1% 0;
  display: inline-block;
}
.table_area .pagination {
  display: inline-block;
}
.pagination {
  margin-top: 1%;
}

/* 重新設置行高度 */
.el-table__header tr,
.el-table__header th {
  padding: 0;
  height: 44px;
}
.el-table__body tr,
.el-table__body td {
  padding: 0;
  height: 44px;
}
</style>