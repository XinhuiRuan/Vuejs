<template>
  <div class style="display:inline-block;">
    <el-button type="primary" @click="dialogUploadVisible=true">上傳</el-button>

    <!-- excel上傳的對話框 -->
    <el-dialog :visible.sync="dialogUploadVisible">
      <upload-excel
        :buttonText="buttonText"
        :areaText="areaText"
        :fileFull="fileFull"
        :loading="loading"
        @openloading="openloading($event)"
        :on-success="handleSuccess"
        :before-upload="beforeUpload"
      ></upload-excel>
    </el-dialog>
  </div>
</template>

<script>
import uploadExcel from "@/components/UploadExcel";
import managementApi from "@/api/management";

export default {
  props: {
    tableCols: {
      type: Array
    },
    page: {
      type: String
    }
  },
  components: {
    uploadExcel
  },

  data() {
    return {
      userId: "18009380", // 之後需要去狀態管理取值
      buttonText: "",
      areaText: "",
      fileFull: "",
      loading: false,
      dialogUploadVisible: false
    };
  },

  created() {
    if (this.page == "projects") {
      this.buttonText = "上传專案經驗";
      this.areaText = "点击上传專案經驗";
      this.fileFull = "./download/模板-專案經驗.xlsx";
    } else if (this.page == "skills") {
      this.buttonText = "上传專業技能";
      this.areaText = "点击上传專業技能";
      this.fileFull = "./download/模板-專業技能.xlsx";
    }
  },

  methods: {
    // EXCEL上傳時打開加載框
    openloading(flag) {
      this.loading = flag;
    },

    // EXCEL上傳之前檢查文件的大小
    beforeUpload(file) {
      const isLt1M = file.size / 1024 / 1024 < 1;
      if (isLt1M) {
        return true;
      }
      this.$message({
        message: "大小不能超过1M",
        type: "warning"
      });
      return false;
    },

    // EXCEL上傳成功后的回調函數
    handleSuccess({ results, header }) {
      if (results == 0) {
        this.$message({
          message: "excel無上傳內容！",
          type: "warning"
        });
        this.loading = false;
        return;
      }

      // 得到欄位的中文名和代碼的對應關係
      let mapping = {};
      this.tableCols.forEach(col => {
        mapping[col.label] = col.prop;
      });

      // 判斷excel的欄位是否都是可上傳的欄位
      for (let col of header) {
        if (!mapping[col]) {
          this.$message({
            message: `${col}是無效的上傳欄位`,
            type: "warning"
          });
          this.loading = false;
          return;
        }
      }

      // 處理上傳的數據
      let uploadRows = []; // 最終傳到後台的數據
      let res = new RegExp(/^\d{4}\-\d{2}\-\d{2}$/); // 正則表達式：判斷日期格式為"yyyy-mm-dd"
      for (let i = 0; i < results.length; i++) {
        let row = results[i];
        let tmp = {};
        for (let item in row) {
          if (item.indexOf("時間") != -1 && !res.test(row[item])) {
            // 時間欄位，需要判斷時間格式
            this.$message({
              message: `第${i + 1}行的${item}格式必須為yyyy-mm-dd`,
              type: "warning"
            });
            this.loading = false;
            return;
          }
          tmp[mapping[item]] = row[item].toString();
        }
        tmp.signState = "結案" // excel上傳狀態都為結案
        uploadRows.push(tmp);
      }

      // 傳給後台，上傳數據
      let data = {
        rows: uploadRows,
        updateBy: this.userId
      };

      let tmp;
      if (this.page == "projects") {
        tmp = managementApi.addProjects(data);
      } else if (this.page == "skills") {
        tmp = managementApi.addSkills(data);
      }

      tmp
        .then(response => {
          this.loading = false;
          this.dialogUploadVisible = false;
          this.$message.success("上傳成功");

          this.$emit("uploadFlag", true);
        })
        .catch(error => {
          this.loading = false;
          this.$message.error(error.message);
        });
    }
  }
};
</script>

<style scoped>
</style>