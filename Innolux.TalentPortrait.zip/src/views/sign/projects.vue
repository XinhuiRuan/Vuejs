<template>
  <div class>
    <!-- 專案進度主頁面組件 -->
    <projects :isSignPage="true" @getClickedRowId="handleRowClick"></projects>

    <!-- 專案詳細信息頁面組件 -->
    <el-dialog :visible.sync="dialogVisible" width="70%">
      <!-- :before-close="handleClose" -->
      <!-- 子組件的內容 -->
      <projects-detail :id="projectId" :isSignPage="true"></projects-detail>

      <!--  <span slot="footer" class="dialog-footer">
            <el-button @click="dialogVisible = false">取 消</el-button>
            <el-button type="primary" @click="dialogVisible = false">确 定</el-button>
      </span>-->
    </el-dialog>
  </div>
</template>

<script>
import projects from "@/views/management/projects";
import projectsDetail from "@/views/portrait/projectsDetail";

export default {
  components: {
    projects,
    projectsDetail
  },

  data() {
    return {
      dialogVisible: false,
      projectId: ""
    };
  },

  methods: {
    // 打開專案詳細信息頁面，并傳入ID值
    handleRowClick(rowId) {
      this.projectId = rowId;
      this.dialogVisible = true;
    }

    // handleClose(done) {
    //     this.$confirm('确认关闭？')
    //       .then(_ => {
    //         done();
    //       })
    //       .catch(_ => {});
    //   }
  }
};
</script>

<style scoped>
/* .el-dialog__body{
  padding-bottom: 0;
} */
</style>