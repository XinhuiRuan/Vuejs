<template>
  <div class>
    <el-collapse v-model="activeNames" @change="handleChange">
      <el-collapse-item title="專案基本信息" name="1">
        <el-form ref="form" :model="projectsForm" label-width="80px" size="medium">
          <el-form-item label="專案名稱">
            <el-col :span="6">
              <el-input v-model="projectsForm.project"></el-input>
            </el-col>
          </el-form-item>
          <el-form-item label="專案時間">
            <el-col :span="6">
              <el-form-item prop="queryDateFrom">
                <el-date-picker
                  type="date"
                  placeholder="选择日期"
                  v-model="projectsForm.queryDateFrom"
                  style="width: 100% "
                  value-format="yyyy-MM-dd"
                ></el-date-picker>
              </el-form-item>
            </el-col>
            <el-col class="line" style="text-align:center" :span="1">~</el-col>
            <el-col :span="6">
              <el-form-item prop="queryDateTo">
                <el-date-picker
                  type="date"
                  placeholder="选择日期"
                  v-model="projectsForm.queryDateTo"
                  style="width: 100% "
                  value-format="yyyy-MM-dd"
                ></el-date-picker>
              </el-form-item>
            </el-col>
          </el-form-item>

          <!-- 循環遍歷四個下拉框 -->
          <el-form-item
            v-for="selection in Selections"
            :label="selection.value"
            :key="selection.key"
            style="display:inline-block;"
          >
            <el-select v-model="projectsForm[selection.key]">
              <el-option
                v-for="item in selection.options"
                :key="item.value"
                :label="item.label"
                :value="item.value"
              ></el-option>
            </el-select>
          </el-form-item>
        </el-form>
      </el-collapse-item>
      <el-collapse-item title="專案PM進度匯報" name="2">
        <div>待開發</div>
      </el-collapse-item>
      <el-collapse-item title="專案成員進度匯報" name="3">
        <div>待開發</div>
      </el-collapse-item>
      <el-collapse-item title="專案項目變更" name="4">
        <div>待開發</div>
      </el-collapse-item>
      <el-collapse-item title="簽核歷程" name="5">
        <div>待開發</div>
      </el-collapse-item>
    </el-collapse>

    <div class="btn_area">
        <el-button type="primary" @click="onSubmit">提交</el-button>
        <el-button type="primary" @click="onSign" v-if="isSignPage">簽核</el-button>
    </div>
    
  </div>
</template>

<script>
import managementApi from "@/api/management";

export default {
  props: ["id","isSignPage"], // 專案的id

  components: {},

  data() {
    return {
      projectsForm: {
        // 專案基本信息
        dept: "",
        empno: "",
        project: "",
        type: "",
        expansion: "",
        benefit: "",
        role: "",
        queryDateFrom: "",
        queryDateTo: "",
        pageSize: 10, // 每頁顯示的條數
        currentPage: 1 // 當前頁
      },
      Selections: [
        // 下拉框的信息
        { key: "type", value: "專案類別", options: [] },
        { key: "expansion", value: "可平展性", options: [] },
        { key: "benefit", value: "達成效益", options: [] },
        { key: "role", value: "角色", options: [] }
      ],
      activeNames: ["1"],
      formInline: {
        user: "",
        region: ""
      }
    };
  },

  created() {
    this.getProjectsOptions();
    
  },

  methods: {
    // 獲取後台維護的四個下拉框的數據
    getProjectsOptions() {
      managementApi
        .getProjectsOptions()
        .then(response => {
          // 遍歷將options賦值給下拉框
          for (let item in response) {
            for (let selection of this.Selections) {
              if (selection.key == item) {
                selection.options = response[item];
              }
            }
          }
        })
        .catch(error => {
          this.$message.error(error.message);
        });
    },

    handleChange(val) {
      console.log(val);
    },
    onSubmit() {
      console.log("submit!");
    },
    onSign() {
      console.log("sign!");
    }
  }
};
</script>

<style scoped>
.btn_area{
    margin-top: 2%;
    text-align: center;
}

</style>