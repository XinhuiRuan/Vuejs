<template>
  <div class>
    <!-- <remote-user></remote-user>     -->
    <el-collapse v-model="activeNames">
      <el-collapse-item name="1">
        <template slot="title">
          <div class="title_area">
            <span>基本信息</span>
          </div>
        </template>
        <div class="content_area">
          <table>
            <tr>
              <td>工號：{{infos.empno}}</td>
              <td>入職：{{infos.entry}}</td>
              <td>狀態：{{infos.status}}</td>
              <td>年龄：{{infos.age}}</td>
              <td>性別：{{infos.sex}}</td>
              <td rowspan="3" class="photo">
                <div class="block">
                  <el-avatar shape="square" :size="80" :src="infos.selfie"></el-avatar>
                </div>
              </td>
            </tr>
            <tr>
              <td>姓名：{{infos.name}}</td>
              <td>職等：{{infos.jobLevel}}</td>
              <td>職務：{{infos.jobDuty}}</td>
              <td>部门：{{infos.department}}</td>
              <td>系統：{{infos.system}}</td>
            </tr>
            <tr>
              <td>學歷：{{infos.diploma}}</td>
              <td>學校：{{infos.school}}</td>
              <td>專業：{{infos.major}}</td>
              <td>畢業：{{infos.graduateYear}}</td>
              <td></td>
            </tr>
          </table>
        </div>
      </el-collapse-item>
      <el-collapse-item name="2">
        <template slot="title">
          <div class="title_area">
            <span>必備知識 [加权分落点：85, TOP 10% ]</span>
            <i class="el-icon-question"></i>
            <span style="color: red">（Tips : 課程認證進度有落後哦,要加油！）</span>
          </div>
        </template>
        <div class="content_area iStudy">
          <i-study :empno="empno"></i-study>
        </div>
      </el-collapse-item>
      <el-collapse-item name="3">
        <template slot="title">
          <div class="title_area">
            <span>專業技能 [加权分落点：60, TOP 10% ]</span>
            <i class="el-icon-question"></i>
            <span style="color: red">（Tips : 應修技能還未達標,要繼續努力哦！）</span>
          </div>
        </template>

        <div class="content_area skills">
          <skills :isPortraitPage="true" :portraitEmpno="empno"></skills>
        </div>
      </el-collapse-item>
      <el-collapse-item name="4">
        <template slot="title">
          <div class="title_area">
            <el-col :span="22">
              <span>專案經驗 [加权分落点：70, TOP 30% ]</span>
              <i class="el-icon-question"></i>
              <span style="color: red">（Tips : 有多項專案積累,你很棒哦！）</span>
            </el-col>
            <el-col :span="2">
              <el-button size="medium" @click.stop="dialogVisible=true">申請提案</el-button>
            </el-col>
          </div>
        </template>

        <div class="content_area projects">
          <projects :isPortraitPage="true" :portraitEmpno="empno"></projects>
        </div>
      </el-collapse-item>
      <el-collapse-item name="5">
        <template slot="title">
          <div class="title_area">
            <span>任職履歷</span>
          </div>
        </template>
        <div class="content_area experience">
          <!-- 職等晉升趨勢圖 -->
          <experience-chart :originalData="experience.chartRows"></experience-chart>
          <!-- 其他數據組成的表格 -->
          <el-table
            :data="experience.tableRows.rows"
            :span-method="arraySpanMethod"
            border
            style="margin-top: 1%;"
          >
            <el-table-column
              v-for="col in experience.tableRows.cols"
              :key="col.label"
              :prop="col.prop"
              :label="col.label"
              align="center"
            ></el-table-column>
          </el-table>
        </div>
      </el-collapse-item>
    </el-collapse>

    <!-- 申請提案的彈出框 -->
    <el-dialog :visible.sync="dialogVisible" width="70%">
      <!-- 子組件的內容 -->
      <projects-detail></projects-detail>
    </el-dialog>
  </div>
</template>

<script>
import remoteUser from "@/components/remote-user";
import portraitApi from "@/api/portrait";
import iStudy from "@/views/portrait/iStudy";
import skills from "@/views/management/skills";
import projects from "@/views/management/projects";
import projectsDetail from "@/views/portrait/projectsDetail";
import experienceChart from "@/views/portrait/experienceChart";

export default {
  components: {
    remoteUser,
    iStudy,
    skills,
    projects,
    projectsDetail,
    experienceChart
  },

  data() {
    return {
      activeNames: ["4"],
      empno: "18009380",
      infos: {},
      dialogVisible: false,
      experience: {
        tableRows: {
          cols: [],
          rows: []
        }
      }
    };
  },

  created() {
    this.getInfos();
    this.getExperience();
  },

  mounted() {},

  methods: {
    // 獲取基本信息
    getInfos() {
      portraitApi
        .getInfos(this.empno)
        .then(response => {
          response.selfie = "data:image/png;base64," + response.selfie;
          this.infos = response;
        })
        .catch(error => {
          this.$message.error(error.message);
        });
    },

    // 獲取任職履歷
    getExperience() {
      portraitApi
        .getExperience(this.empno)
        .then(response => {
          this.experience = response;
        })
        .catch(error => {
          this.$message.error(error.message);
        });
    },

    // 動態合併任職履歷的單元格
    arraySpanMethod({ row, column, rowIndex, columnIndex }) {
      let maxLength = this.experience.tableRows.cols.length; // 總列數
      let nextIdx = columnIndex + 1;

      if (columnIndex == 0) {
        return;
      }

      if (row["col" + columnIndex] == row["col" + (columnIndex - 1)]) {
        // 如果cell與前一個相同，說明已經被計算過合併了
        return [0, 0];
      }

      while (nextIdx < maxLength) {
        if (row["col" + columnIndex] == row["col" + nextIdx]) {
          nextIdx++;
        } else {
          break;
        }
      }

      return [1, nextIdx - columnIndex];
    }
  }
};
</script>

<style scoped>
.el-collapse {
  padding: 1% 1.5%;
}
.title_area {
  font-family: Arial, Helvetica, sans-serif;
  color: #70747c;
  font-weight: bold;
  font-size: 16px;
  width: 100%;
}
.content_area {
  font-size: 15px;
  color: #70747c;
  font-family: Microsoft JhengHei;
}

table {
  width: 100%;
  border-collapse: collapse;
  border: none;
}
td {
  width: 16%;
  padding-left: 1%;
  border: solid rgb(243, 235, 235) 1px;
}
.photo {
  text-align: center;
}
</style>