<template>
  <div class>
    <div class="highcharts-container"></div>
  </div>
</template>

<script>
import Highcharts from "highcharts/highstock";
//import HighchartsMore from "highcharts/highcharts-more";
//import HighchartsDrilldown from "highcharts/modules/drilldown";
//import Highcharts3D from "highcharts/highcharts-3d";
// 树状图中的点（矩形）的颜色是由和它同级的数据点的值来计算的。
// 如果需要 colorAxis 功能则需额外的引入http://cdn.hcharts.cn/highcharts/modules/heatmap.js 。
//import HeatMap from "highcharts/modules/heatmap";
import Exporting from "highcharts/modules/exporting";
import Variwide from "highcharts/modules/variwide";
//import TreeMap from "highcharts/modules/treemap";
//HighchartsMore(Highcharts);
//HighchartsDrilldown(Highcharts);
//Highcharts3D(Highcharts);
//HeatMap(Highcharts);
Exporting(Highcharts);
Variwide(Highcharts);
//TreeMap(Highcharts);
export default {
  props: ["originalData"],
  components: {},
  name: "experienceChart",
  data() {
    return {
      chart: null,
      styles: {
        width: 1200,
        height: 400
      },
      defOptions: {
        chart: {
          type: "variwide" // variwide 依赖 variwide.js
        },
        title: {
          text: "職等晉升趨勢圖"
        },
        xAxis: {
          type: "category"
        },
        yAxis: {
          min: 52,
          max: 56
        },
        legend: {
          enabled: false
        },
        series: [
          {
            tooltip: {
              pointFormat: "職等生效時間：<b>{point.description}</b>"
            }
          }
        ]
      }
    };
  },

  created() {
    if (this.originalData) {
      this.handleData();
    }
  },

  methods: {

    // 處理原始數據得到最終展示在圖表的數據
    handleData() {
      let result = [];
      let colorList = ["#87CEFA", "#5CACEE"];
      let colorIdx = 0;
      for (let i = 0; i < this.originalData.length; i++) {
        let item = this.originalData[i];
        let tmp = {
          x: item.year,
          y: item.jobLevel,
          z: 1,
          name: item.year.toString(),
          description: item.startDate
        };

        // 設置柱子的顏色，部門代碼與之前一條數據的不同則需要換顏色
        if (i > 0) {
          if (item.dept != this.originalData[i - 1].dept) {
            colorIdx = (colorIdx + 1) % 2;
          }
        }

        tmp.color = colorList[colorIdx];

        result.push(tmp);
      }

      this.defOptions.series[0].data = result;

      // 根据传进来的style设置宽高
      this.$el.style.width = (this.styles.width || 800) + "px";
      this.$el.style.height = (this.styles.height || 400) + "px";
      this.chart = new Highcharts.Chart(this.$el, this.defOptions);
    }
  },

  watch: {
    originalData() {
      this.handleData();
    }
  }
};
</script>

<style scoped>
.highcharts-container {
  width: 800px;
  height: 400px;
}
</style>