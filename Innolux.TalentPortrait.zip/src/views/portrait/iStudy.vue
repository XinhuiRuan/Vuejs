<template>
  <div class>
    <div class="progess_area">
      應達等級：
      <span>高級</span>
      <el-progress
        :percentage="percentage1"
        :format="progessFormat1"
        :color="percentage1 < 50 ? 'red' : 'blue'"
      ></el-progress>
    </div>
    <div class="progess_area">
      當前等級：
      <span>初級</span>
      <el-progress
        :percentage="percentage2"
        :format="progessFormat2"
        :color="percentage2 < 50 ? 'red' : 'blue'"
      ></el-progress>
    </div>

    <el-table
      :data="knowledgeFirstTable"
      style="width: 100%"
      row-key="id"
      border
      lazy
      align="center"
      :row-style="tableRowStyle"
      :load="loadKnowledgeSecond"
      :tree-props="{children: 'children', hasChildren: 'hasChildren'}"
    >
      <el-table-column
        v-for="block in tableCols"
        :key="block.label"
        :label="block.label"
        align="center"
      >
        <template v-for="col in block.cols">
          <!-- 普通列的格式 -->
          <el-table-column
            v-if="!col.link"
            :key="col.prop"
            :prop="col.prop"
            :label="col.label"
            show-overflow-tooltip
          ></el-table-column>
          <!-- 具有链接的列的格式 -->
          <el-table-column
            v-else
            :key="col.prop"
            :prop="col.prop"
            :label="col.label"
            show-overflow-tooltip
          >
            <template slot-scope="scope">
              <el-link
                type="warning"
                @click="getStudiedList(scope.row,col.prop)"
              >{{scope.row[col.prop]}}</el-link>
            </template>
          </el-table-column>
        </template>
      </el-table-column>
    </el-table>
    <div class="pagination">
      <el-pagination
        @size-change="handleSizeChange_knowledge"
        @current-change="handleCurrentChange_knowledge"
        :current-page="knowledgeParams.currentPage"
        :page-sizes="pageSizes"
        :page-size="knowledgeParams.pageSize"
        layout="total, sizes, prev, pager, next, jumper"
        :total="total_knowledge"
      ></el-pagination>
    </div>

    <!-- 通過累計積分查看學習過的課程 -->
    <el-dialog title="已訓課程明細" :visible.sync="studiedTableVisible">
      <el-table :data="studiedTable">
        <el-table-column property="id" label="序號" width="80"></el-table-column>
        <el-table-column property="route" label="學習路徑"></el-table-column>
        <el-table-column property="course" label="應修課程"></el-table-column>
        <el-table-column property="level" label="等級"></el-table-column>
        <el-table-column property="result" label="成績"></el-table-column>
        <el-table-column property="grade" label="積分"></el-table-column>
        <el-table-column property="finishedDate" label="完訓時間"></el-table-column>
      </el-table>
      <div class="pagination">
        <el-pagination
          @current-change="handleCurrentChange_studied"
          :current-page="studiedParams.currentPage"
          :page-size="studiedParams.pageSize"
          layout="total, prev, pager, next"
          :total="total_studied"
        ></el-pagination>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import portraitApi from "@/api/portrait";

export default {
  props: ["empno"],

  components: {},

  data() {
    return {
      knowledgeParams: {
        empno: "",
        pageSize: 3, // 每頁顯示的條數
        currentPage: 1 // 當前頁
      },
      tableCols: [
        {
          label: "學習地圖",
          cols: [
            { prop: "year", label: "年份" },
            { prop: "level", label: "等級" },
            { prop: "route", label: "學習路徑" },
            { prop: "totalCount", label: "應修" },
            { prop: "addupStudied1", label: "累計完訓" },
            { prop: "addupGrade1", label: "累計積分", link: true }
          ]
        },
        {
          label: "其他課程",
          cols: [
            { prop: "yearStudied2", label: "本年度完訓" },
            { prop: "addupStudied2", label: "累计完訓" },
            { prop: "yearGrade2", label: "本年度積分" },
            { prop: "addupGrade2", label: "累計積分", link: true }
          ]
        },
        {
          label: "總積分",
          cols: [
            { prop: "yearGrade3", label: "本年度積分加權" },
            { prop: "addupGrade3", label: "累计積分加權" }
          ]
        }
      ],
      total_knowledge: 0,
      pageSizes: [3, 5, 10],
      percentage1: 0,
      percentage2: 0,
      knowledgeFirst: {},
      knowledgeFirstTable: [],
      studiedTableVisible: false,
      total_studied: 0,
      studiedParams: {
        empno: "",
        row: "", // 被选中的父行数据
        col: "", // 被选中的栏位
        pageSize: 10, // 每頁顯示的條數
        currentPage: 1 // 當前頁
      },
      studiedTable: []
    };
  },

//   watch: {
//       empno(){
//           this.knowledgeParams.empno = this.studiedParams.empno = this.empno
//       }
//   },

  created() {
    // 将父组件传过来的工号赋值
    this.knowledgeParams.empno = this.studiedParams.empno = this.empno
    this.getKnowledgeFirst();
  },

  methods: {
    tableRowStyle({ row, rowIndex }) {
      if (row.year == "當前等級") {
        return { background: "pink" };
      }
    },

    // 改變每頁的條數展示
    handleSizeChange_knowledge(val) {
      this.knowledgeParams.pageSize = val;
      this.getKnowledgeFirst();
    },
    // 跳轉到其他頁面
    handleCurrentChange_knowledge(val) {
      this.knowledgeParams.currentPage = val;
      this.getKnowledgeFirst();
    },
    handleCurrentChange_studied(val) {
      this.studiedParams.currentPage = val;
      this.getStudiedList();
    },

    progessFormat1() {
      return (
        this.knowledgeFirst.studiedCount1 +
        "/" +
        this.knowledgeFirst.totalCount1
      );
    },
    progessFormat2() {
      return (
        this.knowledgeFirst.studiedCount2 +
        "/" +
        this.knowledgeFirst.totalCount2
      );
    },

    // 獲取必備知識一階
    getKnowledgeFirst() {
      portraitApi
        .getKnowledgeFirst(this.knowledgeParams)
        .then(response => {
          this.knowledgeFirst = response;
          this.knowledgeFirstTable = response.rows;
          this.total_knowledge = response.total;

          let ratio1 = Math.round(
            (response.studiedCount1 / response.totalCount1) * 100
          ); // 暫時判斷一下百分率
          this.percentage1 = ratio1 > 100 ? 100 : ratio1;
          let ratio2 = Math.round(
            (response.studiedCount2 / response.totalCount2) * 100
          ); // 暫時判斷一下百分率
          this.percentage2 = ratio2 > 100 ? 100 : ratio2;
        })
        .catch(error => {
          this.$message.error(error.message);
        });
    },

    // 獲取必備知識二階
    loadKnowledgeSecond(tree, treeNode, resolve) {
      let params = {
        empno: this.knowledgeParams.empno,
        year: tree.year
      };
      portraitApi
        .getKnowledgeSecond(params)
        .then(response => {
          resolve(response.rows);
        })
        .catch(error => {
          this.$message.error(error.message);
        });
    },

    // 獲取組成累計積分的完訓課程列表
    getStudiedList(row, col) {
      if (row) {
        // 通过点击打开了完训课程表，需要更新属性，重置当前页
        this.studiedParams.row = row;
        this.studiedParams.col = col;
        this.studiedParams.currentPage = 1;
      }

      portraitApi
        .getStudiedList(this.studiedParams)
        .then(response => {
          this.studiedTable = response.rows;
          this.total_studied = response.total;
          this.studiedTableVisible = true;
        })
        .catch(error => {
          this.$message.error(error.message);
        });
    }
  }
};
</script>

<style>
.progess_area {
  margin: -0.5% 0 1% 1.5%;
  /* border-bottom: solid #f5f7fa 1px; */
}
.el-progress {
  display: inline-block;
  width: 35%;
}

/* 重新設置行高度 */
.el-table__header tr,
.el-table__header th {
  padding: 0;
  height: 44px;
}
.el-table__body tr,
.el-table__body td {
  padding: 0;
  height: 44px;
}
</style>