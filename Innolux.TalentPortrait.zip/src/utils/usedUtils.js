import moment from "moment";
/**
 * 常用工具方法
 */
let $usedUtils = {

}
/**
 * 获取文件后缀
 */
$usedUtils.getType = function (file) {
    let filename = file;
    let index1 = filename.lastIndexOf(".");
    let index2 = filename.length;
    let type = filename.substring(index1, index2);
    return type;
}
/**
 * 日期插件
 */
$usedUtils.moment = moment;

/**
 * excle下载
 */
$usedUtils.download = function (data,filename) {
    let url = window.URL.createObjectURL(data)
    let link = document.createElement('a')
    link.style.display = 'none'
    link.href = url
    link.setAttribute('download', filename+'.xlsx')
    document.body.appendChild(link)
    link.click()
}
/**
 * 去除一个数组中与另一个数组中的值相同的元素
 */
$usedUtils.arrayDiff=function(a, b,name) {
        for(var i=0;i<b.length;i++)
        {
          for(var j=0;j<a.length;j++)
          {
            if(a[j][name]==b[i][name]){
              a.splice(j,1);
              j=j-1;
            }
          }
        } 
      return a;
    }
export default $usedUtils