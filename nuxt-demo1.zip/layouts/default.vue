<template>
  <div>
    <!-- <h1>默认组件的导航栏</h1> -->
    <!-- 头部导航 -->
    <div class="header">
      <ul>
        <li><nuxt-link to="/">首页</nuxt-link></li>
        <li><nuxt-link to="/article">文章</nuxt-link></li>
        <li><nuxt-link to="/hot">问答</nuxt-link></li>
        <li><nuxt-link to="/user">个人中心</nuxt-link></li>
      </ul>
    </div>
    <Nuxt />
  </div>
</template>

<script>
export default {
 // middleware: 'auth', // 中间件使用方法2（作用在布局）：访问布局上的路由都会被拦截调用auth.js

  components: {},

  data() {
    return {
    };
  },

  methods: {},
};
</script>

<style>
*{
  margin: 0 auto;
  font-size: 18px;
}

.header{
  width:100%;
  height:50px;
  background-color: black;
}

.header ul{
  margin-left: 80px;
}

.header li{
  display: inline;
  line-height: 50px;
  margin-left: 60px;
}

.header a{
  color: #fff;
  text-decoration: none; /* 去除下划线 */
}

.header a:hover{
  color:aqua;
}
</style>
