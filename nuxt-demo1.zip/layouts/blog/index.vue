<template>
  <div class>
      
      <h1>博客导航栏</h1>
      <nuxt/>
  </div>
</template>

<script>
export default {
  components: {},

  data() {
    return {
    };
  },

  methods: {},
};
</script>

<style scoped>

</style>