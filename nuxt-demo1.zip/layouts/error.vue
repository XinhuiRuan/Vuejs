<template>
  <div class>
      <h1 v-if="error.statusCode === 404">
          您访问的页面不存在：{{error.message}}
      </h1>
      <h1 v-else>
          请求接口失败或超时！请刷新重试！
      </h1>
  </div>
</template>

<script>
export default {
  props: ['error'], // 直接引用Error错误对象

  // 可只为blog布局定制的错误页面，默认default所有布局的错误页  
  // layout: 'blog/index',

  components: {},

  data() {
    return {
    };
  },

  methods: {},
};
</script>

<style scoped>

</style>