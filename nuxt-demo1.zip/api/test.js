export default ({$axios}, inject) => {
    // test 方法注入到context/vue/store
    inject('test', () => $axios.$get( "/test"))
}