
export default {
  /*
  ** Nuxt rendering mode
  ** See https://nuxtjs.org/api/configuration-mode
  */
  mode: 'universal',

  router: {
   // middleware: 'auth', // 中间件使用方法3（作用在全局）：所有的路由都会被拦截调用auth.js
  },

  server: {
    port: 3000,
    host: '0.0.0.0' // 默认是localhost
  },
  
  /*
  ** Nuxt target
  ** See https://nuxtjs.org/api/configuration-target
  */
  target: 'server',
  /*
  ** Headers of the page
  ** See https://nuxtjs.org/api/configuration-head
  */
  head: {
    
    htmlAttrs: { // 对应 HTML_ATTRS 属性
      lang:'en',
    },

    headAttrs: {  // 对应 HEAD_ATTRS 属性
      name: 'headname'
    },

    bodyAttrs: { // 对应 BODY_ATTRS 属性
     // style: 'background-color: pink;'
    },


    // 下面的是 HEAD 模板
    title: 'Nuxtjs学习', //process.env.npm_package_name || '',
    meta: [
      { charset: 'utf-8' },
      { name: 'viewport', content: 'width=device-width, initial-scale=1' },
      { hid: 'description', name: 'description', content: process.env.npm_package_description || '' }
    ],
    link: [
      { rel: 'icon', type: 'image/x-icon', href: '/favicon.ico' }
    ]
  },
  /*
  ** Global CSS
  */
  css: [
  ],
  /*
  ** Plugins to load before mounting the App
  ** https://nuxtjs.org/guide/plugins
  */
  plugins: [
    '~/plugins/vue-inject.js',
    '~/plugins/context-inject.js',
    '@/plugins/all-inject.js',
    // {src: '@/plugins/all-inject.js', mode: 'client'}, // 设置只运行在客户端
    // {src: '@/plugins/all-inject.js', mode: 'server'}, // 设置只运行在服务端
    '@/plugins/interceptor.js',
    '~/api/test.js',
  ],
  /*
  ** Auto import components
  ** See https://nuxtjs.org/api/configuration-components
  */
  components: true,
  /*
  ** Nuxt.js dev-modules
  */
  buildModules: [
  ],
  /*
  ** Nuxt.js modules
  */
  modules: [
    '@nuxtjs/axios' // 引入
  ],
  // 设置代理需要先下载@nuxtjs/axios模块
  axios:{
    proxy: true, // 开启代理转发
    prefix: '/api' // 请求接口添加前缀 /api，/test => /api/test
  },

  proxy: {
     // 将/api开头的请求都进行代理转发，// 比如：/api/test => http://mengxuegu.com:7300/mock/5f2e5c6cfd0fa244c4c55f73/nuxt-blog/test
    '/api': { 
      target: "http://mengxuegu.com:7300/mock/5f2e5c6cfd0fa244c4c55f73/nuxt-blog",
      pathRewrite: {'^/api': ''} // 将/api替换为空，/api/test => /test
    }
  },


  /*
  ** Build configuration
  ** See https://nuxtjs.org/api/configuration-build/
  */
  build: {
  }
}
