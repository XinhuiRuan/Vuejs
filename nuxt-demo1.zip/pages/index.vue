<template>
  <div class="container">
    <div>
      <Logo />
      <h1 class="title">nuxt-demo1</h1>
      <h2>首页标题：{{title}}</h2>
      <ul>
        <li>标题：{{data.title}}</li>
        <li>内容：{{data.content}}</li>
        <li>作者：{{data.author}}</li>
      </ul>

      <div>
        <!-- 子路由组件（/pages/index/_id.vue）渲染出口 
          /pages/index/index.vue 是访问路由地址 http://localhost:3000/ 时的默认子组件
        -->
        <nuxt-child></nuxt-child>
      </div>

      <!-- <div class="links">
        <a
          href="https://nuxtjs.org/"
          target="_blank"
          rel="noopener noreferrer"
          class="button--green"
        >Documentation</a>
        <a
          href="https://github.com/nuxt/nuxt.js"
          target="_blank"
          rel="noopener noreferrer"
          class="button--grey"
        >GitHub</a>
      </div>-->
    </div>
  </div>
</template>

<script>
export default {
  // 当前视图组件引用的是 layouts\blog\index.vue，参数context是nuxtjs的上下文对象
  // layout(context){ // 运行在服务端，因为输出在terminal
  //   // console.log(context)
  //   // console.log(context.isClient)
  //   return 'blog/index' // 要写完整路径，不能像之前一样可以省略写index
  // },

  data() {
    return {
      title: "这是首页标题"
    };
  },

  // 使用 head 方法设置当前页面的头部标签
  // 在 head 方法里可通过 this 关键字来获取组件的数据，可以利用页面组件的数据来设置个性化的 meta 标签
  head() {
    return {
      title: this.title,
      bodyAttrs: {
        style: "background-color: pink;"
      },
      meta: [
        // hid会覆盖nuxt.config.js文件里的重名meta标签
        { hid: "description", name: "description", content: "Nuxtjs技术栈" }
      ]
    };
  },

  // 加载组件之前服务端会调用
  // 方式一：使用了两个return
  //asyncData({$axios}){
  //  return $axios.$get('http://mengxuegu.com:7300/mock/5f2e5c6cfd0fa244c4c55f73/nuxt-blog/test').then(response => {
  //     console.log(response)
  //     console.log('response',response)
  //     const data = response.data
  //     return {data: data}
  //   })
  //}

  // 方式二：通过async和await
  async asyncData({ $axios, app }) {
    //const response = await $axios.$get( "/test")
    // 使用api插件形式（项目中将api单独分离维护）
    const response = await app.$test();

   // console.log("response", response);
    return { data: response.data };
  },

  async mounted() {
    const response = await this.$test();
   // console.log("response", response);
  }
};
</script>

<style>
.container {
  margin: 0 auto;
  min-height: 100vh;
  display: flex;
  justify-content: center;
  align-items: center;
  text-align: center;
}

.title {
  font-family: "Quicksand", "Source Sans Pro", -apple-system, BlinkMacSystemFont,
    "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
  display: block;
  font-weight: 300;
  font-size: 100px;
  color: #35495e;
  letter-spacing: 1px;
}

.subtitle {
  font-weight: 300;
  font-size: 42px;
  color: #526488;
  word-spacing: 5px;
  padding-bottom: 15px;
}

.links {
  padding-top: 15px;
}
</style>
