<template>
  <div class>
      Vue实例插件注入
  </div>
</template>

<script>
export default {
  components: {},

  data() {
    return {};
  },

  created(){
      console.log('运行')
  },

  mounted() {
      this.$myInjectedFunc('test-plugin')
  },

  methods: {}
};
</script>

<style scoped>
</style>