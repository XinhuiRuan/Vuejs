<template>
  <div class>
根据不同的技术频道查询不同文章列表，当前技术频道id是：{{$route.params.id}}
  </div>
</template>

<script>
export default {
  components: {},

  data() {
    return {
    };
  },

  methods: {},
};
</script>

<style scoped>

</style>