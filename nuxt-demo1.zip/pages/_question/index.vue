<template>
  <div class>
<h2>问答列表 —— {{$route.params.question}}</h2>
  </div>
</template>

<script>
export default {
  components: {},

  data() {
    return {
    };
  },

  methods: {},

  validate(context) {
      // 校验question只能是以下三个
      const arr = ['wait', 'hot', 'new']
      return arr.indexOf(context.params.question) != -1
  },
};
</script>

<style scoped>

</style>