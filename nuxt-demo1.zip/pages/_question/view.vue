<template>
  <div class>
      <!-- http://localhost:3000/hot/view -->
      查询问题详情
  </div>
</template>

<script>
export default {
  components: {},

  data() {
    return {
    };
  },

  methods: {},
};
</script>

<style scoped>

</style>