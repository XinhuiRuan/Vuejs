<template>
  <div class>
      Vue实例插件注入
  </div>
</template>

<script>
export default {
  layout(context){
    context.app.myContextFunc('ctx')
    return 'blog/index'
  },

  asyncData({app}){
    app.myContextFunc('asyncData')
  },

  components: {},

  data() {
    return {};
  },

  methods: {}
};
</script>

<style scoped>
</style>