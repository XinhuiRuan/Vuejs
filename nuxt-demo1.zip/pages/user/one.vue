<template>
  <div class>
用户one
  </div>
</template>

<script>
export default {
  components: {},

  data() {
    return {
    };
  },

  methods: {},
};
</script>

<style scoped>

</style>