
<template>
  <div class>
    <!-- 学习以下划线为前缀的Vue文件来生成动态路由 -->
    查看用户详情：{{$route.params.id}}
  </div>
</template>

<script>
export default {
  components: {},

  data() {
    return {};
  },

  methods: {},

  // nuxt.js提供的校验动态路由值的方法（服务端），返回true证明地址合法可访问
  validate(context) {
    // 判断id只能为数字
    // console.log(context.params.id)
    return /^\d+$/.test(context.params.id);
  },
  asyncData({ params }) {
    const id = params.id;
    console.log("id", id);
  }
};
</script>

<style scoped>
</style>