<template>
  <div class>
用户首页
  </div>
</template>

<script>
export default {
 // middleware: 'auth', // 中间件使用方法1（作用在特定的组件）：将auth.js中间件作用到该组件

  components: {},

  data() {
    return {
    };
  },

  methods: {},
};
</script>

<style scoped>

</style>