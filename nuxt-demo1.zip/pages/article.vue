<template>
  <div class>
      文章
  </div>
</template>

<script>
export default {
  components: {},

  data() {
    return {
    };
  },

  methods: {},
};
</script>

<style scoped>

</style>
