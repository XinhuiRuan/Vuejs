<template>
  <div class>

  </div>
</template>

<script>
export default {
  components: {},

  data() {
    return {
    };
  },

  methods: {},

  // 服务端（Nuxt）
  asyncData({app}){
      // 方法名之前必须加$，才能被调用
      app.$myAllFuc('asyncData')
  },

  // 客户端（Vue），不能使用created测试（既运行在客户端也运行在服务端）
  mounted(){
      // Vuex也是用这个调用方式，一模一样
      this.$myAllFuc('mounted')
  }
};
</script>

<style scoped>

</style>