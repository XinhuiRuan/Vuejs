// 定义权限判断中间件
export default ({store,redirect}) => {
    console.log('auth.js认证中间件被调用')
    if(!store || !store.state.userInfo){
        // 没有登入，重定向到首页
        redirect('/')
    }
}