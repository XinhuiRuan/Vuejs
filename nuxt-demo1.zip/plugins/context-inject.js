// context：上下文对象
// inject：同时将方法注入到context和Vue实例和store中
export default (context, inject) => {
    // 将方法注入到context中
    context.app.myContextFunc = str => console.log('在context插件中的参数值：', str)
}