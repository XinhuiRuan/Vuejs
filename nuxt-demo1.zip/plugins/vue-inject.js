import Vue from 'vue'

Vue.prototype.$myInjectedFunc = str => console.log('绑定到Vue实例里的参数：', str)