// context：上下文对象
// inject：同时将方法注入到context和Vue实例和store中
export default (context, inject) => {
    // 第一个参数：注入的名称；第二个参数：注入的方法
    inject('myAllFuc', str => console.log('同时将方法注入到context和Vue实例和store中的参数：', str))
}