import Vue from 'vue'
import Router from 'vue-router'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _3fbbd7aa = () => interopDefault(import('..\\pages\\article.vue' /* webpackChunkName: "pages/article" */))
const _2f0c0afa = () => interopDefault(import('..\\pages\\plugin-all.vue' /* webpackChunkName: "pages/plugin-all" */))
const _30baeade = () => interopDefault(import('..\\pages\\plugin-context.vue' /* webpackChunkName: "pages/plugin-context" */))
const _4e55cfe8 = () => interopDefault(import('..\\pages\\plugin-vue.vue' /* webpackChunkName: "pages/plugin-vue" */))
const _1c11335b = () => interopDefault(import('..\\pages\\user\\index.vue' /* webpackChunkName: "pages/user/index" */))
const _8f1751a2 = () => interopDefault(import('..\\pages\\user\\one.vue' /* webpackChunkName: "pages/user/one" */))
const _617a5083 = () => interopDefault(import('..\\pages\\user\\_id.vue' /* webpackChunkName: "pages/user/_id" */))
const _663a06f4 = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))
const _5b39553c = () => interopDefault(import('..\\pages\\index\\index.vue' /* webpackChunkName: "pages/index/index" */))
const _725376a4 = () => interopDefault(import('..\\pages\\index\\_id.vue' /* webpackChunkName: "pages/index/_id" */))
const _7e7208e9 = () => interopDefault(import('..\\pages\\_question\\index.vue' /* webpackChunkName: "pages/_question/index" */))
const _d1aa3f44 = () => interopDefault(import('..\\pages\\_question\\view.vue' /* webpackChunkName: "pages/_question/view" */))

// TODO: remove in Nuxt 3
const emptyFn = () => {}
const originalPush = Router.prototype.push
Router.prototype.push = function push (location, onComplete = emptyFn, onAbort) {
  return originalPush.call(this, location, onComplete, onAbort)
}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: decodeURI('/'),
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/article",
    component: _3fbbd7aa,
    name: "article"
  }, {
    path: "/plugin-all",
    component: _2f0c0afa,
    name: "plugin-all"
  }, {
    path: "/plugin-context",
    component: _30baeade,
    name: "plugin-context"
  }, {
    path: "/plugin-vue",
    component: _4e55cfe8,
    name: "plugin-vue"
  }, {
    path: "/user",
    component: _1c11335b,
    name: "user"
  }, {
    path: "/user/one",
    component: _8f1751a2,
    name: "user-one"
  }, {
    path: "/user/:id",
    component: _617a5083,
    name: "user-id"
  }, {
    path: "/",
    component: _663a06f4,
    children: [{
      path: "",
      component: _5b39553c,
      name: "index"
    }, {
      path: ":id",
      component: _725376a4,
      name: "index-id"
    }]
  }, {
    path: "/:question",
    component: _7e7208e9,
    name: "question"
  }, {
    path: "/:question/view",
    component: _d1aa3f44,
    name: "question-view"
  }],

  fallback: false
}

export function createRouter () {
  return new Router(routerOptions)
}
