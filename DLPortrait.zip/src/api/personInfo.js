import request from "@/utils/request"

export default{
    // 得到个人信息
    getPersonInfo(empno,userid){
        return request({
            url: `/dl/GetPersonInfo?empno=${empno}&userid=${userid}`,
            method: "get"
        })
    },

    // 得到返任记录
    getReturnRecord(empno){
        return request({
            url: `/dl/GetReturnRecord?empno=${empno}`,
            method: "get"
        })
    },
}