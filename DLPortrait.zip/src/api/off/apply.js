import request from "@/utils/requestOff"

export default {
    // 获取班表
    getWorkSchedule(empno, startDate, endDate) {
        return request({
            url: `/dlOff/GetWorkSchedule?empno=${empno}&startDate=${startDate}&endDate=${endDate}`,
            method: "get"
        })
    },

    // 申请页面获取初始数据：销单次数，每日的人额
    getOffApplyInfo(empno, startDate, endDate) {
        return request({
            url: `/dlOff/GetOffApplyInfo?empno=${empno}&startDate=${startDate}&endDate=${endDate}`,
            method: "get"
        })
    },

    // 根据假别得到剩余时数和请假时数
    postOffTypeDetail(data) {
        return request({
            url: `/dlOff/GetOffTypeDetail`,
            method: "post",
            data
        })
    },

    // 提交预提请假申请单
    submitForm(data) {
        return request({
            url: `/dlOff/SubmitOffApply`,
            method: "post",
            data
        })
    }
}