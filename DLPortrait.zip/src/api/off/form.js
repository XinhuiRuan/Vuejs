import request from "@/utils/requestOff"

export default {
    // 获取单据状态
    getFormStatus() {
        return request({
            url: `/dlOff/GetFormStatus`,
            method: "get"
        })
    },

    // 获取假单类别
    getOffType(empno) {
        return request({
            url: `/dlOff/GetOffType?empno=${empno}`,
            method: "get"
        })
    },

    // 获取单据列表
    getOffFormList(data) {
        return request({
            url: `/dlOff/GetOffFormList`,
            method: "post",
            data
        })
    },

    // 获取单据的详细信息
    getOffFormInfo(formno) {
        return request({
            url: `/dlOff/GetOffFormInfo?formno=${formno}`,
            method: "get",
        })
    },

    // 中止或销单
    deleteOffForm(data){
        return request({
            url: `/dlOff/PostHandleForm`,
            method: "post",
            data
        })
    }
}