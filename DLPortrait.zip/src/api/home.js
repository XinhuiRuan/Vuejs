import request from "@/utils/request"

export default {
    getEmpList(userid, search, currentPage, pageSize) {
        return request({
            url: `/dl/GetEmpList?userid=${userid}&search=${search}&currentPage=${currentPage}&pageSize=${pageSize}`,
            method: "get"
        })
    }
}