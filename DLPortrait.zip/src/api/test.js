import request from "@/utils/request" // @是脚手架封装的便捷路径，直接指向src文件夹

//const BASE_URL = 'http://localhost:8001';
// 当存在跨域问题时，使用以下的声明
//const BASE_URL = '/dev-api'; // 失效了，因为已经修改了封装的axios对象的baseURL

// 推荐使用对象形式传入请求配置，如请求url, method，param
// request({
//     url: "/db.json",
//     method: "get"
// }).then(response => {
//     console.log("get2", response.data);
// }).catch(error => {
//     console.log(error);
// })

// 第三步（最终版）：为了将返回的data不同调用的组件使用，要将then和catch方法写在组件里，需要导出request
export default {
    getList() {
        const req = request({   
        // 过程：/db.json -> 通过axios -> /dev-api/db.json -> 通过代理转发(vue.config.js) -> http://localhost:8001/dev-api/db.json
            url: "/db.json",
            method: "get"
        });
        // console.log(req) // Promise对象，通过它调用then获取响应数据
        return req;
    }
}