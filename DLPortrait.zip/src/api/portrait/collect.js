import request from "@/utils/request"

export default{
    // 得到问题
    getQuestions(id){
        return request({
            url: `/dl/GetQuestions?Whcl1=${id}`,
            method: "get"
        })
    },

    // 提交问题收集单
    submitCollectForm(data) {
        return request({
            url: `/dl/SubmitCollectForm`,
            method: "post",
            data
        })
    },

    getEmpByCollect(userid, search, currentPage, pageSize){
        return request({
            url: `/dl/GetEmpByCollect?userid=${userid}&search=${search}&currentPage=${currentPage}&pageSize=${pageSize}`,
            method: "get"
        })
    }
}