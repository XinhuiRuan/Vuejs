import request from "@/utils/request"

export default{
    // 得到工作信息数据
    getJobInfo(empno,userid){
        return request({
            url: `/dl/GetJobInfo?empno=${empno}&userid=${userid}`,
            method: "get"
        })
    },

    // 得到奖惩记录
    getBonusAndPenalty(empno){
        return request({
            url: `/dl/GetBonusAndPenalty?empno=${empno}`,
            method: "get"
        })
    },

    // 得到请假记录
    getLeaves(empno,key){
        return request({
            url: `/dl/GetLeaves?empno=${empno}&key=${key}`,
            method: "get"
        })
    },

}