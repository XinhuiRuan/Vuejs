import request from "@/utils/request"

export default{
    // 得到高风险因子数据
    getRiskFactors(empno,userid){
        return request({
            url: `/dl/GetRiskFactors?empno=${empno}&userid=${userid}`,
            method: "get"
        })
    }
}