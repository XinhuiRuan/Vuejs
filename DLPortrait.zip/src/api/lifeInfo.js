import request from "@/utils/request"

export default{
    // 得到生活信息页面数据
    getLifeInfo(empno,userid){
        return request({
            url: `/dl/GetLifeInfo?empno=${empno}&userid=${userid}`,
            method: "get"
        })
    },

    // 得到宿舍放行单/维修/调退宿信息
    getDormInfo(empno,index){
        return request({
            url: `/dl/GetDormInfo?empno=${empno}&index=${index}`,
            method: "get"
        })
    },
}