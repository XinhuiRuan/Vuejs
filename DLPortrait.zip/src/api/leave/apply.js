import request from "@/utils/requestMock"

export default {
    // 得到人员的派遣公司信息（如果是派遣人员）
    getRecruitnameDetail(userid) {
        return request({
            url: `/leave/GetRecruitnameDetail?userid=${userid}`,
            method: "get"
        })
    },

    // 提交预提离职申请单
    submitForm(data) {
        return request({
            url: `/leave/SubmitForm`,
            method: "post",
            data
        })
    }
}