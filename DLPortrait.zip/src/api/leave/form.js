import request from "@/utils/requestMock"

export default {
    getFormDetail(userid) {
        return request({
            url: `/leave/GetFormDetail?userid=${userid}`,
            method: "get"
        })
    }
}