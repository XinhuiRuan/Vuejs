import request from "@/utils/requestMock"

export default {
    // 得到待签核清单
    getSignList(userid,curLen,eachLen) {
        return request({
            url: `/leave/GetSignList?userid=${userid}&curLen=${curLen}&eachLen=${eachLen}`,
            method: "get"
        })
    },

    // 得到签核页面的详细信息
    getSignDetail(userid,formno) {
        return request({
            url: `/leave/GetSignDetail?userid=${userid}&formno=${formno}`,
            method: "get"
        })
    },

    // 得到本月预提状况
    getMonthlyLeave(userid) {
        return request({
            url: `/leave/GetMonthlyLeave?userid=${userid}`,
            method: "get"
        })
    },

    // 签核预提离职单
    signForm(data) {
        return request({
            url: `/leave/SignForm`,
            method: "post",
            data
        })
    }
}