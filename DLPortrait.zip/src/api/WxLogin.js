import request from "@/utils/requestWX"

export function requestWxLogin(params){
    return request({
        url: '/Wx/WxLogin',
        method: 'get',
        params
      })
}
