import Vue from "vue";
import Router from "vue-router";
// 默认导入目录下的 index.vue 文件，等价于 ./views/login/index.vue，只适用于取名字为 index.vue
import Layout from "./layout/Layout.vue"
import Main from "./layout/AppMain/AppMain.vue"

Vue.use(Router);

export default new Router({
  //mode:"history",//去除哈希值的#号s
  routes: [
    // 查询主页面
    {
      // 基础布局
      path: "/",
      redirect: '/off', // 重定向到子路由     
    },

    // 员工画像部分的路由
    {
      // 查询首页
      path: "/portrait",
      component: () => import('./views/portrait/home'),
      meta: {
        keepAlive: true, // 需要被缓存
      }
    },

    // 个人信息
    {
      // 基础布局
      path: "/portrait/personInfo",
      component: Layout,
      children: [
        {
          path: '/',
          component: () => import('./views/portrait/personInfo'),
          name: "personInfo",
          meta: {
            // keepAlive: true, // 需要被缓存
          }
        }
      ]
    },
    // 生活信息
    {
      path: '/portrait/lifeInfo',
      component: Layout,
      children: [
        {
          path: '/',
          component: () => import('./views/portrait/lifeInfo'),
          meta: {
            // keepAlive: true, // 需要被缓存
          }
        }
      ]
    },
    // 工作信息
    {
      path: '/portrait/jobInfo',
      component: Layout,
      children: [
        {
          path: '/',
          component: () => import('./views/portrait/jobInfo'),
          meta: {
            // keepAlive: true, // 需要被缓存
          }
        }
      ]
    },
    // 高风险因子
    {
      path: '/portrait/riskFactors',
      component: Layout,
      children: [
        {
          path: '/',
          component: () => import('./views/portrait/riskFactors'),
          meta: {
            // keepAlive: true, // 需要被缓存
          }
        }
      ]
    },
    // 问题收集
    {
      path: '/portrait/collect',
      component: () => import('./views/portrait/collect'),
    },

    // 预提离职部分的路由
    {
      // 主页
      path: "/leave",
      component: () => import('./views/leave/home'),
      meta: {
        keepAlive: true // 需要被缓存
      }
    },
    // 预提离职申请
    {
      path: "/leave/apply",
      component: () => import('./views/leave/apply'),
    },
    // 预提离职申请单查询
    {
      path: "/leave/form",
      component: () => import('./views/leave/form'),
      meta: {
        keepAlive: true // 需要被缓存
      }
    },
    // 待签核清单列表
    {
      path: "/leave/sign/list",
      component: () => import('./views/leave/sign/list'),
    },
    // 签核详情页面
    {
      path: "/leave/sign/detail",
      component: () => import('./views/leave/sign/detail'),
      meta: {
        keepAlive: true // 需要被缓存
      }
    },

    // 预提请假部分的路由
    // 主页
    {
      path: "/off",
      component: () => import('./views/off/home'),
      meta: {
        keepAlive: true // 需要被缓存
      }
    },
    // 预提请假申请
    {
      path: "/off/apply",
      component: () => import('./views/off/apply'),
    },
    // 预提请假申请单列表（自己的和课里所有的）
    {
      path: "/off/form/list",
      component: () => import('./views/off/form/list'),
      // meta: {
      //   keepAlive: true // 需要被缓存
      // }
    },
    // 预提请假申请单详情
    {
      path: "/off/form/detail",
      component: () => import('./views/off/form/detail'),
      // meta: {
      //   keepAlive: true // 需要被缓存
      // }
    },
  ]
});
