import Vue from "vue";

import ElementUI from 'element-ui'; // 组件库
import 'element-ui/lib/theme-chalk/index.css'; // 样式

import Vant from 'vant'; // 引入Vant组件库：VUE的移动端ui组件库
import 'vant/lib/index.css';
// Vant在桌面端自动将mouse事件转换成对应的touch事件
import '@vant/touch-emulator';

import App from "./App.vue";
import router from "./router";

// 导入Vuex文件
import store from './store'

Vue.use(ElementUI); // 使用 ElementUI 插件
Vue.use(Vant); // 使用 Vant 插件

// 权限拦截
import './permission'
// vee-validate的文件
import './utils/validate'
// 引入rem文件
import './utils/rem'

import './assets/customStyle.css'; // 自定义样式

// 消息提示的环境配置，是否为生产环境：
// false 开发环境：Vue会提供很多警告来方便调试代码。
// true 生产环境：警告却没有用，反而会增加应用的体积
Vue.config.productionTip = process.env.NODE_ENV === 'production'; // 开发环境为 development
//console.log(process.env.NODE_ENV);

new Vue({
  router,
  store, // 注册
  render: h => h(App)
}).$mount("#app");


Object.defineProperty(String.prototype, "trimMultiSpace", {
  enumerable: false,
  value: function() {
    return this.replace(/ *[' '] */gm, ""); //将字符串的空格都去掉
  }
});
