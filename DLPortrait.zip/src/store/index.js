import Vue from 'vue'
import Vuex from 'vuex'
import portrait from './modules/portrait'

Vue.use(Vuex)

const store = new Vuex.Store({
    modules: {
        portrait
    }
})

export default store