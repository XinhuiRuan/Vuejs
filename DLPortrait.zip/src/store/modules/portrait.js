import { requestWxLogin } from '@/api/WxLogin'

const portrait = {
    state: {
        //userid: process.env.VUE_APP_USERID, // 进入系统人员的工号
        userid: '07002206', // 进入系统人员的工号
        username: '',
        mobile: '',
        avatar: '',
        code: '',
        empno: '', // 员工画像的员工工号
    },

    mutations: {
        SET_EMPNO(state, empno) {
            state.empno = empno;
        },

        SET_USERID(state, userid) {
            state.userid = userid;
        },
        SET_NAME(state, username) {
            state.username = username;
        },
        SET_MOBILE(state, mobile) {
            state.mobile = mobile;
        },
        SET_AVATAR(state, avatar) {
            state.avatar = avatar;
        },
        SET_CODE(state, code) {
            state.code = code;
        }
    },

    actions: {
        // 通过点击员工卡片跳转到该员工的个人信息，并保存当前员工工号
        SaveEmpno({ commit }, empno) {
            commit("SET_EMPNO", empno)
        },

        WxLogin({ commit }, code) {
            return new Promise((resolve, reject) => {
                requestWxLogin({ code }).then(response => {
                    const resp = response.data
                    const flag = resp.success
                    if (flag) {
                        const res = resp.data
                        commit('SET_USERID', res.userid)
                        commit('SET_NAME', res.name)
                        commit('SET_MOBILE', res.mobile)
                        commit('SET_AVATAR', res.avatar)
                        commit('SET_CODE', res.code)
                    }
                    resolve(flag)
                }).catch(err => {
                    reject(err)
                })
            })
        }
    },
}


export default portrait