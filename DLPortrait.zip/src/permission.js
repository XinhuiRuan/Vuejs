/*
权限校验：
通过router路由前置钩子函数 beforeEach() ，
在跳转路由前进行拦截判断是否已经登录，
如果已登录，则进行路由跳转，如果没有则回到登录页
*/

import router from './router'
import store from './store'
import util from '@/utils/weixin.js'
/*
前置路由钩子函数
to ：即将要进入的目标路由对象
from ：当前导航正要离开的路由对象
next : 调用该方法，进入目标路由
*/
router.beforeEach((to, from, next) => {
    // 动态改变head里的title（员工画像/预提离职）
    let pathFirst = (to.path.split('/').filter(item => item != ''))[0]
    if(pathFirst == "portrait"){
        document.title = "员工画像"
    }else if(pathFirst == "leave"){
        document.title = "预提离职"
    }


    if (process.env.NODE_ENV != "production") {
        next()
        
    } else {
        const code = util.getUrlParam("code") // 截取url上的code ,可能没有,则返回''空字符串
        if (code == "" && process.env.NODE_ENV == "production") {
            let redirectUrl = `${window.location.href}?t=${util.getRandom(1, 51)}`;
            redirectUrl = encodeURIComponent(redirectUrl)
            const appid = process.env.VUE_APP_APPID
            window.location.href = `https://open.weixin.qq.com/connect/oauth2/authorize?appid=${appid}&redirect_uri=${redirectUrl}&response_type=code&scope=snsapi_base&state=123&connect_redirect=1#wechat_redirect`
        }
        else {
            if (!store.state.portrait.userid) {
                // 没有用户id，表示是第一次登入，需要调用微信接口根据code获取用户信息
                store.dispatch("WxLogin", code).then(response => {
                    if (response) {
                        next()
                    }
                })
            } else {
                next()
            }
        }
    }
})
