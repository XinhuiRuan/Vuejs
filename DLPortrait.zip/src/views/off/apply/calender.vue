<template>
  <div class>
    <van-calendar
      :show-title="false"
      :poppable="false"
      :show-confirm="false"
      color="#00AA55"
      :formatter="formatterCalendar"
      :max-date="calendarMaxDate"
      readonly
      :style="{ height: '50vh' }"
    />
  </div>
</template>

<script>
import FormatDateUtil from "@/utils/formatDate";

export default {
  components: {},

  props: ["schedule", "calendarMaxDate"],

  data() {
    return {
    };
  },

  methods: {
    // 格式化日历
    formatterCalendar(day) {
      if (day.type != "disabled") {
        let date = FormatDateUtil.formatDate(day.date);
        day.bottomInfo = this.schedule[date]["left"];
        if (day.bottomInfo - 0 <= 0) {
          day.className = "excessDate";
          day.bottomInfo = "满额";
        } else {
          day.bottomInfo += "人";
        }

        day.topInfo = this.schedule[date]["work"];
        if(day.topInfo === "ROFF"){
          day.className = "excessDate";
        }
      }
      return day;
    }
  }
};
</script>

<style scoped>
</style>