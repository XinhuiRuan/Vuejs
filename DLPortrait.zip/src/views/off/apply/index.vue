<template>
  <div id="offApply" v-loading="loading" element-loading-text="拼命加载中">
    <van-notice-bar
      color="#1989fa"
      background="#ecf9ff"
    >请再三确认请假安排，如年度销单次数达到3次（含），或实际出勤，系统不销单，年度次数达3次，从第3次销单时间起，将冻结请假预约90天。</van-notice-bar>

    <component :is="myCalender" :schedule="schedule" :calendarMaxDate="calendarMaxDate"></component>

    <div class="applyForm">
      <ValidationObserver ref="form">
        <!-- 请假开始时间 -->
        <van-field
          readonly
          label="开始时间"
          placeholder="点击选择时间"
          :value="applyForm.startDate"
          @click="() => {curDatetimePicker = 'start'; showDatetimePicker = true}"
        />

        <!-- 请假结束时间 -->
        <van-field
          readonly
          label="结束时间"
          placeholder="点击选择时间"
          :value="applyForm.endDate"
          @click="() => {curDatetimePicker = 'end'; showDatetimePicker = true}"
        />

        <!-- 有效请假时数 -->
        <van-field readonly label="有效时数" :value="applyForm.validtime+'小时'"></van-field>

        <!-- 假别和剩余时数 -->
        <van-field center readonly :value="applyForm.desc" label="剩余时数" placeholder="请选择假别">
          <template #extra>
            <van-dropdown-menu direction="up">
              <van-dropdown-item
                v-model="applyForm.restListId"
                :options="offTypeOpts"
                @change="getOffTypeDetail()"
              />
            </van-dropdown-menu>
          </template>
        </van-field>

        <!-- 请假原因 -->
        <ValidationProvider rules="required|min:10" name="reason" v-slot="{ errors }">
          <van-field
            v-model.trim="applyForm.reason"
            rows="2"
            required
            clearable
            autosize
            label="请假原因"
            type="textarea"
            maxlength="100"
            placeholder="请填写至少10字"
            show-word-limit
            :error-message="errors[0]"
          />
        </ValidationProvider>
      </ValidationObserver>

      <van-checkbox v-model="checked">我已清楚了解预约请假流程，并认同实际批假以主管实际签核为准的请假结果。</van-checkbox>

      <div id="customBtnGroup">
        <div>
          <van-button type="danger" to="/off">返回</van-button>
        </div>
        <div>
          <van-button type="primary" @click="onSubmit" loading-text="提交中...">提交</van-button>
          <!-- <van-button
            type="primary"
            @click="onSubmit"
            loading-text="提交中..."
            :loading="submitLoading"
          >申请</van-button>-->
        </div>
      </div>
    </div>

    <!-- 时间选择框-->
    <van-popup v-model="showDatetimePicker" position="bottom">
      <van-datetime-picker
        type="datetime"
        title="选择年月日小时"
        :min-date="datetimeMinDate"
        :max-date="datetimeMaxDate"
        :filter="filterDatetime"
        :formatter="formatterDatetime"
        @confirm="onConfirmDatetime"
        @cancel="showDatetimePicker = false"
      />
    </van-popup>
  </div>
</template>

<script>
import store from "@/store";
import { ValidationProvider, ValidationObserver } from "vee-validate";
import FormatDateUtil from "@/utils/formatDate";
import FormApi from "@/api/off/form";
import ApplyApi from "@/api/off/apply";

export default {
  components: {
    ValidationProvider,
    ValidationObserver
  },

  data() {
    return {
      myCalender: null,
      schedule: {},
      calendarMaxDate: null,
      datetimeMaxDate: null,
      datetimeMinDate: null,
      showDatetimePicker: false,
      curDatetimePicker: "",
      destroyCounts: 0, // 销单次数
      leftSchedule: [],
      workSchedule: [],
      applyForm: {
        empno: store.state.portrait.userid,
        name: store.state.portrait.username,
        startDate: "",
        endDate: "",
        validtime: "",
        desc: "",
        restListId: "", // 假別ID
        offType: "", // 假別名字
        reason: ""
      },
      offTypeOpts: [],
      checked: false,
      loading: false
    };
  },

  created() {
    this.setMinDate();
    // 获取页面初始数据
    this.getInitialData();
  },

  methods: {
    // 页面一进来，获取初始数据
    getInitialData() {
      this.loading = true; // 打开加载框

      // 传给后台的参数
      let empno = this.applyForm.empno;
      let startDate = FormatDateUtil.formatDate(this.datetimeMinDate);
      let endDate = FormatDateUtil.formatDate(this.datetimeMaxDate);

      const p1 = ApplyApi.getOffApplyInfo(empno, startDate, endDate); // 获取销单次数，每日的人额
      const p2 = ApplyApi.getWorkSchedule(empno, startDate, endDate); // 获取班表
      // 并发执行两个Promise
      Promise.all([p1, p2])
        .then(res => {
          if (res[0].success && res[1].success) {
            this.destroyCounts = res[0].data.destroyCounts; // 记录违规次数
            this.leftSchedule = res[0].data.leftSchedule; // 记录每日的人额
            this.workSchedule = res[1].data; // 记录行事历
            this.setMaxDateAndSchedule(); // 设置请假中止日期，加载日历子组件
            this.getOffType();
          } else if (!res[0].success) {
            // 后台返回业务逻辑错误，需要提示错误，并返回首页
            this.$dialog
              .alert({
                message: res[0].message
              })
              .then(() => {
                this.$router.push({
                  path: "/off"
                });
              });
          }
        })
        .finally(() => {
          this.loading = false; // 关闭加载框
        });
    },

    // 设置时间选择框的起始时间和初始结束时间（+60天）
    setMinDate() {
      // 设置时间选择器的起始时间（当前日期）
      let curDate = new Date();
      this.datetimeMinDate = curDate;
      // 设置时间选择器的结束时间（+60天）
      let maxDate = new Date();
      this.datetimeMaxDate = new Date(maxDate.setDate(maxDate.getDate() + 60));

      // 设置默认开始时间和结束时间（08:00 和 17:30）
      this.applyForm.startDate =
        FormatDateUtil.formatDate(curDate) + " 08:00:00";
      this.applyForm.endDate = FormatDateUtil.formatDate(curDate) + " 17:30:00";
    },

    // 设置日历框和时间选择框的结束时间，处理日历框日期文案的数据，记载日历子组件
    setMaxDateAndSchedule() {
      // 设置日历和时间选择器的最大时间（当前日期+N天）
      var maxDate = new Date();
      maxDate = maxDate.setDate(
        maxDate.getDate() + this.leftSchedule.length - 1
      );
      this.datetimeMaxDate = new Date(maxDate);
      this.calendarMaxDate = new Date(maxDate);

      // 组装数据：每日人额和每日行事历
      for (let left of this.leftSchedule) {
        this.schedule[left.date] = {};
        this.schedule[left.date]["left"] = left.count;
      }
      for (let work of this.workSchedule) {
        if (this.schedule[work.datetime]) {
          this.schedule[work.datetime]["work"] = work.datecode;
        }
      }

      // 动态加载日历子组件
      let vue = this;
      var myCalender = () => import("@/views/off/apply/calender");
      vue.myCalender = myCalender;
    },

    // 格式化时间选择框
    formatterDatetime(type, val) {
      if (type === "year") {
        return val + "年";
      }
      if (type === "month") {
        return val + "月";
      }
      if (type === "day") {
        return val + "日";
      }
      if (type === "hour") {
        return val + "时";
      }
      if (type === "minute") {
        return val + "分";
      }
      return val;
    },

    // 设置时间选择框按5分钟选择
    filterDatetime(type, options) {
      if (type === "minute") {
        return options.filter(option => option % 5 === 0);
      }
      return options;
    },

    // 确认时间选择
    onConfirmDatetime(value) {
      if (this.curDatetimePicker === "start") {
        this.applyForm.startDate = FormatDateUtil.formatDatetime(value);
      } else if (this.curDatetimePicker === "end") {
        this.applyForm.endDate = FormatDateUtil.formatDatetime(value);
      }

      this.showDatetimePicker = false;
      // 去后台查询有效的请假时数
      this.getOffTypeDetail();
    },

    // 获取假别下拉框的数据
    getOffType() {
      FormApi.getOffType(this.applyForm.empno).then(res => {
        for(let [index,item] of res.data.entries()){
          // 去掉病假
          if(item.text === '病假'){
            res.data.splice(index,1)
            break;
          }
        }

        this.offTypeOpts = res.data;
        // 默认选择第一个
        this.applyForm.restListId = this.offTypeOpts[0]["value"];

        this.getOffTypeDetail();
      });
    },

    // 获取剩余假别时数和请假时数
    getOffTypeDetail() {
      ApplyApi.postOffTypeDetail(this.applyForm).then(res => {
        if (res.data && res.data.cid) {
          // 存在剩余请假时数
          this.applyForm.desc = res.data.desc;
          this.applyForm.validtime = res.data.validtime;
        } else {
          this.applyForm.desc = "无抵扣假别";
          this.applyForm.validtime = "0";
        }
      });
    },

    // 提交申请单
    onSubmit() {
      let that = this;
      this.$refs.form.validate().then(res => {
        if (res) {
          // 进一步判断数据
          let flag = this.checkBeforeSubmit();
          if (flag) {
            // 送审前提示确认框
            let msg = "";
            let msgAlign = "center";
            if (this.destroyCounts !== 0) {
              msg += `您年度销假已有${this.destroyCounts}次，若年度累计销假3次或不销假实出勤3次，则冻结预约请假功能90天。`;
              msgAlign = "left";
            }
            if (this.applyForm.isExcessive) {
              msg += msg === "" ? "" : "<br/>";
              msg += `您预约的请假时间内名额不足，假单可以继续送出，具体签核结果以实际情况为准。`;
              msgAlign = "left";
            }

            if (msg === "") {
              msg += "申请后不可修改，您确定申请吗？";
            }

            // 賦值事假的名字給後台
            for (let item of that.offTypeOpts) {
              if (item.value === that.applyForm.restListId) {
                that.applyForm.offType = item.text;
                break;
              }
            }

            that.$dialog
              .confirm({
                message: msg,
                messageAlign: msgAlign
              })
              .then(() => {
                // on confirm
                that.loading = true; // 打开加载框

                ApplyApi.submitForm(that.applyForm)
                  .then(res => {
                    if(res.success){
                      that.$toast.success(res.message);
                      // 跳回主页
                      that.$router.push("/off");
                    }else{
                      that.$toast.fail(res.message);
                    }
                  })
                  .finally(() => {
                    that.loading = false; // 关闭加载框
                  });
              })
              .catch(() => {
                // on cancel
              });
          }
        } else {
          that.$toast.fail("请填写完整信息");
        }
      });
    },

    // 提交表单之前判断是否可以送审
    checkBeforeSubmit() {
      if (!this.checked) {
        this.$toast.fail("请勾选预约须知");
        return false;
      }

      // 卡控有效时数不能为0
      if (this.applyForm.validtime == "0") {
        this.$toast.fail("没有剩余的请假有效时数");
        return false;
      }

      // 判断数据的正确性：开始时间和结束时间
      let startDate = FormatDateUtil.stringToDate(this.applyForm.startDate);
      let endDate = FormatDateUtil.stringToDate(this.applyForm.endDate);
      if (startDate < new Date()) {
        this.$toast.fail("开始时间需要大于当前时间");
        return false;
      }
      if (startDate >= endDate) {
        this.$toast.fail("开始时间需要小于结束时间");
        return false;
      }

      // 组装数据：请假范围内每天的行事历
      let startFlag = false; // 开启插入数组的标志
      let hasGEDA = false; // 判断假单是否存在工作日
      let workSchedule = [];
      let isExcessive = false;
      for (let day of this.workSchedule) {
        if (day.datetime === FormatDateUtil.formatDate(startDate)) {
          startFlag = true;
        }

        if (startFlag) {    
          if (day.datecode.indexOf('OFF') == -1) {
            hasGEDA = true;
          }
          if (this.schedule[day.datetime].left - 0 <= 0) {
            isExcessive = true; // 标志这笔请假单是超额请假单
          }
          workSchedule.push(day);
        }

        if (day.datetime === FormatDateUtil.formatDate(endDate)) {
          startFlag = false;
        }
      }

      if (!hasGEDA) {
        this.$toast.fail("不能申请都为休息日的请假");
        return false;
      }

      // 判断完成，这张单子是能够送审的
      this.applyForm.isExcessive = isExcessive;
      this.applyForm.workSchedule = workSchedule;
      return true;
    }
  }
};
</script>

<style scoped>
.applyForm {
  width: 94vw;
  margin: 2vh auto;
}

.van-checkbox {
  margin: 1vh;
}

/* 解决ValidationProvider组件造成的下划线消失问题 */
.van-cell--borderless::after,
.van-cell:last-child::after {
  display: inline-block;
}
</style>