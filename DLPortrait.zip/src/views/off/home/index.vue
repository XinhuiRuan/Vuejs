<template>
  <div class>
    <div class="logo">
      <img id="logo" :src="logoUrl" alt />
    </div>

    <div class="btn-group">
      <van-button type="info" block round to="/off/apply">我要预约请假</van-button>
      <van-button type="info" block round :to="{path:'/off/form/list',query: {type: 'my'}}">我的预约请假申请单</van-button>
      <van-button type="info" block round :to="{path:'/off/form/list',query: {type: 'all'}}">预约请假情况</van-button>
    </div>
  </div>
</template>

<script>
export default {
  components: {},

  data() {
    return {
      logoUrl: require("@/assets/Images/INNOLUX.png")
    };
  },

  created(){
    this.$dialog.alert({
      message: '系统正在测试中，请非测试人员暂时先不要使用。',
      theme: 'round-button',
    }).then(() => {
      // on close
    });
  },

  methods: {}
};
</script>

<style scoped>
.logo {
  margin-top: 20%;
  text-align: center;
}

.btn-group{
  margin-top: 15%;
}

.van-button {
  font-size: 0.8rem;
  width: 50%;
  margin: 10% auto;
}
</style>