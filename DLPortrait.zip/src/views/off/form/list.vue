<template>
  <div class>
    <van-dropdown-menu :close-on-click-outside="false">
      <van-dropdown-item :title="dateTitle" ref="item">
        <van-cell
          title="开始日期"
          is-link
          :value="searchForm.startDate"
          @click="() => {datePanelShow = true; dateType = 'start'}"
        />
        <van-cell
          title="结束日期"
          is-link
          :value="searchForm.endDate"
          @click="() => {datePanelShow = true; dateType = 'end'}"
        />
        <div style="padding: 5px 16px;">
          <van-button type="info" block round @click="onChangeDropdown('date')">确认</van-button>
        </div>
      </van-dropdown-item>
      <van-dropdown-item
        v-model="searchForm.restListId"
        :options="offTypeOpts"
        placeholder="假期类别"
        @change="onChangeDropdown"
      />
      <van-dropdown-item
        v-model="searchForm.status"
        :options="statusOpts"
        @change="onChangeDropdown"
      />
    </van-dropdown-menu>

    <!-- 日历框 -->
    <!-- <van-calendar v-model="datePanelShow" @confirm="onConfirmDate" :min-date="minDate" :max-date="maxDate"/> -->

    <van-popup v-model="datePanelShow" position="bottom">
      <van-datetime-picker
        v-model="currentDate"
        type="date"
        title="选择年月日"
        @confirm="onConfirmDate"
        @cancel="datePanelShow = false"
      />
    </van-popup>

    <van-list
      class="cardBody"
      v-model="loading"
      :finished="finished"
      :finished-text="finishedText"
      @load="onLoad"
    >
      <div class="loadingArea">
        <!-- 循环遍历问题回答 -->
        <van-cell-group
          class="formList"
          v-for="(form,index) in formList"
          :key="index"
          @click="() => { if(searchForm.type === 'my') jumpToFormDetail(form.formno)}"
        >
          <van-cell title="单号" :value="form.formno" />
          <van-cell title="请假日期" :value="form.startDate" />
          <van-cell v-if="searchForm.type === 'all'" title="姓名" :value="form.name" />
          <van-cell title="请假假别" :value="form.offType" />
          <van-cell title="请假时数" :value="form.hours" />
          <van-cell title="单据状态" :value="form.status" />
        </van-cell-group>
      </div>
    </van-list>

    <!-- 返回和返回最顶端的两个按钮 -->
    <div class="backBtn el-backtop" @click="backHome">
      <i class="el-icon-back" style="color: #409EFF;"></i>
    </div>
    <el-backtop :bottom="8" :right="60"></el-backtop>
  </div>
</template>

<script>
import store from "@/store";
import FormatDateUtil from "@/utils/formatDate";
import FormApi from "@/api/off/form";
import funHelper from "lodash/function";

export default {
  components: {},

  data() {
    return {
      count: 0, // 计算进入load方法的次数
      offTypeOpts: [],
      statusOpts: [],
      searchForm: {
        empno: store.state.portrait.userid,
        offType: "",
        restListId: "",
        status: "",
        startDate: "",
        endDate: "",
        pageSize: 4,
        type: "" // 判断是查询自己的还是所有的单据
      },
      formList: [],
      datePanelShow: false,
      currentDate: new Date(),
      finishedText: "",
      loading: false,
      finished: false,
      dialogShow: false,
      selectedFormno: ""
    };
  },

  computed: {
    dateTitle: function() {
      let arr1 = this.searchForm.startDate.split("-");
      let arr2 = this.searchForm.endDate.split("-");
      return `${arr1[1]}/${arr1[2]} ~ ${arr2[1]}/${arr2[2]}`;
    }
  },

  created() {
    this.searchForm.type = this.$route.query.type;
    //this.searchForm.empno = this.searchForm.type === "my" ? store.state.portrait.userid : "";

    // 设置查询的额开始和结束日期都为当日
    let date1 = new Date(); // 开始时间
    date1.setMonth(date1.getMonth() - 1);
    this.searchForm.startDate = FormatDateUtil.formatDate(date1);

    let date2 = new Date(); // 结束时间
    this.searchForm.endDate = FormatDateUtil.formatDate(date2);
  },

  // 列表页面需要对筛选框设置缓存，但每次进来需要重新查询数据
  // activated() {
  //   if (this.searchForm.restListId || this.searchForm.status) {
  //     this.formList = [];
  //     this.loading = true;
  //     this.onLoad();
  //   }
  // },

  // watch: {
  //   $route() {
  //     this.searchForm.type = this.$route.query.type;
  //     this.searchForm.empno =
  //       this.searchForm.type === "my" ? store.state.portrait.userid : "";

  //     this.formList = [];
  //     this.loading = true;
  //     this.onLoad();
  //   }
  // },

  methods: {
    backHome() {
      this.$router.push({
        path: "/off"
      });
    },

    // 获取下拉框的数据
    getDropdownData() {
      const p1 = FormApi.getFormStatus();
      const p2 = FormApi.getOffType(this.searchForm.empno); // 查询自己的页面需要工号，查询所有的则不需要
      // 并发执行两个Promise
      return Promise.all([p1, p2]).then(res => {
        // 赋值单据状态下拉数据
        if (res[0].success) {
          res[0].data.unshift({
            text: "所有假别",
            value: ""
          });
          this.statusOpts = res[0].data;
          this.searchForm.status = res[0].data[0]["value"];
        }

        // 赋值假单类别下拉数据
        if (res[1].success) {
          for (let [index, item] of res[1].data.entries()) {
            // 去掉病假
            if (item.text === "病假") {
              res[1].data.splice(index, 1);
              break;
            }
          }

          res[1].data.unshift({
            text: "所有状态",
            value: ""
          });
          this.offTypeOpts = res[1].data;
          this.searchForm.restListId = res[1].data[0]["value"];
        }
      });
    },

    // 确认日期选择
    onConfirmDate(date) {
      this.datePanelShow = false;
      if (this.dateType === "start") {
        this.searchForm.startDate = FormatDateUtil.formatDate(date);
      } else if (this.dateType === "end") {
        this.searchForm.endDate = FormatDateUtil.formatDate(date);
      }
    },

    // 确认日期筛选、假别和状态选择
    onChangeDropdown(item) {
      if (item === "date") {
        this.$refs.item.toggle();
      }
      this.formList = [];
      // 根据重新查询前是否之前的有被加载完，设置不同的初始值
      if (this.finished) {
        this.finished = false;
        this.finishedText = "";
      } else {
        this.onLoad();
      }
    },

    async onLoad() {
      if (this.count === 0) {
        // 第一次进入，获取下拉框的数据
        await this.getDropdownData();
        this.count++;
      }

      this.getOffFormList();
    },

    // 获取单据列表
    getOffFormList() {
      this.searchForm.currentLength = this.formList.length;

      // 賦值事假的名字給後台
      for (let item of this.offTypeOpts) {
        if (item.value === this.searchForm.restListId) {
          this.searchForm.offType = !item.value ? "" : item.text;
          break;
        }
      }

      FormApi.getOffFormList(this.searchForm)
        .then(res => {
          if (res.success) {
            let data = res.data;
            // 遍历增加表单个数
            for (const item of data.rows) {
              this.formList.push(item);
            }

            // 加载状态结束
            this.loading = false;

            // 数据全部加载完成
            if (this.formList.length >= data.total) {
              this.finished = true;
              this.finishedText = "共" + data.total + "笔请假单据";
            }
            console.log(this.formList.length);
          } else {
            this.loading = false;
            this.finished = true;
          }
        })
        .catch(error => {
          // 返回错误时，结束加载
          this.loading = false;
          this.finished = true;
        });
    },

    // 点击卡片跳转到单据详情页面
    jumpToFormDetail(formno) {
      this.$router.push({
        path: "/off/form/detail",
        query: {
          formno // 单号
        }
      });
    }
  }
};
</script>

<style scoped>
.formList {
  width: 90vw;
  padding: 0 2vw;
  margin: 2.5vh auto;
  box-shadow: 0.1rem 0.1rem 0.3rem #888888;
  /* background: rgb(252, 246, 246); */
}

.van-cell {
  padding: 0.8vh 2vw;
  /* background: rgb(252, 246, 246); */
}

.el-backtop {
  width: 1.8rem;
  height: 1.8rem;
}

.backBtn {
  position: fixed;
  background-color: #fff;
  right: 15px;
  bottom: 8px;
  border-radius: 50%;
  align-items: center;
  justify-content: center;
  font-size: 20px;
  box-shadow: 0 0 6px rgba(0, 0, 0, 0.12);
  z-index: 5;
}
</style>