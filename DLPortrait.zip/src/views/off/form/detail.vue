<template>
  <div id="offFormDetail">
    <!-- 单据信息 -->
    <div class="formInfo">
      <van-cell title="工号" :value="formInfo.empno" />
      <van-cell title="姓名" :value="formInfo.name" />
      <van-cell title="请假假别" :value="formInfo.offType" />
      <van-cell title="请假时数" :value="formInfo.hours" />
      <van-cell title="开始时间" :value="formInfo.startDate" />
      <van-cell title="结束时间" :value="formInfo.endDate" />
      <van-cell title="单据状态" :value="formInfo.status" />
      <!-- 请假事由 -->
      <van-cell title="请假事由" :value="formInfo.reason" />
      <!-- <van-field
        v-model="formInfo.reason"
        readonly
        rows="2"
        autosize
        label="请假事由"
        type="textarea"
        show-word-limit
      /> -->
    </div>

    <!-- 签核历程 -->
    <van-steps direction="vertical" :active="activedStep">
      <van-step v-for="(log,index) in formInfo.signLog" :key="index">
        <div class="stepTitle">
          <span v-text="log.date"></span>
          &nbsp;
          <span v-text="log.title"></span>
          &nbsp;
          <span v-text="log.status"></span>
        </div>
        <div class="stepContent" v-text="log.content"></div>
      </van-step>
    </van-steps>

    <div id="customBtnGroup">
      <div v-if="formInfo.operation == 1 || formInfo.operation == 2">
        <van-button type="danger" @click="deleteOffForm">{{btnText}}</van-button>
      </div>
      <div>
        <van-button type="primary" @click="backList">返回</van-button>
      </div>
    </div>
  </div>
</template>

<script>
import store from "@/store";
import FormatDateUtil from "@/utils/formatDate";
import FormApi from "@/api/off/form";

export default {
  components: {},

  data() {
    return {
      userid: store.state.portrait.userid,
      formInfo: {
        formno: "",
        empno: "",
        name: "",
        offType: "",
        hours: "",
        startDate: "",
        endDate: "",
        status: "",
        reason: "",
        operation: "",
        signLog: []
      },
      btnText: "",
      activedStep: 0, // 步骤条的激活点
    };
  },

  created() {
    this.formInfo.formno = this.$route.query.formno;
    this.getFormDetail();
  },


  methods: {
    backList() {
      this.$router.push({
        path: "/off/form/list",
        query: {
          type: 'my'
        }
      });
    },

    // 获取单据的详细信息
    getFormDetail() {
      FormApi.getOffFormInfo(this.formInfo.formno).then((res) => {
        if(res.success){
          this.formInfo = res.data
          this.btnText = this.formInfo.operation == 1 ? "中止" : "销单";

          let signLog = this.formInfo.signLog
          for(let i=0; i<signLog.length; i++){
            if(signLog[i].status === '待签核' || signLog[i].status === '待簽核'){
              this.activedStep = i - 1
              break;
            }

            if(i == signLog.length - 1 && (signLog[i].status != '待签核' || signLog[i].status === '待簽核')){
              this.activedStep = i
            }
          }
        }
      });
    },

    // 中止或销单
    deleteOffForm() {
      // 操作确认框
      this.$dialog
        .confirm({
          message: `确认${this.btnText}吗？`
        })
        .then(() => {
          let params = {
            empno: store.state.portrait.userid,
            name: store.state.portrait.username,
            operation: this.formInfo.operation,
            rows: [
              {formno: this.formInfo.formno}
            ]
          };
          FormApi.deleteOffForm(params).then((res) => {
            if(res.success){
              this.$toast.success(res.message);
              // 返回列表页
              this.backList()
            }
          });
        });
    }
  }
};
</script>

<style scoped>
.formInfo {
  width: 92vw;
  margin: 2vh auto;
  box-shadow: 0.1rem 0.1rem 0.3rem #888888;
}

.van-steps {
  width: 85vw;
  margin: 2vh auto;
}

.van-step .stepTitle {
  font-size: 0.8rem;
  font-weight: bold;
  margin: 1vh 0;
}

.van-step .stepContent {
  font-size: 0.75rem;
  line-height: 1.2rem;
}
</style>