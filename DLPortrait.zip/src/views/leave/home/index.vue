<template>
  <div class>
    <div class="logo">
      <img id="logo" :src="logoUrl" alt />
    </div>

    <div class="btn-group">
      <van-button type="info" block round to="/leave/apply">我要预提离职</van-button>
      <van-button type="info" block round to="/leave/form">我的预提离职申请单</van-button>
      <van-button type="info" block round to="/leave/sign/list">待签核清单</van-button>
    </div>
  </div>
</template>

<script>
export default {
  components: {},

  data() {
    return {
      logoUrl: require("@/assets/Images/INNOLUX.png")
    };
  },

  methods: {}
};
</script>

<style scoped>
.logo {
  margin-top: 20%;
  text-align: center;
}

.btn-group{
  margin-top: 15%;
}

.van-button {
  font-size: 0.8rem;
  width: 50%;
  margin: 10% auto;
}
</style>