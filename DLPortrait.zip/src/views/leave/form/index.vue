<template>
  <div id="leaveForm">
    <van-notice-bar v-if="formInfo.status == '结案'">温馨提示：请您于核定离职日期前三天至关爱中心填写离职单（若期间想要取消离职请忽略此步骤）。</van-notice-bar>
    <van-pull-refresh v-model="isLoading" @refresh="onRefresh" success-text="刷新成功">
      <van-cell-group class="formInfo">
        <!-- <van-cell title="单号" :value="formInfo.formno"/> -->
        <van-cell title="工号" :value="formInfo.empno" />
        <van-cell title="姓名" :value="formInfo.name" />
        <van-cell title="电话" :value="formInfo.phone" />
        <van-cell title="签核状态" :value="formInfo.status" />
        <van-cell title="当前签核人" :value="formInfo.signer" v-if="formInfo.status != '结案'" />
      </van-cell-group>

      <van-steps direction="vertical" :active="formInfo.signLog.length - 1">
        <van-step v-for="(log,index) in formInfo.signLog" :key="index">
          <div class="stepTitle">
            <span v-text="log.date"></span>
            &nbsp;
            <span v-text="log.title"></span>
          </div>
          <div class="stepContent" v-text="log.content"></div>
        </van-step>
      </van-steps>
    </van-pull-refresh>
  </div>
</template>

<script>
import store from "@/store";
import FormApi from "@/api/leave/form";

export default {
  components: {},

  data() {
    return {
      formInfo: {
        formno: "",
        empno: "",
        name: "",
        phone: "",
        status: "",
        signer: "",
        signLog: []
      },
      count: 0,
      isLoading: false
    };
  },

  created() {
    this.getFormDetail();
  },

  methods: {
    // 下拉刷新
    onRefresh() {
      this.getFormDetail();
    },

    // 得到预提离职单的详细信息
    getFormDetail() {
      let userid = store.state.portrait.userid;
      FormApi.getFormDetail(userid).then(response => {
        const resp = response.data;
        if (resp.success) {
          let data = resp.data;
          // 遍历赋值
          for (let prop1 in this.formInfo) {
            for (let prop2 in data) {
              if (prop1 == prop2) {
                this.formInfo[prop1] = data[prop2];
              }
            }
          }

          // this.$toast.success(resp.message)
          this.isLoading = false;
        }
      });
    }
  }
};
</script>

<style scoped>
.van-pull-refresh {
  min-height: 100vh;
}

.formInfo {
  width: 92vw;
  margin: 2vh auto;
  box-shadow: 0.1rem 0.1rem 0.3rem #888888;
}

.van-steps {
  width: 85vw;
  margin: 2vh auto;
}

.van-step .stepTitle {
  font-size: 0.8rem;
  font-weight: bold;
  margin: 1vh 0;
}

.van-step .stepContent {
  font-size: 0.75rem;
  line-height: 1.2rem;
}
</style>