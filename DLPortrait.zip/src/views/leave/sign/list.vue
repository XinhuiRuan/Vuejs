<template>
  <div class>
    <van-notice-bar
      scrollable
      color="#1989fa"
      background="#ecf9ff"
      text="温馨提示：请您尽快面谈签核以保证预提流程在5日内结案。"
    />

    <van-list
      class="cardBody"
      v-model="loading"
      :finished="finished"
      :finished-text="finishedText"
      @load="onLoad"
    >
      <div class="loadingArea">
        <!-- 循环遍历问题回答 -->
        <van-cell-group
          class="formList"
          v-for="(formInfo,index) in formInfos"
          :key="index"
          @click="jumpToSignDetail(formInfo.formno,formInfo.empno)"
        >
          <van-cell title="工号" :value="formInfo.empno" />
          <van-cell title="姓名" :value="formInfo.name" />
          <van-cell title="预提时间" :value="formInfo.sendDate" />
          <van-cell title="员工已提单" :value="formInfo.timeStay" class="warning" />
        </van-cell-group>
      </div>
    </van-list>

    <div class="backBtn el-backtop" @click="backHome">
      <i class="el-icon-back" style="color: #409EFF;" to="/leave"></i>
    </div>
    <el-backtop :bottom="8" :right="60"></el-backtop>

    <!-- <van-button class="btmBtn" plain color="#00BFFF" block to="/leave">返回</van-button> -->
  </div>
</template>

<script>
import store from "@/store";
import SignApi from "@/api/leave/sign";
import funHelper from "lodash/function";

export default {
  components: {},

  data() {
    return {
      finishedText: "",
      formInfos: [],
      loading: false,
      finished: false,
      eachLen: 4 // 每次从后台获取数据的长度
    };
  },

  methods: {
    backHome() {
      this.$router.push({
        path: "/leave"
      });
    },

    onLoad: funHelper.throttle(
      function() {
        // 如果使用()=> 箭头函数 this指向根实例，使用普通函数function()不改变this指向本组件
        console.log("1000ms内只能调用一次!");
        this.getSignList();
      },
      1000,
      { trailing: false }
    ),

    // 得到待签核清单
    getSignList() {
      let userid = store.state.portrait.userid;

      SignApi.getSignList(userid, this.formInfos.length, this.eachLen).then(
        response => {
          const resp = response.data;
          if (resp.success) {
            let data = resp.data;

            if (data.total == 0) {
              // 如果total为0，提示暂无待签核单据，返回主页
              // 加载状态结束
              this.loading = false;
              this.finished = true;
              this.$dialog
                .alert({
                  message: `您暂无待签核单据`
                })
                .then(() => {
                  // 跳回主页
                  this.$router.push("/leave");
                });
            } else {
              this.finishedText = "共" + data.total + "笔待签核单据";
              for (const item of data.rows) {
                this.formInfos.push(item);
              }

              // 加载状态结束
              this.loading = false;

              let loadingTimer = setInterval(() => {
                // 解决用户下滑太快，定时器每隔1秒如果处于加载状态但是还未加载完，重新触发onload事件
                if (!this.finished && this.loading) {
                  this.loading = false;
                }
              }, 1000);

              // 数据全部加载完成
              if (this.formInfos.length >= data.total) {
                this.finished = true;
                clearTimeout(loadingTimer); // 清除定时器
              }
              console.log(this.formInfos.length);
            }
          }
        }
      );
    },

    // 点击卡片跳转到签核详情页面
    jumpToSignDetail(formno,empno) {
      this.$router.push({
        path: "/leave/sign/detail",
        query: {
          formno, // 单号
          empno // 工号
        }
      });
    }
  }
};
</script>

<style scoped>
.loadingArea {
  margin-bottom: -2.5vh;
}

.formList {
  width: 90vw;
  padding: 0 2vw;
  margin: 2.5vh auto;
  box-shadow: 0.1rem 0.1rem 0.3rem #888888;
  /* background: rgb(252, 246, 246); */
}

.van-cell {
  padding: 0.8vh 2vw;
  /* background: rgb(252, 246, 246); */
}

.warning div {
  color: #ff0033;
}

.el-backtop {
  width: 1.8rem;
  height: 1.8rem;
}

.backBtn {
  position: fixed;
  background-color: #fff;
  right: 15px;
  bottom: 8px;
  border-radius: 50%;
  align-items: center;
  justify-content: center;
  font-size: 20px;
  box-shadow: 0 0 6px rgba(0, 0, 0, 0.12);
  z-index: 5;
}
</style>