<template>
  <div id="leaveSignDetail">
    <van-notice-bar
      scrollable
      color="#1989fa"
      background="#ecf9ff"
      v-if="formInfo.recruitname"
      text="人员为派遣员工，故此人员与派遣公司具有劳动关系，面谈时请同步告知同仁还需向派遣公司提出离职。"
    />

    <ValidationObserver ref="form">
      <div class="formDetail">
        <van-cell title="单号" :value="formInfo.formno" />
        <van-cell title="工号" :value="formInfo.empno" />
        <van-cell title="姓名" :value="formInfo.name">
          <template #right-icon>
            <van-tag type="success" round size="small" @click="jumpToPortrait">员工画像</van-tag>
          </template>
        </van-cell>
        <!-- <van-cell v-if="formInfo.recruitname" title="派遣公司" :value="formInfo.recruitname" />
        <van-cell v-if="formInfo.recruitname" title="派遣公司联系人" :value="formInfo.contact" /> -->
        <van-cell title="申请时间" :value="formInfo.sendDate" />
        <van-cell title="希望离职时间" :value="formInfo.expectedDate" />
        <!-- 申请离职原因 -->
        <ValidationProvider>
          <van-field
            v-model="formInfo.reason"
            readonly
            rows="2"
            autosize
            label="申请离职原因"
            type="textarea"
            show-word-limit
          />
        </ValidationProvider>
        <!-- 访谈原因 -->
        <ValidationProvider rules="required|min:10" name="reason" v-slot="{ errors }">
          <van-field
            v-model="formInfo.interview"
            :readonly="isInterviewReadOnly"
            rows="2"
            autosize
            required
            clearable
            label="访谈原因"
            type="textarea"
            show-word-limit
            placeholder="请填写至少10字"
            maxlength="100"
            :error-message="errors[0]"
          />
        </ValidationProvider>

        <!-- 是否一定离职 -->
        <ValidationProvider rules="required">
          <van-field name="radio" label="是否一定离职" required v-model="formInfo.isLeave">
            <template #input>
              <van-radio-group v-model="formInfo.isLeave" direction="horizontal">
                <van-radio name="1">是</van-radio>
                <van-radio name="2" @click="clearConfirmedDate">否</van-radio>
              </van-radio-group>
            </template>
          </van-field>
        </ValidationProvider>

        <!-- 核定离职日期 -->
        <ValidationProvider
          rules="required"
          v-if="formInfo.userType == '2' && formInfo.isLeave != '2'"
        >
          <van-field
            readonly
            clickable
            label="核定离职日期"
            required
            placeholder="点击选择时间"
            :value="formInfo.confirmedDate"
            @click="datePanelShow = true"
          />
        </ValidationProvider>

        <van-cell
          title="本月核定离职状况"
          is-link
          @click="showMonthlyLeave"
          v-if="formInfo.userType == '2'"
        />
      </div>
    </ValidationObserver>

    <div id="customBtnGroup">
      <div>
        <van-button type="danger" to="/leave/sign/list">返回</van-button>
      </div>
      <div>
        <van-button type="primary" @click="onSubmit">{{formInfo.userType == '2' ? '核准' : '访谈完毕'}}</van-button>
      </div>
    </div>

    <van-calendar v-model="datePanelShow" @confirm="onConfirmDate" />

    <!-- 本月预提状况对话框 -->
    <van-dialog class="leaveDialog" v-model="dialogShow" title="本月预提状况">
      <el-table
        :data="monthlyLeave"
        max-height="380"
        style="width: 100%;"
        :default-sort="{prop: 'date', order: 'ascending'}"
      >
        <el-table-column prop="date" label="日期" align="center" sortable></el-table-column>
        <el-table-column prop="expectedNum" label="期望离职人数" align="center" sortable></el-table-column>
        <el-table-column prop="confirmedNum" label="核定离职人数" align="center" sortable></el-table-column>
      </el-table>
    </van-dialog>
  </div>
</template>

<script>
import store from "@/store";
import FormatDateUtil from "@/utils/formatDate";
import SignApi from "@/api/leave/sign";
import ApplyApi from "@/api/leave/apply";
import { ValidationProvider, ValidationObserver } from "vee-validate";

export default {
  components: {
    ValidationProvider,
    ValidationObserver
  },

  data() {
    return {
      userid: store.state.portrait.userid,
      formInfo: {
        formno: "",
        userType: "",
        empno: "",
        name: "",
        // recruitname: "",
        // contact: "",
        sendDate: "",
        expectedDate: "",
        reason: "",
        interview: "",
        isLeave: "",
        confirmedDate: ""
      },
      isInterviewReadOnly: false,
      datePanelShow: false,
      dialogShow: false,
      monthlyLeave: []
    };
  },

  created() {
    this.formInfo.formno = this.$route.query.formno;
    this.getSignDetail();
  },

  // 签核详情页面设置了缓存，通过每次进入比较新旧formno判断是否要重新查询数据
  activated() {
    let newFormno = this.$route.query.formno;
    if (newFormno != this.formInfo.formno) {
      // 清空数据
      for (let prop in this.formInfo) {
        this.formInfo[prop] = "";
      }
      this.formInfo.formno = newFormno;
      this.getSignDetail();
    }
  },

  methods: {
    // 得到签核申请单的详细信息，如果是派遣人员，额外显示派遣公司信息
    getSignDetail() {
      const p1 = ApplyApi.getRecruitnameDetail(this.$route.query.empno); // 获取派遣公司信息
      const p2 = SignApi.getSignDetail(this.userid, this.formInfo.formno); // 得到签核申请单的详细信息
      // 并发执行两个Promise
      Promise.all([p1, p2]).then(response => {
        // 处理得到的派遣公司信息
        if (response[0].data.success) {
          let data = response[0].data.data;
          if (data.recruitname) {
            this.$dialog
                .alert({
                  messageAlign: 'left',
                  message: `人员为派遣员工，待派遣公司面谈后再核定最终离职日期。
              派遣公司：${data.recruitname}
              联系人电话：`.trimMultiSpace() + `${data.contact}`
                })
                .then(() => {
                  // on close
                });
          }

          // this.formInfo.recruitname = data.recruitname;
          // this.formInfo.contact = data.contact;
        }


        // 处理得到的签核申请单信息
        if (response[1].data.success) {
          let data = response[1].data.data;
          // 遍历赋值
          for (let prop1 in this.formInfo) {
            for (let prop2 in data) {
              if (prop1 == prop2) {
                this.formInfo[prop1] = data[prop2];
              }
            }
          }
          // 已存在访谈原因的情况下，不能编辑访谈原因
          if (this.formInfo.interview) {
            this.isInterviewReadOnly = true;
          }
        }
      });

      // SignApi.getSignDetail(this.userid, this.formInfo.formno).then(
      //   response => {
      //     const resp = response.data;
      //     if (resp.success) {
      // let data = resp.data;
      // // 遍历赋值
      // for (let prop1 in this.formInfo) {
      //   for (let prop2 in data) {
      //     if (prop1 == prop2) {
      //       this.formInfo[prop1] = data[prop2];
      //     }
      //   }
      // }

      // // 已存在访谈原因的情况下，不能编辑访谈原因
      // if (this.formInfo.interview) {
      //   this.isInterviewReadOnly = true;
      // }
      //     }
      //   }
      // );
    },

    // 日期控件
    onConfirmDate(date) {
      this.datePanelShow = false;
      this.formInfo.confirmedDate = FormatDateUtil.formatDate(date);
    },

    // 跳转到DL员工画像的个人信息
    jumpToPortrait() {
      // vuex保存员工的工号
      store.dispatch("SaveEmpno", this.formInfo.empno).then(response => {
        this.$router.push({
          path: "/portrait/personInfo",
          query: {
            from: "/leave/sign/detail?formno=" + this.formInfo.formno // 返回的路由
          }
        });
      });
    },

    // 查看本月预提状况
    showMonthlyLeave() {
      SignApi.getMonthlyLeave(this.userid).then(response => {
        const resp = response.data;
        if (resp.success) {
          this.dialogShow = true;
          this.monthlyLeave = resp.data;
        }
      });
    },

    // 选择不离职清空离职日期
    clearConfirmedDate() {
      this.formInfo.confirmedDate = "";
    },

    // 签核预提离职单
    onSubmit() {
      let that = this;
      this.$refs.form.validate().then(res => {
        if (res) {
          // 组装要传到后台的数据
          that.formInfo.userid = that.userid;
          that.formInfo.username = store.state.portrait.username;
          SignApi.signForm(that.formInfo).then(response => {
            const resp = response.data;
            if (resp.success) {
              // 签核成功，返回签核列表
              this.$router.push({
                path: "/leave/sign/list"
              });
              that.$toast.success(resp.message);
            }
          });
        } else {
          that.$toast.fail("请填写正确信息");
        }
      });
    }
  }
};
</script>

<style scoped>
.formDetail {
  width: 96vw;
  margin: 2vh auto;
}

/* 解决ValidationProvider组件造成的下划线消失问题 */
.van-cell--borderless::after,
.van-cell:last-child::after {
  display: inline-block;
}

.leaveDialog {
  width: 90vw;
  margin: 0 auto;
}
</style>