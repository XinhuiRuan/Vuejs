<template>
  <div id="leaveApply">
    <!-- wrapable :scrollable="false" -->
    <van-notice-bar color="#1989fa" background="#ecf9ff">温馨提示：为保证公司及个人权益，请您尽量按照离职流程提前一个月预提，感谢您的配合。</van-notice-bar>

    <div class="applyForm">
      <ValidationObserver ref="form">
        <!-- 工号 -->
        <ValidationProvider>
          <van-field v-model="applyForm.userid" readonly label="工号" size="large" />
        </ValidationProvider>
        <!-- 姓名 -->
        <ValidationProvider>
          <van-field v-model="applyForm.name" readonly label="姓名" size="large" />
        </ValidationProvider>
        <!-- 手机号码 -->
        <ValidationProvider rules="required|length:11" name="phone" v-slot="{ errors }">
          <van-field
            required
            clearable
            v-model.trim="applyForm.phone"
            type="tel"
            label="手机号码"
            size="large"
            maxlength="11"
            :error-message="errors[0]"
          />
        </ValidationProvider>
        <!-- 期望离职时间 -->
        <ValidationProvider>
          <van-field
            readonly
            clickable
            size="large"
            label="期望离职时间"
            required
            placeholder="点击选择时间"
            :value="applyForm.expectedDate"
            @click="datePanelShow = true"
          />
        </ValidationProvider>
        <!-- 离职原因 -->
        <ValidationProvider rules="required|min:10" name="reason" v-slot="{ errors }">
          <van-field
            v-model.trim="applyForm.reason"
            size="large"
            rows="2"
            required
            clearable
            autosize
            label="离职原因"
            type="textarea"
            maxlength="100"
            placeholder="请填写至少10字"
            show-word-limit
            :error-message="errors[0]"
          />
        </ValidationProvider>
      </ValidationObserver>

      <div id="customBtnGroup">
        <div>
          <van-button type="danger" to="/leave">返回</van-button>
        </div>
        <div>
          <van-button
            type="primary"
            @click="onSubmit"
            loading-text="提交中..."
            :loading="submitLoading"
          >申请</van-button>
        </div>
      </div>
    </div>

    <!-- 日历框 -->
    <van-calendar v-model="datePanelShow" @confirm="onConfirmDate" />
  </div>
</template>

<script>
import store from "@/store";
import ApplyApi from "@/api/leave/apply";
import FormatDateUtil from "@/utils/formatDate";
import { ValidationProvider, ValidationObserver } from "vee-validate";

export default {
  components: {
    ValidationProvider,
    ValidationObserver
  },

  data() {
    return {
      applyForm: {
        userid: store.state.portrait.userid,
        name: store.state.portrait.username,
        phone: store.state.portrait.mobile,
        expectedDate: "",
        reason: ""
      },
      datePanelShow: false,
      submitLoading: false
    };
  },

  created() {
    this.getRecruitnameDetail();

    // 初始化设置预离职日期，距离当日延后一个月
    var d = new Date();
    d.setMonth(d.getMonth() + 1);
    this.applyForm.expectedDate = FormatDateUtil.formatDate(d);
  },

  methods: {
    // 日期控件
    onConfirmDate(date) {
      this.datePanelShow = false;
      this.applyForm.expectedDate = FormatDateUtil.formatDate(date);
    },

    // 得到人员的派遣公司信息（如果是派遣人员）
    getRecruitnameDetail() {
      ApplyApi.getRecruitnameDetail(this.applyForm.userid).then(response => {
        const resp = response.data;
        if (resp.success) {
          let data = resp.data;
          if (data.recruitname) {
            this.$dialog
              .alert({
                messageAlign: 'left',
                message: `提醒您：您是派遣员工，还需同步告知派遣公司。
            派遣公司：${data.recruitname}
            联系人电话：`.trimMultiSpace() + `${data.contact}`
              })
              .then(() => {
                // on close
              });
          }
        }
      });
    },

    // 提交申请单
    onSubmit() {
      let that = this;
      this.$refs.form.validate().then(res => {
        if (res) {
          // 内容转码
          let newApplyForm = {};
          for (let prop in this.applyForm) {
            newApplyForm[prop] = escape(this.applyForm[prop]);
          }

          that.$dialog
            .confirm({
              message: "申请后不可修改，您确定申请吗？"
            })
            .then(() => {
              // on confirm，提交申请单
              // 按钮显示为提交中
              that.submitLoading = true;
              // ApplyApi.submitForm(that.applyForm)
              ApplyApi.submitForm(newApplyForm)
                .then(response => {
                  const resp = response.data;
                  that.submitLoading = false;
                  if (resp.success) {
                    that.$dialog
                      .alert({
                        message: `您已提交成功！<div style='text-align:left;'>请等待关爱团长与您面谈，若想要修改离职日期，请您与关爱团长沟通。</div>`
                      })
                      .then(() => {
                        // 跳回主页
                        that.$router.push("/leave");
                      });
                  }
                })
                .catch(error => {
                  // 发生错误了也关闭加载
                  that.submitLoading = false;
                });
            });
        } else {
          that.$toast.fail("请填写正确信息");
        }
      });
    }
  }
};
</script>

<style scoped>
.applyForm {
  width: 90vw;
  margin: 2vh auto;
}

/* .van-field {
  border-bottom: 0.2vh solid #f5f5f5;
} */

/* 解决ValidationProvider组件造成的下划线消失问题 */
.van-cell--borderless::after,
.van-cell:last-child::after {
  display: inline-block;
}
</style>