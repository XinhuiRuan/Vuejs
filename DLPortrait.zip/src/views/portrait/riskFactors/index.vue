<template>
  <div id="customInfo">
      <div id="customTitle">高风险因子</div>
      <div class="row">
        <van-row v-if="content.length == 0" >
          <van-col span="24">无</van-col>
        </van-row>
         <van-row v-else v-for="(item,index) in content" :key="index" >
           <van-col span="6" style="text-align: right;" v-text="item.date"></van-col>
           <van-col span="3" style="text-align: right;" v-text="item.type"></van-col>
           <van-col span="15" v-text="item.question"></van-col>
         </van-row>
      </div>
  </div>    
</template>

<script>
import store from "@/store";
import RiskFactors from "@/api/riskFactors";

export default {
  components: {},

  data() {
    return {
      empno: store.state.portrait.empno,
      content: []
    };
  },

  created(){
    this.getRiskFactors()
  },

  methods: {
    getRiskFactors(){
      let userid = store.state.portrait.userid
      RiskFactors.getRiskFactors(this.empno,userid).then(response => {
        const resp = response.data;
        if (resp.success) {
          this.content = resp.data
        }
      });
    },
  },
};
</script>

<style scoped>
#customInfo{
    min-height: 85vh;
}

.row {
  border: 0.5vw solid white;
  /* padding: 1.5vh 0; */
  margin: 2.5vh 0;
  text-align: center;
  line-height: 6vh;
}

.van-row {
  text-align: center;
  padding: 0.5vh 0;
}
</style>