<template>
  <div id="customInfo">
    <div id="customTitle">生活信息</div>
    <div class="row inline left">
      <div v-text="'交通方式：' + transportation"></div>
    </div>
    <div class="row inline right">
      <div v-text="'住宿：' + dorm"></div>
    </div>

    <!-- 就餐情況和水電費 -->
    <div class="row" v-for="row in lifeInfos" :key="row.desc">
      <div>
        <span class="desc" v-text="row.desc"></span>
        <span v-if="row.data.length == 0" >
          <span>无</span>
        </span>
        <span v-else v-for="(item,idx) in row.data" :key="item.key">
          <span v-if=" idx == 0"></span>
          <span v-else>|&emsp;</span>
          <span>{{item.key}}：{{item.value}}&emsp;</span>
        </span>
      </div>
    </div>

    <div id="customTitle" class="dorm_title">宿舍相关信息</div>
    <!-- 放行单、维修和调退宿 -->
    <div v-for="(dorm,index) in dormInfos" :key="dorm.desc" @click="getDormInfo(index)">
      <div class="row">
        <div v-text="dorm.desc"></div>
      </div>
      <div v-show="dorm.details.isShow">
        <div v-if="dorm.details.rows == 0" >
         <van-row>
            <van-col span="24">无</van-col>
          </van-row>
        </div> 
        <div v-else v-for="(item,idx) in dorm.details.rows" :key="idx">
          <van-row>
            <van-col span="20" v-text="item.content" style="text-align:justify;"></van-col>
            <van-col span="4" v-text="item.status"></van-col>
          </van-row>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import LifeInfoApi from "@/api/lifeInfo";
import store from "@/store";

export default {
  components: {},

  data() {
    return {
      empno: store.state.portrait.empno,
      transportation: "",
      dorm: "外宿",
      lifeInfos: [
        {
          desc: "近三个月就餐状况",
          data: []
        },
        {
          desc: "近三个月水电费",
          data: []
        }
      ],
      dormInfos: [
        {
          desc: "宿舍放行单（近三个月）",
          details: {
            isShow: false,
            rows: []
          }
        },
        {
          desc: "宿舍维修（近三个月）",
          details: {
            isShow: false,
            rows: []
          }
        },
        {
          desc: "宿舍调退宿（近三个月）",
          details: {
            isShow: false,
            rows: []
          }
        }
      ]
    };
  },

  created() {
    this.getLifeInfo();
  },

  methods: {
    // 查询生活信息数据
    getLifeInfo() {
      let userid = store.state.portrait.userid
      LifeInfoApi.getLifeInfo(this.empno,userid).then(response => {
        const resp = response.data;
        if (resp.success) {
          let data = resp.data;
          this.transportation = data.transportation;
          if(data.dorm){
            this.dorm = data.dorm;
          }
          this.lifeInfos[0].data = data.mealFees;
          this.lifeInfos[1].data = data.utilities;
        }
      });
    },

    getDormInfo(index) {
      let area = this.dormInfos[index].details
      if(area.isShow){
        // 已经展开的窗口，直接关闭
        area.isShow = false;
      }
      else if (!area.isShow && area.rows.length > 0) {
        // 已经查询过有记录的宿舍信息，只要展开就可以了
        area.isShow = !area.isShow;
      } else {
        LifeInfoApi.getDormInfo(this.empno, index).then(response => {
          const resp = response.data;
          if (resp.success) {
            area.isShow = true;
            area.rows = resp.data;
          }
        });
      }
    }
  }
};
</script>

<style scoped>
#customInfo{
    min-height: 85vh;
}
.dorm_title{
  margin-top: 4vh;
}

.row {
  margin: 2vh 0;
  border: 0.5vw solid white;
  text-align: center;
  line-height: 6.5vh;
}

.row .desc {
  display: block;
  margin-bottom: -2vh;
}

.inline {
  display: inline-block;
  margin-bottom: 0;
}
.left {
  width: 34vw;
}
.right {
  margin-left: 5vw;
  width: 55vw;
}

.van-row {
  text-align: center;
  padding: 0.5vh 0;
}
</style>