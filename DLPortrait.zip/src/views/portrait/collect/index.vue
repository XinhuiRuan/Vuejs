<template>
  <div class="collectDiv" v-loading="loading" element-loading-text="数据查询中">
    <van-search v-model.trim="search" show-action placeholder="添加反映人员，请输入工号或姓名">
      <template #action>
        <van-button type="info" size="small" @click="getEmpList">添加</van-button>
      </template>
    </van-search>

    <div class="empList_area" v-show="collectInfo.empList.length > 0">
      <div v-for="(emp,index) in collectInfo.empList" :key="index">
        <van-cell
          center
          :title="emp.name"
          :value="emp.empno"
          :label="emp.hireDate"
          value-class="valueClass"
          title-class="txtClass"
          label-class="txtClass"
        >
          <template #right-icon>
            <van-icon
              name="close"
              color="#1989fa"
              size="1rem"
              @click="collectInfo.empList.splice(index, 1)"
            />
          </template>
        </van-cell>
      </div>
    </div>

    <!-- 表单数据 -->
    <ValidationObserver ref="form">
      <div class="collectForm">
        <!-- 反映日期 -->
        <ValidationProvider rules="required">
          <van-field
            readonly
            clickable
            label="反映日期"
            required
            placeholder="点击选择日期"
            :value="collectInfo.date"
            @click="datePanelShow = true"
          />
        </ValidationProvider>

        <!-- 问题一阶 -->
        <ValidationProvider rules="required">
          <van-field
            readonly
            clickable
            required
            label="问题一阶"
            placeholder="点击选择"
            :value="first"
            @click="showQuestionFirst = true"
          />
        </ValidationProvider>
        <!-- 问题二阶 -->
        <ValidationProvider rules="required">
          <van-field
            readonly
            clickable
            required
            label="问题二阶"
            placeholder="先点击选择问题一阶"
            :value="second"
            @click=" () => { if(!readonlySecond) showQuestionSecond = true }"
          />
        </ValidationProvider>

        <!-- 问题描述 -->
        <ValidationProvider rules="required">
          <van-field
            readonly
            clickable
            required
            label="问题描述"
            placeholder="先点击选择问题一阶"
            :value="third"
            @click=" () => { if(!readonlyThird) showQuestionThird = true }"
          />
        </ValidationProvider>

        <!-- 具体内容 -->
        <ValidationProvider>
          <van-field
            v-model.trim="collectInfo.content"
            rows="2"
            clearable
            autosize
            label="具体内容"
            type="textarea"
            maxlength="500"
            placeholder="可选填"
            show-word-limit
          />
        </ValidationProvider>

        <!-- 问题状态 -->
        <ValidationProvider rules="required">
          <van-field name="radio" label="问题状态" required v-model="collectInfo.status">
            <template #input>
              <van-radio-group v-model="collectInfo.status" direction="horizontal">
                <van-radio name="结案">结案</van-radio>
                <van-radio name="转至沟通互动">转至沟通互动</van-radio>
              </van-radio-group>
            </template>
          </van-field>
        </ValidationProvider>

        <!-- 处理回复，如果问题状态为转至沟通互助，则隐藏 -->
        <ValidationProvider rules="required" v-if="collectInfo.status === '结案'">
          <van-field
            v-model.trim="collectInfo.reply"
            rows="2"
            required
            clearable
            autosize
            label="处理回复"
            type="textarea"
            maxlength="500"
            placeholder="必填"
            show-word-limit
          />
        </ValidationProvider>
      </div>
    </ValidationObserver>

    <!-- 两个按钮 -->
    <div id="customBtnGroup">
      <div>
        <van-button type="danger" to="/portrait">返回</van-button>
      </div>
      <div>
        <van-button type="primary" @click="onSubmit">上传</van-button>
      </div>
    </div>

    <!-- 日期弹出框 -->
    <van-calendar v-model="datePanelShow" @confirm="onConfirmDate" />

    <!-- 搜索结果为多个员工时，在弹出框进行进一步确认 -->
    <van-dialog
      v-model="showDialog"
      title="请再次确认"
      :showConfirmButton="false"
      showCancelButton
      cancelButtonText="关闭"
    >
      <van-list
        class="empDialog_area"
        v-model="listLoading"
        :finished="finished"
        finished-text="没有更多了"
        @load="onLoad"
      >
        <div v-for="(emp,index) in tmpEmpList" :key="index">
          <van-cell
            center
            :title="emp.name"
            :value="emp.empno"
            :label="emp.hireDate"
            value-class="valueClass"
            title-class="txtClass"
            label-class="txtClass"
          >
            <template #right-icon>
              <!-- <van-icon name="success" color="#1989fa" size="1rem" @click="addEmpList(emp,index)" /> -->
              <van-button plain type="info" size="small" @click="addEmpList(emp,index)">添加</van-button>
            </template>
          </van-cell>
        </div>
      </van-list>
    </van-dialog>

    <!-- 问题一阶下拉框 -->
    <van-popup v-model="showQuestionFirst" position="bottom">
      <van-picker
        show-toolbar
        :columns="curQuestion[0]"
        @confirm="(val) => onConfirmQuestion(val, 1)"
        @cancel="showQuestionFirst = false"
      />
    </van-popup>
    <!-- 问题二阶下拉框 -->
    <van-popup v-model="showQuestionSecond" position="bottom">
      <van-picker
        show-toolbar
        :columns="curQuestion[1]"
        @confirm="(val) => onConfirmQuestion(val, 2)"
        @cancel="showQuestionSecond = false"
      />
    </van-popup>
    <!-- 问题描述下拉框 -->
    <van-popup v-model="showQuestionThird" position="bottom">
      <van-picker
        show-toolbar
        :columns="curQuestion[2]"
        @confirm="(val) => onConfirmQuestion(val, 3)"
        @cancel="showQuestionThird = false"
      />
    </van-popup>
  </div>
</template>

<script>
import store from "@/store";
import FormatDateUtil from "@/utils/formatDate";
import { ValidationProvider, ValidationObserver } from "vee-validate";
import funHelper from "lodash/function";
import CollectApi from "@/api/portrait/collect";

export default {
  components: {
    ValidationProvider,
    ValidationObserver
  },

  data() {
    return {
      loading: false,
      listLoading: false,
      finished: false,
      showDialog: false,
      currentPage: 1,
      pageSize: 5,
      search: "",
      tmpEmpList: [],
      questionFirstTotal: [],
      questionSecondTotal: {},
      questionThirdTotal: {},
      first: "",
      second: "",
      third: "",
      collectInfo: {
        empList: [],
        date: "",
        content: "",
        status: "结案",
        reply: ""
      },
      mapQuestion: [
        {},
        {},
        {} // 一阶/二阶/三阶问题mapping对象
      ],
      curQuestion: [
        [],
        [],
        [] // 当前 一阶/二阶/三阶问题 下拉框内的数据
      ],
      readonlySecond: true,
      readonlyThird: true,
      datePanelShow: false,
      showQuestionFirst: false,
      showQuestionSecond: false,
      showQuestionThird: false,
      curQuestionSecond: [],
      curQuestionThird: [],
      submitLoading: false
    };
  },

  // 监听表单的问题一阶/二阶，实现联动的的功能
  watch: {
    first: {
      handler: async function(val) {
        debugger
        console.log(this)
        await this.getQuestions(this.mapQuestion[0][val], 1);
        this.second = this.curQuestion[1][0];
        this.readonlySecond = false;
      }
    },

    second: {
      handler: async function(val) {
        await this.getQuestions(this.mapQuestion[1][val], 2);
        this.third = this.curQuestion[2][0];
        this.readonlyThird = false;
      }
    }
  },

  created() {
    this.initForm()
    // 初始化获取一阶问题
    this.getQuestions("", 0);
  },

  methods: {
    // 初始化表单数据
    initForm() {
      this.collectInfo.empList = [];
      // 初始化设置为当前日期
      var d = new Date();
      d.setMonth(d.getMonth());
      this.collectInfo.date = FormatDateUtil.formatDate(d);
      this.collectInfo.content = "";
      this.collectInfo.status = "结案";
      this.collectInfo.reply = "";
      this.collectInfo.first = "";
    },

    // 添加反映人员
    getEmpList() {
      // 查询条件不能为空
      if (!this.search) {
        return;
      }
      this.tmpEmpList = [];
      this.loading = true;

      CollectApi.getEmpByCollect(
        store.state.portrait.userid,
        this.search,
        this.currentPage,
        this.pageSize
      ).then(response => {
        const resp = response.data;
        if (resp.success) {
          let rows = resp.data.rows;
          // 如果有多个员工，在弹出框进行再次确认
          if (rows.length > 1) {
            this.tmpEmpList = rows;
            this.showDialog = true;
            // 每次查询前重置下拉加载的变量
            this.currentPage = 1
            this.pageSize = 5
            this.listLoading = false
            this.finished = false
          } else {
            // 查询结果为一个员工，则直接添加
            //this.collectInfo.empList.push(rows[0]);
            this.addEmpList(rows[0]);
          }
        }
        this.loading = false;
      });
    },

    // 人员确认框内下滑加载
    onLoad: funHelper.throttle(
      function() {
        // 如果使用()=> 箭头函数 this指向根实例，使用普通函数function()不改变this指向本组件
        console.log("1000ms内只能调用一次!");
        this.getMoreEmpList();
      },
      1000,
      { trailing: false }
    ),

    // 人员确认框内下滑加载得到反映人员
    getMoreEmpList() {
      // 页面+1
      this.currentPage++;
      CollectApi.getEmpByCollect(
        store.state.portrait.userid,
        this.search,
        this.currentPage,
        this.pageSize
      ).then(response => {
        const resp = response.data;
        if (resp.success) {
          let data = resp.data
          if (data.total == 0) {
            // 数据已经加载完
            this.finished = true;
          } else {
            for (const row of data.rows) {
              this.tmpEmpList.push(row);
            }
          }

          // 加载状态结束
          this.listLoading = false;

          let loadingTimer = setInterval(() => {
            // 解决用户下滑太快，定时器每隔1秒如果处于加载状态但是还未加载完，重新触发onload事件
            if (!this.finished && this.listLoading) {
              this.listLoading = false;
            }
          }, 1000);

          // 数据全部加载完成
          if (this.tmpEmpList.length >= data.total) {
            this.finished = true;
            clearTimeout(loadingTimer); // 清除定时器
          }
          console.log(this.tmpEmpList.length);
        }
      });
    },

    // 确认添加反应人员，添加成功前去重
    addEmpList(emp, index) {
      // 判断是否已被添加该员工
      for (let item of this.collectInfo.empList) {
        if (item.empno === emp.empno) {
          this.$toast.fail("不能添加重复的反映人员");
          return;
        }
      }

      if (this.showDialog === true) {
        // 弹出框内进行添加
        this.tmpEmpList.splice(index, 1);
        // 将临时员工确认加入表单，最后一个临时员工确认后，关闭弹出框
        if (this.tmpEmpList.length === 0) {
          this.showDialog = false;
        }
      }

      // 添加
      this.collectInfo.empList.push(emp);
    },

    // 从后台获取问题
    getQuestions(id, rank) {
      return CollectApi.getQuestions(id).then(response => {
        const resp = response.data;
        if (resp.success) {
          this.HandleQuestions(rank, resp.data);
        }
      });
    },

    // 处理后台得到的问题，进行mapping
    HandleQuestions(rank, rows) {
      // 重置
      this.curQuestion[rank] = [];
      this.mapQuestion[rank] = [];

      rows.forEach(row => {
        this.curQuestion[rank].push(row.attr1);
        this.mapQuestion[rank][row.attr1] = row.whcl1;
      });
    },

    //  日期确认
    onConfirmDate(date) {
      this.datePanelShow = false;
      this.collectInfo.date = FormatDateUtil.formatDate(date);
    },

    // 问题确认公用方法
    onConfirmQuestion(value, rank) {
      switch (rank) {
        case 1:
          this.first = value;
          this.showQuestionFirst = false;
          break;
        case 2:
          this.second = value;
          this.showQuestionSecond = false;
          break;
        case 3:
          this.third = value;
          this.showQuestionThird = false;
          break;
        default:
          break;
      }
    },

    // 上传
    onSubmit() {
      // 先判断人员不能为空
      if (this.collectInfo.empList.length == 0) {
        this.$toast("请添加反映人员");
        return;
      }

      this.$refs.form.validate().then(res => {
        if (res) {
          // 表单数据通过
          // 添加人员信息
          this.collectInfo.userid = store.state.portrait.userid;
          this.collectInfo.username = store.state.portrait.username;
          this.collectInfo.phone = store.state.portrait.mobile;
          // 添加三阶问题ID
          this.collectInfo.first = this.mapQuestion[0][this.first]
          this.collectInfo.second = this.mapQuestion[1][this.second]
          this.collectInfo.third = this.mapQuestion[2][this.third]

          if (this.collectInfo.status === "转至沟通互动") {
            // 转至沟通互助，清空处理回复
            this.collectInfo.reply = "";
          }
          // 提交表单
          CollectApi.submitCollectForm(this.collectInfo).then(response => {
            const resp = response.data;
            if (resp.success) {
              this.$toast.success("上传成功");
              // 提交成功，初始化表单数据
              this.initForm();
            }
          });
        } else {
          this.$toast("请填写正确信息");
        }
      });
    }
  }
};
</script>

<style scoped>
/* .collectDiv {
  min-height: 100vh;
} */

.van-loading {
  margin-top: 2vh;
  text-align: center;
}

.collectForm {
  width: 96vw;
  margin: 2vh auto;
}

.empList_area {
  width: 96vw;
  margin: 0 auto;
  box-shadow: 0.2rem 0.3rem 0.3rem rgb(222, 227, 230);
  /* box-shadow: 0.3rem 0.5rem 0.5rem #ffdddd; */
}

.valueClass {
  padding-right: 5vw;
}
.txtClass {
  font-size: 0.75rem;
}

.empDialog_area {
  max-height: 60vh;
  overflow: scroll;
}

/* 解决ValidationProvider组件造成的下划线消失问题 */
.van-cell--borderless::after,
.van-cell:last-child::after {
  display: inline-block;
}
</style>