<template>
  <div id="customInfo">
      <div id="customTitle">基本资料</div>
      <table>
        <tr>
          <td v-text="'工号：' + tableCells.empno"></td>
          <td rowspan="3" style="text-align:center;">
            <van-image round width="4rem" height="4rem" :src="tableCells.selfie" />
          </td>
        </tr>
        <tr>
          <td v-text="'姓名：' + tableCells.name"></td>
        </tr>
        <tr>
          <td v-text="'性别：' + tableCells.sex"></td>
        </tr>
        <tr>
          <td v-text="'民族：' + tableCells.nation"></td>
          <td v-text="'联系电话：' + tableCells.telephone"></td>
        </tr>
        <tr>
          <td v-text="'籍贯：' + tableCells.birthPlace"></td>
          <td v-text="'婚姻状况：' + tableCells.marriage"></td>
        </tr>
      </table>

      <div id="customTitle">工作信息</div>
      <table>
        <tr>
          <td v-text="'入职日期：' + tableCells.hireDate"></td>
          <td v-text="'部门代码：' + tableCells.deptno"></td>
        </tr>
        <tr>
          <td v-text="'站点：' + tableCells.position"></td>
          <td v-text="'招聘渠道：' + tableCells.recruitment"></td>
        </tr>
        <tr>
          <td colspan="2" v-text="'部门：' + tableCells.dept"></td>
        </tr>
        <tr>
          <td colspan="2" v-if="tableCells.return > 0" v-text="'返任记录：' + tableCells.return" @click="showReturnRecords()" style="text-decoration: underline;"></td>
          <td colspan="2" v-else v-text="'返任记录：' + tableCells.return"></td>
        </tr>
      </table>
      
      <div id="customTitle">家庭信息</div>
      <table>
        <tr>
          <td v-text="'家庭成员：' + tableCells.members"></td>
        </tr>
        <tr>
          <td v-text="'家庭状况：' + tableCells.condition"></td>
        </tr>
        <tr>
          <td v-text="'紧急联系人：' + tableCells.emergency"></td>
        </tr>
        <tr>
          <td v-text="'电话：' + tableCells.contact"></td>
        </tr>
      </table>

   
      <div id="customTitle">其他信息</div>
      <table>
        <tr>
          <td v-text="'社交圈子：' + tableCells.social"></td>
        </tr>
        <tr>
          <td v-text="'个人爱好：' + tableCells.hobbies"></td>
        </tr>
      </table>
  </div>
</template>

<script>
import store from "@/store";
import personInfoApi from "@/api/personInfo";
import Bus from "@/utils/Bus";

export default {
  components: {},

  data() {
    return {
      empno: store.state.portrait.empno,
      tableCells: {
        //selfie: "data:image/png;base64,",
        selfie: "",
        empno: "",
        name: "",
        sex: "",
        nation: "",
        telephone: "",
        birthPlace: "",
        marriage: "",
        hireDate: "",
        deptno: "",
        position: "",
        recruitment: "",
        dept: "",
        return: "",
        members: "",
        condition: "",
        emergency: "",
        contact: "",
        social: "",
        hobbies: ""
      }
    };
  },

  created() {
    //console.log(this.$route)
    if(this.$route.query.from){
      // 从预提离职的待签核单据详细页面进入，路由中会传from值
      // $nextTick解决第一次$on监听不到的问题
      this.$nextTick(function () {
        Bus.$emit('changeRoute', this.$route.query.from)
      })
    }
    this.getPersonInfo();
  },

  // 清除中央事件总线
  beforeDestroy(){
    Bus.$off('changeRoute')
  },

  methods: {
    // 查询个人信息数据
    getPersonInfo() {
      let userid = store.state.portrait.userid
      personInfoApi.getPersonInfo(this.empno,userid).then(response => {
        const resp = response.data;
        if (resp.success) {
          const data = resp.data;
          for (let prop in data) {
            for (let cell in this.tableCells) {
              if (prop == cell) {
                this.tableCells[cell] = data[prop];
              }
            }
          }
        }
      });
    },

    // 查询返任记录
    showReturnRecords() {
      personInfoApi.getReturnRecord(this.empno).then(response => {
        const resp = response.data;
        if (resp.success) {
          const data = resp.data;
          let content = ""; // 弹出框需要显示的内容
          for (let [idx,row] of data.entries()) {
            content +=
              row.timeFrom + "~" + row.timeTo + "      " + row.reason

            // 除了最后一项，其他每项都加一个换行符
            if(idx != data.length - 1){
              content += "</br>"
            }  
          }

          this.$dialog
            .alert({
              title: "返任记录",
              message: content
            })
            .then(() => {
              // on close
            });
        }
      });
    }
  }
};
</script>

<style scoped>
</style>