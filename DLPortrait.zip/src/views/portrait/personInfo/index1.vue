<template>
  <div class>
    <div v-for="item in tableCells" :key="item.title" class="info">
      <div class="title" v-text="item.title"></div>
      <div v-for="cell in item.cells" :key="cell.key">
        <van-cell v-if="cell.key == 'selfie'" :title="cell.label"  center size="large" title-class="cell-font">
          <template #right-icon>
            <van-image
              width="3rem"
              height="3rem"
              :src="'data:image/png;base64,'+cell.value"
            />
          </template>
        </van-cell>
        <van-cell v-else :title="cell.label" :value="cell.value" size="large" title-class="cell-font" value-class="cell-font"/>
      </div>

      <!-- 
      <div class="title">基本资料</div>
      <van-cell :title="tableCells.selfie.key" center size="large">
        <template #title>
          <div class="title">基本资料</div>
        </template>
        <template #right-icon>
          <van-image width="3rem" height="3rem" :src="'data:image/png;base64,'+tableCells.selfie.value" />
        </template>
      </van-cell>
      <van-cell :title="tableCells.name.key" :value="tableCells.name.value" size="large" />
      <van-cell :title="tableCells.sex.key" :value="tableCells.sex.value" size="large" />
      <van-cell :title="tableCells.nation.key" :value="tableCells.nation.value" size="large" />
      <van-cell :title="tableCells.telephone.key" :value="tableCells.telephone.value" size="large" />
      <van-cell :title="tableCells.birthPlace.key" :value="tableCells.birthPlace.value" size="large" />
      <van-cell :title="tableCells.marriage.key" :value="tableCells.marriage.value" size="large" />-->

      <!-- <table>
        <tr>
          <td v-text="tableCells.empno"></td>
          <td rowspan="3" style="text-align:center;">
            <van-image round width="4rem" height="4rem" :src="tableCells.selfie" />
          </td>
        </tr>
        <tr>
          <td v-text="tableCells.name"></td>
        </tr>
        <tr>
          <td v-text="tableCells.sex"></td>
        </tr>
        <tr>
          <td v-text="tableCells.nation"></td>
          <td v-text="tableCells.telephone"></td>
        </tr>
        <tr>
          <td v-text="tableCells.birthPlace"></td>
          <td v-text="tableCells.marriage"></td>
        </tr>
      </table>-->
    </div>

    <!-- <div class="info">
      <div class="title">工作信息</div>
      <table>
        <tr>
          <td v-text="tableCells.hireDate"></td>
          <td v-text="tableCells.deptno"></td>
        </tr>
        <tr>
          <td v-text="tableCells.position"></td>
          <td v-text="tableCells.recruitment"></td>
        </tr>
        <tr>
          <td colspan="2" v-text="tableCells.dept"></td>
        </tr>
        <tr>
          <td colspan="2" v-text="tableCells.return" @click="showReturnRecords()"></td>
        </tr>
      </table>
    </div>
    <div class="info">
      <div class="title">家庭信息</div>
      <table>
        <tr>
          <td v-text="tableCells.members"></td>
        </tr>
        <tr>
          <td v-text="tableCells.condition"></td>
        </tr>
        <tr>
          <td v-text="tableCells.health"></td>
        </tr>
        <tr>
          <td v-text="tableCells.emergency"></td>
        </tr>
        <tr>
          <td v-text="tableCells.contact"></td>
        </tr>
      </table>
    </div>
    <div class="info">
      <div class="title">其他信息</div>
      <table>
        <tr>
          <td v-text="tableCells.social"></td>
        </tr>
        <tr>
          <td v-text="tableCells.hobbies"></td>
        </tr>
      </table>
    </div>-->
  </div>
</template>

<script>
import personInfoApi from "@/api/personInfo";

export default {
  components: {},

  data() {
    return {
      empno: "18009380",
      tableCells: [
        {
          title: "基本资料",
          cells: [
            {key: "selfie", label: "照片", value: ""},
            { key: "empno", label: "工号" },
            { key: "name", label: "姓名" },
            { key: "sex", label: "性别" },
            { key: "nation", label: "民族" },
            { key: "telephone", label: "联系电话" },
            { key: "birthPlace", label: "籍贯" },
            { key: "marriage", label: "婚姻状况" }
          ]
        },
        {
          title: "工作信息",
          cells: [
            {key: "hireDate", label: "入职日期"},
            { key: "deptno", label: "部门代码" },
            { key: "position", label: "站点" },
            { key: "recruitment", label: "招聘渠道" },
            { key: "dept", label: "部门" },
            { key: "return", label: "返任记录" }
          ]
        },
        {
          title: "家庭信息",
          cells: [
            {key: "members", label: "家庭成员"},
            { key: "condition", label: "家庭状况" },
            { key: "health", label: "家庭成员健康状况" },
            { key: "emergency", label: "紧急联系人" },
            { key: "contact", label: "紧急联系人电话" },
            { key: "return", label: "返任记录" }
          ]
        },
        {
          title: "其他信息",
          cells: [
            {key: "social", label: "社交圈子"},
            { key: "hobbies", label: "个人爱好" },
          ]
        }
      ]
    };
  },

  created() {
    this.getPersonInfo();
  },

  methods: {

    getPersonInfo() {
      personInfoApi.getPersonInfo(this.empno).then(response => {
        console.log(response);
        const resp = response.data;
        if (resp.success) {
          const data = resp.data;
          for (let prop in data) {
            for (let item of this.tableCells) {
              for (let cell of item.cells) {
                if (cell.key == prop) {
                  cell.value = data[prop];
                  break;
                }
              }
            }
            // for (let cell in this.tableCells) {
            //   if (prop == cell) {
            //     this.tableCells[cell].value = data[prop];
            //   }
            // }
          }
        }
      });
    },

    showReturnRecords() {
      this.$dialog
        .alert({
          title: "返任记录",
          message:
            "2018/1/16~2019/2/6     家庭因素</br>2019/6/4~2019/10/16   健康因素"
        })
        .then(() => {
          // on close
        });
    }
  }
};
</script>

<style scoped>
.van-cell {
  position: inherit;
  background-color: transparent;
  padding: 1vh 4vw 0 4vw;
}
.cell-font {
  font-size: 0.75rem;
  color: rgb(233, 229, 223);
}

.info {
  padding: 2vh 2vw 0 2vw;
}
table {
  width: 100%;
}
td {
  padding: 0.6vh 0;
  width: 50%;
}
</style>