<template>
  <div id="customInfo">
      <div id="customTitle">基本工作信息</div>
      <table>
        <tr>
          <td v-text="'班别：' + tableCells.shift"></td>
          <td v-text="'岗位技能等级：' + tableCells.skillLevel"></td>
        </tr>
        <tr>
          <td v-text="'产能记录：' + tableCells.productivity"></td>
          <td v-text="'良率记录：' + tableCells.quality"></td>
        </tr>
        <tr>
          <td colspan="2" v-if="tableCells.record > 0" v-text="'奖惩记录：' + tableCells.record" @click="showBonusAndPenalty()" style="text-decoration: underline;"></td>
          <td colspan="2" v-else v-text="'奖惩记录：' + tableCells.record"></td>
        </tr>
        <tr>
          <td v-text="'直属厂长：' + tableCells.changZhang"></td>
          <td v-text="'直属经理：' + tableCells.jingLi"></td>
        </tr>
        <tr>
          <td v-text="'直属课长：' + tableCells.keZhang"></td>
          <td v-text="'直属线长：' + tableCells.xianZhang"></td>
        </tr>
        <tr>
          <td colspan="2" v-text="'帮扶团长：' + tableCells.tuanZhang"></td>
        </tr>
      </table>

      <div id="customTitle">详细工作信息</div>
      <div
        class="row"
        v-for="(detail,index) in jobDetails"
        :key="index"
      >
        <div>
          <span class="desc" v-text="detail.desc"></span>
          <span v-if="detail.data.length == 0">
            <span>无</span>
          </span>
          <span v-else v-for="(item,idx) in detail.data" :key="item.key">
            <span v-if=" idx == 0"></span>
            <span v-else>|&emsp;</span>
            <span :class="{'warning' : item.warn}" @click="getJobDetails(index, item.key)">{{item.key}}：{{item.value}}&emsp;</span>
          </span>
        </div>
      </div>
  </div>
</template>

<script>
import store from "@/store";
import JobInfo from "@/api/jobInfo";

export default {
  components: {},

  data() {
    return {
      empno: store.state.portrait.empno,
      tableCells: {
        shift: "",
        skillLevel: "",
        productivity: "",
        quality: "",
        record: "",
        changZhang: "",
        jingLi: "",
        keZhang: "",
        xianZhang: "",
        tuanZhang: ""
      },
      jobDetails: [
        {
          desc: "近一个月请假",
          data: []
        },
        {
          desc: "近三个月绩效",
          data: []
        },
        {
          desc: "近三个月加班",
          data: []
        }
      ]
    };
  },

  created() {
    this.getJobInfo();
  },

  methods: {
    // 查询工作信息数据
    getJobInfo() {
      let userid = store.state.portrait.userid
      JobInfo.getJobInfo(this.empno,userid).then(response => {
        const resp = response.data;
        if (resp.success) {
          const data = resp.data;
          for (let prop in data) {
            for (let cell in this.tableCells) {
              if (prop == cell) {
                this.tableCells[cell] = data[prop];
              }
            }
          }

          this.jobDetails[0].data = data.leave;
          this.jobDetails[1].data = data.score;
          this.jobDetails[2].data = data.overtime;
        }
      });
    },

    // 显示奖惩记录
    showBonusAndPenalty(){
      JobInfo.getBonusAndPenalty(this.empno).then(response => {
        const resp = response.data;
        if (resp.success) {
          const data = resp.data;
          let content = ""; // 弹出框需要显示的内容
          for (let [idx,row] of data.entries()) {
            content +=
              content += row.date + "      " + row.type + "      " + row.reason;

            // 除了最后一项，其他每项都加一个换行符
            if(idx != data.length - 1){
              content += "</br>"
            }  
          }

          this.$dialog
            .alert({
              title: "近一年奖惩记录",
              message: content
            })
            .then(() => {
              // on close
            });
        }
      })
    },

    // 获取详细的工作信息，目前只有请假记录
    getJobDetails(index, key) {
      if (index == 0) {
        // 只点击近一个月请假有效
        JobInfo.getLeaves(this.empno, key).then(response => {
          const resp = response.data;
          if (resp.success) {
            let content = ""; // 弹出框需要显示的内容
            const data = resp.data;
            for (let [idx, row] of data.entries()) {
              content += row.date + "      " + row.type + "  " + row.duration;

              // 除了最后一项，其他每项都加一个换行符
              if (idx != data.length - 1) {
                content += "</br>";
              }
            }

            this.$dialog
              .alert({
                title: "近一个月请假",
                message: content
              })
              .then(() => {
                // on close
              });
          }
        });
      }
    }
  }
};
</script>

<style scoped>
#customInfo{
    min-height: 85vh;
}
.row {
  border: 0.5vw solid white;
  /* padding: 1.5vh 0; */
  margin: 2vh 0;
  text-align: center;
  line-height: 6vh;
}
.row .desc {
  display: block;
  margin-bottom: -2vh;
}

.warning {
  color: #FF5511;
}
</style>