<template>
  <div>
        <van-search v-model.trim="search" show-action placeholder="请输入工号或姓名" @search="getEmpList">
          <template #action>
            <van-button type="info" size="small" @click="getEmpList">查询</van-button>
          </template>
          <template #left>
            <van-button type="info" size="small" to="/portrait/collect">问题收集</van-button>
          </template>
        </van-search>

    <div class="cardBody">
      <van-loading type="spinner" color="#1989fa" v-if="loading" />
      <div
        v-else
        class="card"
        v-for="(emp,index) in empList"
        :key="index"
        @click="JumpToPersonInfo(emp.empno)"
      >
        <div class="part1">
          <div v-text="emp.empno + emp.name"></div>
          <div v-text="emp.hireDate"></div>
        </div>
        <div class="part2">
          <div
            v-for="(item,idx) in emp.newContent"
            :key="idx"
            :style="emp.style"
            v-text="item"
            class="van-ellipsis"
          ></div>
        </div>
      </div>
    </div>

    <!-- 分页栏 -->
    <van-pagination
      v-model="currentPage"
      :total-items="total"
      :items-per-page="pageSize"
      @change="handleCurrentChange"
    />
  </div>
</template>

<script>
import store from "@/store";
import HomeApi from "@/api/home";

export default {
  data() {
    return {
      userid: store.state.portrait.userid,
      loading: true,
      currentPage: 1,
      total: 0,
      pageSize: 10,
      search: "",
      empList: []
    };
  },

  components: {},

  created() {
    this.getEmpList();
  },

  methods: {
    // 查询可以查看的員工列表
    getEmpList() {
      this.loading = true;
      HomeApi.getEmpList(
        this.userid,
        this.search,
        this.currentPage,
        this.pageSize
      ).then(response => {
        const resp = response.data;
        if (resp.success) {
          let data = resp.data;
          this.total = data.total;
          this.empList = data.rows;

          // 需求：每个人的异常需要两两一组显示在同一行，用逗号隔开；且每行动态垂直居中
          // 实现方法：遍历每个人的异常个数，根据个数来计算每个异常的行高和设置垂直居中
          for (let emp of this.empList) {
            emp.newContent = [];
            emp.style = "";
            // 去除数组中的空元素
            emp.content = emp.content.filter(item => item.length > 0);
            let len = emp.content.length; // 每个人有多少个异常
            if (len > 0) {
              let tmp = "";
              for (let i = 0; i < len; i++) {
                let item = emp.content[i];
                if (i % 2 == 1) {
                  // 处理偶数行的数据（数组第1个数据i=0）
                  tmp += item;
                  emp.newContent.push(tmp);
                  tmp = "";
                } else if (i % 2 == 0) {
                  // 处理奇数行的数据
                  tmp += item;
                  if (i == len - 1) {
                    emp.newContent.push(tmp);
                    tmp = "";
                  } else {
                    tmp += "，";
                  }
                }
              }
              // 7是在css中设置的div.part2的高度
              emp.style =
                "height:" +
                7 / emp.newContent.length +
                "vh;line-height: " +
                7 / emp.newContent.length +
                "vh;";
            }
          }
        }

        this.loading = false;
      });
    },

    // 改变当前页面
    handleCurrentChange(val) {
      this.currentPage = val;
      this.getEmpList();
    },

    JumpToPersonInfo(empno) {
      store.dispatch("SaveEmpno", empno).then(response => {
        // 跳转到个人信息
        this.$router.push({
          path: "/portrait/personInfo"
        });
      });
    }
  }
};
</script>

<style scoped>
.van-loading {
  margin-top: 10%;
  text-align: center;
}

.card {
  height: 7vh;
  width: 92vw;
  margin: 2.5vh auto;
  box-shadow: 0.3rem 0.5rem 0.5rem #888888;
}

.part1,
.part2 {
  height: 100%;
}

.part1 {
  float: left;
  width: 34%;
  font-weight: bold;
  font-size: 0.7rem;
  color: rgba(19, 61, 197, 0.459);
}
.part2 {
  float: right;
  width: 66%;
  background: rgba(19, 61, 197, 0.459);
  color: white;
  font-size: 0.65rem;
}

.part1 div {
  display: flex;
  align-items: center;
  justify-content: center;
  height: 50%;
}
.part2 div {
  padding-left: 3%;
  text-align: left;
  /* overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap; */
}

.van-search {
  margin-top: 2vh;
}

.van-pagination {
  position: fixed;
  bottom: 0;
  left: 0;
  width: 100%;
  background-color: #fff;
}

.cardBody:after {
  content: "";
  height: 35px;
  display: block;
}
</style>