import axios from "axios"

const request = axios.create({
    baseURL: process.env.VUE_APP_SERVICE_URL_WX, // 不使用代理了，直接连api的url
    
    timeout: 20000 // 请求超时，设置20s
})

// 发送请求后设置拦截器（之后实现具体功能）
// Add a request interceptor
request.interceptors.request.use(function (config) {
    // Do something with request data
    return config;
}, function (error) {
    // Do something with request error
    loading.close(); //关闭加载效果
    return Promise.reject(error);
});

// 接收请求前设置拦截器（之后实现具体功能）
// Add a response interceptor
request.interceptors.response.use(function (response) {
    // Do something with response data
    const resp = response.data;
    // 如果后台响应状态码不是 200 , 说明后台服务有异常,统一可在此处处理
    if(resp.code !== 200 && resp.code !== 2000){
        Message({
            message: resp.message || '系统异常',
            type: 'warning',
            duration: 5 * 1000 // 停留时长
        })
    }

    return response;
}, function (error) {
    // Do something with response error
    // 当请求接口出错时, 进行弹出错误提示, 如 404, 500, 请求超时
    console.log('response error', error.response.status)
    Message({
        message: error.message,
        type: 'error',
        duration: 5 * 1000 // 停留时长
    })
    
    return Promise.reject(error);
});


// 自己封装好axios之后，接着去api/test.js下接着看代码
export default request // 导出 axios 对象