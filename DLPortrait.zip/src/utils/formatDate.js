export default {
    // 日期转字符串：格式化日期为“yyyy-MM-dd”
    formatDate(date) {
        let year = date.getFullYear();
        let month = date.getMonth() + 1;
        month = month < 10 ? "0" + month : month;
        let day = date.getDate();
        day = day < 10 ? "0" + day : day;
        return `${year}-${month}-${day}`;
    },

    // 日期转字符串：格式化日期为“yyyy-MM-dd HH:mm:ss”
    formatDatetime(datetime) {
        let year = datetime.getFullYear();
        let month = datetime.getMonth() + 1;
        month = month < 10 ? "0" + month : month;
        let day = datetime.getDate();
        day = day < 10 ? "0" + day : day;
        let hour = datetime.getHours();
        hour = hour < 10 ? "0" + hour : hour;
        let minute = datetime.getMinutes();
        minute = minute < 10 ? "0" + minute : minute;
        let second = datetime.getSeconds();
        second = second < 10 ? "0" + second : second;

        return `${year}-${month}-${day} ${hour}:${minute}:${second}`;
    },

    // 字符串转日期：字符串格式为“yyyy-MM-dd HH:mm:ss”
    stringToDate(str) {
        var tempStrs = str.split(" ");
        var dateStrs = tempStrs[0].split("-");
        var year = parseInt(dateStrs[0], 10);
        var month = parseInt(dateStrs[1], 10) - 1;
        var day = parseInt(dateStrs[2], 10);
        var timeStrs = tempStrs[1].split(":");
        var hour = parseInt(timeStrs[0], 10);
        var minute = parseInt(timeStrs[1], 10);
        var second = parseInt(timeStrs[2], 10);
        var date = new Date(year, month, day, hour, minute, second);
        return date;
    }
}