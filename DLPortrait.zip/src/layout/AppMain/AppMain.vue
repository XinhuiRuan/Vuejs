<template>
  <div class="main">
    <!-- 使用 v-show 判断路由为 /home 时不显示横向指示导航 -->
    <!-- <app-link v-show="$route.path !== '/home'"></app-link> -->
    <!-- 当扫二维码进入存在id值时不显示导航栏 -->
    <!-- <app-link v-if="$route.query.id ? false : true"></app-link> -->

    <!-- 子路由渲染出口 -->
    <!-- <router-view>
    </router-view>-->
    <!-- 主区域 -->
    <div
      class="bgDiv"
      id="bgDiv"
      :style="{backgroundImage:`url(${backgroundImg})`,backgroundSize:'100% 100%',backgroundPosition:'center center'}"
    >
      <keep-alive>
        <router-view v-if="$route.meta.keepAlive">
          <!-- 这里是会被缓存的视图组件 -->
        </router-view>
      </keep-alive>

      <router-view v-if="!$route.meta.keepAlive">
        <!-- 这里是不被缓存的视图组件 -->
      </router-view>
    </div>
  </div>
</template>

<script>
import AppLink from "./AppLink.vue";

export default {
  data() {
    return {
      backgroundImg: require("@/assets/Images/bg.png"), // 底图的地址
    };
  },

  components: { AppLink },

  methods: {}
};
</script>

<style scoped>

.bgDiv:after {
  content: "";
  height: 50px;
  display: block;
}
</style>