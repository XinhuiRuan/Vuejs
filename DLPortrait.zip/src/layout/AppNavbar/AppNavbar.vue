<template>
  <div class="navbar">
    <!-- 路由模式下会匹配页面路径和标签的to属性，并自动选中对应的标签 -->
    <van-tabbar v-model="active" class="active_tab">
      <van-tabbar-item v-for="(item,index) in tabbars" :key="index" :to="item.name">
        <span>{{item.title}}</span>
      </van-tabbar-item>
    </van-tabbar>
  </div>
</template>

<script>
import Bus from "@/utils/Bus";

export default {
  data() {
    return {
      currIndex: 0,
      active: 0,
      tabbars: [
        {
          name: "/portrait",
          title: "返回"
        },
        {
          name: "/portrait/personInfo",
          title: "个人信息"
        },
        {
          name: "/portrait/lifeInfo",
          title: "生活信息"
        },
        {
          name: "/portrait/jobInfo",
          title: "工作信息"
        },
        {
          name: "/portrait/riskFactors",
          title: "高风险因子"
        }
      ]
    };
  },

  components: {},

  created() {
    this.SetActiveIdx();

    // 通过中央事件总线，如果是预提离职待签核单子详情页面进入的，则重新设置“返回”按钮的路由
    let that = this;
    Bus.$on("changeRoute", target => {
      // console.log(that.tabbars[0]["name"]);
      // console.log(target); //　注意：发送和监听的事件名称必须一致，target就是获取的数据
      that.tabbars[0]["name"] = target;
    });
  },

  methods: {
    // 通过页面当前路由判断active哪个导航标签
    SetActiveIdx() {
      const curPath = this.$route.path;
      for (let item in this.tabbars) {
        let idx = item - 0;
        if (curPath.indexOf(this.tabbars[idx].name) != -1) {
          this.active = idx;
        }
      }
    }
  }
};
</script>

<style scoped>
.el-menu {
  border-right: none;
}

.van-tabbar-item--active {
  color: #1e90ff;
  /* color: #F5F5F5; */
}

/* .navbar:after {
  content: "";
  height: 50px;
  display: block;
} */
</style>