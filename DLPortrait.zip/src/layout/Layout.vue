<template>
  <div>
    
    <app-main></app-main>

    <!-- 底部导航区域 -->
    <app-navbar></app-navbar>
  </div>
</template>

<script>
import AppMain from './AppMain/AppMain.vue'
import AppNavbar from './AppNavbar/AppNavbar.vue'

export default {
  components: {AppNavbar, AppMain},

  data() {
    return {
       
    };
  },
}
</script>

<style scoped>

</style>